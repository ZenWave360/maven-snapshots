package io.zenwave360.lsp.jvm

import io.zenwave360.lsp.core.contracts.DiagnosticSeverity
import io.zenwave360.lsp.core.contracts.HierarchyNode
import io.zenwave360.lsp.core.contracts.NavigationTarget
import io.zenwave360.lsp.core.contracts.Position
import io.zenwave360.lsp.core.contracts.Range
import com.google.gson.JsonElement
import org.eclipse.lsp4j.Diagnostic
import org.eclipse.lsp4j.DocumentSymbol
import org.eclipse.lsp4j.DiagnosticSeverity as LspDiagnosticSeverity
import org.eclipse.lsp4j.Location
import org.eclipse.lsp4j.MarkupContent
import org.eclipse.lsp4j.MarkupKind
import org.eclipse.lsp4j.SymbolKind
import org.eclipse.lsp4j.TextEdit
import org.eclipse.lsp4j.Position as LspPosition
import org.eclipse.lsp4j.PublishDiagnosticsParams
import org.eclipse.lsp4j.Range as LspRange
import io.zenwave360.lsp.core.platform.WorkspaceStatus

internal object DtoMapper {
    fun toPosition(position: LspPosition): Position =
        Position(
            line = position.line,
            character = position.character
        )

    fun toLspRange(range: Range?): LspRange? =
        range?.let {
            LspRange(
                LspPosition(it.start.line, it.start.character),
                LspPosition(it.end.line, it.end.character)
            )
        }

    fun toHoverContent(markdown: String): MarkupContent =
        MarkupContent(MarkupKind.MARKDOWN, markdown)

    fun toFullDocumentEdit(text: String, replacement: String): TextEdit =
        TextEdit(fullDocumentRange(text), replacement)

    fun toLocation(target: NavigationTarget): Location? =
        toLspRange(target.range)?.let { range -> Location(target.uri, range) }

    fun toDocumentSymbol(node: HierarchyNode): DocumentSymbol =
        DocumentSymbol(
            node.label,
            toSymbolKind(node.kind),
            requireNotNull(toLspRange(node.source.range)),
            requireNotNull(toLspRange(node.source.range)),
            null,
            node.children.map(::toDocumentSymbol)
        )

    fun toPublishDiagnostics(uri: String, diagnostics: List<io.zenwave360.lsp.core.contracts.Diagnostic>): PublishDiagnosticsParams =
        PublishDiagnosticsParams(
            uri,
            diagnostics.map { diagnostic ->
                Diagnostic(
                    requireNotNull(toLspRange(diagnostic.range)),
                    diagnostic.message
                ).apply {
                    severity = diagnostic.severity.toLspSeverity()
                    source = diagnostic.source
                    setCode(diagnostic.code)
                    data = diagnostic.data
                }
            }
        )

    private fun DiagnosticSeverity.toLspSeverity(): LspDiagnosticSeverity =
        when (this) {
            DiagnosticSeverity.ERROR -> LspDiagnosticSeverity.Error
            DiagnosticSeverity.WARNING -> LspDiagnosticSeverity.Warning
            DiagnosticSeverity.INFO -> LspDiagnosticSeverity.Information
            DiagnosticSeverity.HINT -> LspDiagnosticSeverity.Hint
        }

    private fun toSymbolKind(kind: String): SymbolKind =
        when (kind) {
            "entity", "enum", "input", "output" -> SymbolKind.Class
            "service" -> SymbolKind.Interface
            "method", "command" -> SymbolKind.Method
            "event" -> SymbolKind.Event
            "field" -> SymbolKind.Field
            "flow" -> SymbolKind.Function
            "domain", "subdomain" -> SymbolKind.Package
            "manifest" -> SymbolKind.File
            else -> SymbolKind.Object
        }

    private fun fullDocumentRange(text: String): LspRange {
        val lines = text.split('\n')
        val lastLineIndex = (lines.size - 1).coerceAtLeast(0)
        val lastCharacter = lines.lastOrNull()?.length ?: 0
        return LspRange(
            LspPosition(0, 0),
            LspPosition(lastLineIndex, lastCharacter)
        )
    }
}

data class HierarchyRequest(
    val uri: String
)

data class SemanticReferenceRequest(
    val uri: String,
    val semanticId: String
)

/** Params of `zenwave/organizeZflServices`. `mode` is `full` (default) or `additive`. */
data class OrganizeZflServicesRequest(
    val uri: String,
    val mode: com.google.gson.JsonElement? = null,
)

data class ConceptAtRequest(
    val uri: String,
    val semanticPath: String? = null,
    val position: LspPosition? = null,
)

data class WorkspaceStatusDto(
    val state: String,
    val manifestUri: String?,
    val message: String?,
)

internal fun WorkspaceStatus.toDto(): WorkspaceStatusDto =
    WorkspaceStatusDto(
        state = state.name.lowercase(),
        manifestUri = manifestUri,
        message = message,
    )

/** Params of `zenwave/eventFlowViews`. Nullable: Gson leaves absent properties null, reported as InvalidParams. */
data class TextDocumentRequest(
    val textDocument: org.eclipse.lsp4j.TextDocumentIdentifier?,
    val variant: com.google.gson.JsonElement? = null,
    val positions: com.google.gson.JsonElement? = null,
    val lanes: com.google.gson.JsonElement? = null,
)

/** Params of `zenwave/preview`; `mode` is docs (default) or diagrams for ZDL. */
data class PreviewRequest(
    val textDocument: org.eclipse.lsp4j.TextDocumentIdentifier?,
    val sequenceRenderMode: String? = null,
    val mode: com.google.gson.JsonElement? = null,
)

/** Params of `zenwave/symbolAt`: LSP's TextDocumentPositionParams. Nullable, reported as InvalidParams when absent. */
data class SymbolAtRequest(
    val textDocument: org.eclipse.lsp4j.TextDocumentIdentifier?,
    val position: org.eclipse.lsp4j.Position?
)

/** Result of `zenwave/symbolAt`: what `forwardReferences` and `reverseReferences` take, and where the symbol is. */
data class SymbolAtResult(
    val uri: String,
    val semanticId: String,
    val range: Range?
)

data class ModuleSelector(
    val languageId: String,
    val extensions: List<String>
)

data class HierarchyNodeDto(
    val id: String,
    val label: String,
    val kind: String,
    val language: String,
    val sourceUri: String,
    val sourceRange: Range,
    val children: List<HierarchyNodeDto>,
    val relatedResources: List<NavigationTarget>,
    val uiHints: Map<String, String>,
    /** Ids of the nodes and service groups in the same document's `zenwave/eventFlowViews` that stand for this concept. */
    val viewNodeIds: List<String> = emptyList()
)

internal fun HierarchyNode.toDto(): HierarchyNodeDto =
    HierarchyNodeDto(
        id = id,
        label = label,
        kind = kind,
        language = language,
        sourceUri = source.uri,
        sourceRange = source.range,
        children = children.map { it.toDto() },
        relatedResources = relatedResources,
        uiHints = uiHints,
        viewNodeIds = viewNodeIds
    )

/** Params of the `zenwave/pluginCatalogue` notification: the catalogue as a JSON object. Nullable: Gson leaves absent properties null. */
data class PluginCatalogueParams(
    val catalogue: JsonElement? = null
)

/** The `mode` param as lsp-js reads it: absent or null is the default, any other non-string is InvalidParams. */
internal fun modeOrNull(mode: com.google.gson.JsonElement?): String? {
    if (mode == null || mode.isJsonNull) return null
    if (!mode.isJsonPrimitive || !mode.asJsonPrimitive.isString) throw io.zenwave360.lsp.core.visualization.InvalidRequestParamsException("mode must be a string")
    return mode.asString
}

/** The `variant` param as lsp-js reads it: absent or null selects the full flow. */
internal fun variantOrNull(variant: com.google.gson.JsonElement?): String? {
    if (variant == null || variant.isJsonNull) return null
    if (!variant.isJsonPrimitive || !variant.asJsonPrimitive.isString) throw io.zenwave360.lsp.core.visualization.InvalidRequestParamsException("variant must be a string")
    return variant.asString
}

/** The `lanes` param as lsp-js reads it: absent or null is not named (answered as `none`); an unknown value is rejected by the server as invalid params. */
internal fun lanesOrNull(lanes: com.google.gson.JsonElement?): String? {
    if (lanes == null || lanes.isJsonNull) return null
    if (!lanes.isJsonPrimitive || !lanes.asJsonPrimitive.isString) throw io.zenwave360.lsp.core.visualization.InvalidRequestParamsException("lanes must be a string")
    return lanes.asString
}

/**
 * The `positions` param as lsp-js reads it: absent or null is no positions, anything but an object is invalid
 * params, and an entry that is not `{ x, y }` of numbers becomes a non-finite point (reported as `invalid`).
 */
internal fun positionsOrNull(positions: JsonElement?): Map<String, io.zenwave360.lsp.core.visualization.SavedPoint>? {
    if (positions == null || positions.isJsonNull) return null
    if (!positions.isJsonObject) throw io.zenwave360.lsp.core.visualization.InvalidRequestParamsException("positions must be an object")
    fun number(entry: JsonElement?): Double? =
        entry?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asDouble
    return positions.asJsonObject.entrySet().associate { (id, entry) ->
        val obj = entry.takeIf { it.isJsonObject }?.asJsonObject
        val x = number(obj?.get("x"))
        val y = number(obj?.get("y"))
        id to if (x != null && y != null) io.zenwave360.lsp.core.visualization.SavedPoint(x, y)
        else io.zenwave360.lsp.core.visualization.SavedPoint(Double.NaN, Double.NaN)
    }
}
