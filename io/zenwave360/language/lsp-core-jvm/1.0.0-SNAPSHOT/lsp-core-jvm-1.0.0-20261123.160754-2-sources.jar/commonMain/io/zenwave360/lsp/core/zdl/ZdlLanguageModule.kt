package io.zenwave360.lsp.core.zdl

import io.zenwave360.language.zdl.formatter.ZdlFormatter
import io.zenwave360.lsp.core.contracts.CodeAction
import io.zenwave360.lsp.core.contracts.CompletionItem
import io.zenwave360.lsp.core.contracts.Diagnostic
import io.zenwave360.lsp.core.contracts.DocumentSnapshot
import io.zenwave360.lsp.core.contracts.DocumentSymbolRef
import io.zenwave360.lsp.core.contracts.HierarchyNode
import io.zenwave360.lsp.core.contracts.HoverResult
import io.zenwave360.lsp.core.contracts.LanguageCapabilities
import io.zenwave360.lsp.core.contracts.LanguageModule
import io.zenwave360.lsp.core.contracts.NavigationTarget
import io.zenwave360.lsp.core.contracts.ParseResult
import io.zenwave360.lsp.core.contracts.Position
import io.zenwave360.lsp.core.contracts.Range
import io.zenwave360.lsp.core.contracts.RelatedDocuments
import io.zenwave360.lsp.core.jsonpath.SemanticPointerEvaluator
import io.zenwave360.lsp.core.spec.parseSpecDocument
import io.zenwave360.lsp.core.spec.specDeclarationRange
import io.zenwave360.lsp.core.model.SemanticModel
import io.zenwave360.lsp.core.visualization.ModelVisualizations
import io.zenwave360.lsp.core.xref.CrossReferenceContribution

/**
 * The ZDL language. `.zw` files are the same language with a different purpose (they configure plugins), so
 * they are served by a second instance, [zw]: same parser, diagnostics, symbols and hierarchy, but a language id
 * of their own, which lets `zenwave/preview` tell them apart.
 */
class ZdlLanguageModule(
    private val parserAdapter: ZdlParserAdapter = ZdlParserAdapter(),
    override val languageId: String = ModelVisualizations.ZDL,
    private val extension: String = ".zdl",
) : LanguageModule {

    private val hierarchyBuilder = ZdlHierarchyBuilder()
    private val crossReferenceContributor = ZdlCrossReferenceContributor()
    private val formatter = ZdlFormatter()

    override val capabilities: LanguageCapabilities =
        LanguageCapabilities(
            languageId = languageId,
            extensions = listOf(extension),
            supportsHover = true,
            supportsDefinition = true,
            supportsCompletion = true,
            supportsDiagnostics = true,
            supportsHierarchy = true,
            supportsReferences = true,
            supportsFormatting = true,
            supportsCodeActions = true
        )

    override fun parse(snapshot: DocumentSnapshot): ParseResult {
        val semanticModel = parseModel(snapshot)
        val model = semanticModel.asZdlMap()
        return ParseResult(
            documentSymbol = DocumentSymbolRef(snapshot.ref.uri, "document"),
            model = semanticModel,
            diagnostics = diagnosticsFromModel(snapshot, model)
        )
    }

    override fun diagnostics(snapshot: DocumentSnapshot): List<Diagnostic> {
        val model = parseModel(snapshot).asZdlMap()
        return diagnosticsFromModel(snapshot, model)
    }

    override fun diagnostics(snapshot: DocumentSnapshot, parsedArtifact: Any?): List<Diagnostic> =
        diagnosticsFromModel(snapshot, (parsedArtifact as SemanticModel).asZdlMap())

    override fun hover(snapshot: DocumentSnapshot, position: Position): HoverResult? {
        val semanticModel = parseModel(snapshot)
        return hover(snapshot, position, semanticModel)
    }

    override fun hover(snapshot: DocumentSnapshot, position: Position, parsedArtifact: Any?): HoverResult? {
        ZdlRules(snapshot.ref.uri, snapshot.text).let { rules -> if (rules.isRuleSite(position)) return rules.hover(position) }
        val semanticModel = parsedArtifact as SemanticModel
        val path = resolvePathAtPosition(snapshot, semanticModel, position) ?: return null
        val model = semanticModel.asZdlMap()
        val range = model.locationTable().findSource(snapshot.ref.uri, path).range
        return HoverResult(
            documentSymbol = DocumentSymbolRef(snapshot.ref.uri, declarationPath(path), range),
            markdown = describeZdlNode(path, findNodeAtPath(model, path.substringBeforeLast('.', path))),
            range = range
        )
    }

    override fun definition(snapshot: DocumentSnapshot, position: Position): List<NavigationTarget> {
        val semanticModel = parseModel(snapshot)
        return definition(snapshot, position, semanticModel)
    }

    override fun definition(snapshot: DocumentSnapshot, position: Position, parsedArtifact: Any?): List<NavigationTarget> =
        definition(snapshot, position, parsedArtifact, RelatedDocuments.NONE)

    /** The API document an `@asyncapi` or HTTP annotation at [position] points into, so the server can supply it. */
    override fun definitionDependencies(snapshot: DocumentSnapshot, position: Position, parsedArtifact: Any?): List<String> {
        val semanticModel = parsedArtifact as? SemanticModel ?: return emptyList()
        val path = resolvePathAtPosition(snapshot, semanticModel, position)
        val navigation = apiNavigation(snapshot.ref.uri, semanticModel.asZdlMap(), path)
        return listOfNotNull(navigation?.takeIf { it.semanticPath != null }?.target?.uri)
    }

    override fun definition(
        snapshot: DocumentSnapshot,
        position: Position,
        parsedArtifact: Any?,
        related: RelatedDocuments
    ): List<NavigationTarget> {
        ZdlRules(snapshot.ref.uri, snapshot.text).definition(position)?.let { return it }
        val semanticModel = parsedArtifact as SemanticModel
        val path = resolvePathAtPosition(snapshot, semanticModel, position)
        val model = semanticModel.asZdlMap()
        val locations = model.locationTable()

        navigationToApis(snapshot.ref.uri, model, path, related)?.let { return it }

        val targetPath = path?.let { resolveDefinitionPath(model, it) }
            ?: resolveNamedType(model, tokenAtPosition(snapshot.text, position))
            ?: return emptyList()
        val targetLabel = targetPath.substringAfterLast('.')
        return listOf(
            NavigationTarget(
                targetKind = "definition",
                label = targetLabel,
                uri = snapshot.ref.uri,
                range = locations.findSource(snapshot.ref.uri, targetPath).range,
                category = "zdl",
                relationType = "declares"
            )
        )
    }

    override fun hierarchy(snapshot: DocumentSnapshot): List<HierarchyNode> =
        hierarchy(snapshot, parseModel(snapshot))

    override fun hierarchy(snapshot: DocumentSnapshot, parsedArtifact: Any?): List<HierarchyNode> =
        hierarchyBuilder.build(snapshot.ref.uri, (parsedArtifact as SemanticModel).asZdlMap()) +
            listOfNotNull(ZdlRules(snapshot.ref.uri, snapshot.text).hierarchy())

    override fun completion(snapshot: DocumentSnapshot, position: Position, parsedArtifact: Any?): List<CompletionItem> =
        ZdlRules(snapshot.ref.uri, snapshot.text).completion(position)

    override fun codeActions(snapshot: DocumentSnapshot, diagnostics: List<Diagnostic>, parsedArtifact: Any?): List<CodeAction> =
        ZdlRules(snapshot.ref.uri, snapshot.text).codeActions(diagnostics)

    override fun format(snapshot: DocumentSnapshot): String =
        formatter.format(snapshot.text)

    override fun crossReferenceContributions(snapshot: DocumentSnapshot): List<CrossReferenceContribution> =
        crossReferenceContributor.build(snapshot.ref.uri, parseModel(snapshot).asZdlMap())

    override fun crossReferenceContributions(snapshot: DocumentSnapshot, parsedArtifact: Any?): List<CrossReferenceContribution> =
        crossReferenceContributor.build(snapshot.ref.uri, (parsedArtifact as SemanticModel).asZdlMap())

    override fun canHandle(uri: String, text: String?): Boolean =
        uri.endsWith(extension)

    override fun declarationRange(snapshot: DocumentSnapshot, parsedArtifact: Any?, semanticId: String): Range? {
        val path = semanticId.substringAfter('#', "")
        if (path.isEmpty() || semanticId.substringBefore('#') != snapshot.ref.uri) return null
        val locations = (parsedArtifact as SemanticModel).asZdlMap().locationTable()
        return (locations["$path.name"] ?: locations[path])?.toRange()
    }

    private fun parseModel(snapshot: DocumentSnapshot): SemanticModel =
        parserAdapter.parse(snapshot.text)

    private fun diagnosticsFromModel(snapshot: DocumentSnapshot, model: Map<String, Any?>): List<Diagnostic> =
        model["problems"].asList().map { toDiagnostic(snapshot.ref.uri, it.asMap(), snapshot.text) }

    private fun resolvePathAtPosition(
        snapshot: DocumentSnapshot,
        semanticModel: SemanticModel,
        position: Position
    ): String? {
        // dsl-kotlin numbers lines from 1, positions here from 0.
        semanticModel.getLocation(position.line + 1, position.character)?.let { return it }

        val lineText = snapshot.text.lineSequence().elementAtOrNull(position.line) ?: return null
        val maxCharacter = lineText.length
        for (delta in 1..maxCharacter) {
            val left = position.character - delta
            if (left >= 0) {
                semanticModel.getLocation(position.line + 1, left)?.let { return it }
            }
            val right = position.character + delta
            if (right <= maxCharacter) {
                semanticModel.getLocation(position.line + 1, right)?.let { return it }
            }
        }
        return null
    }

    /** The name of a declaration stands for it: `entities.Order.name` is `entities.Order`, a service method's too. */
    private fun declarationPath(path: String): String =
        Regex("""^((?:entities|enums|inputs|outputs|events|services)\.[^.]+(?:\.methods\.[^.]+)?)\.name$""").matchEntire(path)?.groupValues?.get(1) ?: path

    private fun tokenAtPosition(text: String, position: Position): String? {
        val line = text.lines().getOrNull(position.line) ?: return null
        if (line.isEmpty()) return null

        val candidates = Regex("""[A-Za-z_][A-Za-z0-9_]*""")
            .findAll(line)
            .map { match ->
                Triple(match.value, match.range.first, match.range.last + 1)
            }
            .toList()

        if (candidates.isEmpty()) return null

        val exact = candidates.firstOrNull { (_, start, end) ->
            position.character in start until end
        }
        if (exact != null) return exact.first

        return candidates
            .minByOrNull { (_, start, end) ->
                minOf(
                    kotlin.math.abs(position.character - start),
                    kotlin.math.abs(position.character - (end - 1))
                )
            }
            ?.first
    }

    private val NO_TARGET = NavigationTarget("definition", "", "", null, null, "")

    private class ApiNavigation(val target: NavigationTarget, val semanticPath: String?)

    /**
     * `apis` locations, `@asyncapi` and the HTTP annotations of a method go to their API document; a type inside a method
     * does not. [semanticPath] is where in that document the target is declared, when the annotation names it.
     */
    private fun apiNavigation(uri: String, model: Map<String, Any?>, path: String?): ApiNavigation? {
        path ?: return null
        Regex("""^apis\.([^.]+)\.uri$""").matchEntire(path)?.let { match ->
            val api = zdlApiDescriptors(uri, model).firstOrNull { it.name == match.groupValues[1] }
                ?: return ApiNavigation(NO_TARGET, null)
            return ApiNavigation(apiTarget(api.uri, api.uri.substringAfterLast('/'), api.type, "references", null), null)
        }
        Regex("""^((?:events\.[^.]+)|(?:services\.[^.]+\.methods\.[^.]+))\.options\.asyncapi(?:\..+)?$""").matchEntire(path)?.let { match ->
            val options = findNodeAtPath(model, match.groupValues[1]).asMap().mapAt("options")
            val target = resolveAsyncApiChannelTarget(uri, model, options.mapAt("asyncapi")) ?: return ApiNavigation(NO_TARGET, null)
            val semanticPath = SemanticPointerEvaluator.appendProperty("$.channels", target.channel)
            return ApiNavigation(apiTarget(target.api.uri, target.channel, "asyncapi", "publishes", null), semanticPath)
        }
        Regex("""^services\.([^.]+)\.methods\.([^.]+)\.options\.(?:get|post|put|delete|patch)(?:\..+)?$""").matchEntire(path)?.let { match ->
            val target = resolveRestOperationTarget(uri, model, match.groupValues[1], match.groupValues[2]) ?: return ApiNavigation(NO_TARGET, null)
            return ApiNavigation(apiTarget(target.api.uri, target.operationId, "openapi", "rest-operation", null), target.semanticPath)
        }
        return null
    }

    private fun navigationToApis(uri: String, model: Map<String, Any?>, path: String?, related: RelatedDocuments): List<NavigationTarget>? {
        val navigation = apiNavigation(uri, model, path) ?: return null
        if (navigation.target === NO_TARGET) return emptyList()
        val range = navigation.semanticPath?.let { declaredRange(related.get(navigation.target.uri), it) }
        // Without the document or the node there is no range: the transports open the file at the start.
        return listOf(if (range == null) navigation.target else navigation.target.copy(range = range))
    }

    private fun declaredRange(document: DocumentSnapshot?, semanticPath: String): Range? {
        document ?: return null
        return try {
            val spec = parseSpecDocument(document)
            specDeclarationRange(spec, "${spec.model.uri}#$semanticPath")
        } catch (_: Exception) {
            null
        }
    }

    private fun apiTarget(uri: String, label: String, category: String?, relationType: String, range: Range?) =
        NavigationTarget(
            targetKind = "definition",
            label = label,
            uri = uri,
            range = range,
            category = category,
            relationType = relationType
        )

    private fun resolveDefinitionPath(model: Map<String, Any?>, path: String): String? {
        val fieldTypeMatch = Regex("""^(entities|inputs|outputs|events)\.([^.]+)\.fields\.([^.]+)(?:\.type)?$""").matchEntire(path)
        if (fieldTypeMatch != null) {
            val fieldPath = "${fieldTypeMatch.groupValues[1]}.${fieldTypeMatch.groupValues[2]}.fields.${fieldTypeMatch.groupValues[3]}"
            val fieldMap = findNodeAtPath(model, fieldPath).asMap()
            return resolveNamedType(model, fieldMap["type"].asString())
        }

        val serviceAggregateMatch = Regex("""^services\.([^.]+)\.aggregates(?:\.[^.]+)?$""").matchEntire(path)
        if (serviceAggregateMatch != null) {
            val service = model.mapAt("services")[serviceAggregateMatch.groupValues[1]].asMap()
            val aggregateName = service["aggregates"].asList().firstOrNull().asString()
            return aggregateName?.let { "entities.$it" }
        }

        val eventNameMatch = Regex("""^services\.([^.]+)\.methods\.([^.]+)\.withEvents(?:\.[^.]+)?$""").matchEntire(path)
        if (eventNameMatch != null) {
            val method = model.mapAt("services")[eventNameMatch.groupValues[1]].asMap()
                .mapAt("methods")[eventNameMatch.groupValues[2]].asMap()
            val eventName = method["withEvents"].asList().firstOrNull().asString()
            return eventName?.let { "events.$it" }
        }

        return null
    }

    private fun resolveNamedType(model: Map<String, Any?>, typeName: String?): String? {
        val name = typeName ?: return null
        return when {
            model.mapAt("entities").containsKey(name) -> "entities.$name"
            model.mapAt("enums").containsKey(name) -> "enums.$name"
            model.mapAt("inputs").containsKey(name) -> "inputs.$name"
            model.mapAt("outputs").containsKey(name) -> "outputs.$name"
            model.mapAt("events").containsKey(name) -> "events.$name"
            model.mapAt("allEntitiesAndEnums").containsKey(name) -> {
                when (model.mapAt("allEntitiesAndEnums")[name].asMap()["type"].asString()) {
                    "entity" -> "entities.$name"
                    "enum" -> "enums.$name"
                    "input" -> "inputs.$name"
                    "output" -> "outputs.$name"
                    else -> null
                }
            }
            else -> null
        }
    }

    companion object {
        /** The module for `.zw` files: ZDL by every means but its language id and extension. */
        fun zw(): ZdlLanguageModule = ZdlLanguageModule(languageId = ModelVisualizations.ZW, extension = ".zw")
    }
}
