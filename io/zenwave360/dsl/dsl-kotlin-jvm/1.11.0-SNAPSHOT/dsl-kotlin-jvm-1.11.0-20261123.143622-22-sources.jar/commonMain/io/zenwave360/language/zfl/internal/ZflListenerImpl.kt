package io.zenwave360.language.zfl.internal

import io.zenwave360.language.antlr.ZflBaseListener
import io.zenwave360.language.antlr.ZflParser
import io.zenwave360.language.utils.buildMap
import io.zenwave360.language.utils.with
import io.zenwave360.language.utils.appendTo
import io.zenwave360.language.utils.appendToList
import io.zenwave360.language.utils.appendToWithMap
import io.zenwave360.language.zfl.ZflModel
import org.antlr.v4.kotlinruntime.ParserRuleContext
import org.antlr.v4.kotlinruntime.tree.ErrorNode
import org.antlr.v4.kotlinruntime.tree.TerminalNode
import io.zenwave360.language.zfl.internal.ZflListenerUtils.getText
import io.zenwave360.language.zfl.internal.ZflListenerUtils.getValueText
import io.zenwave360.language.zfl.internal.ZflListenerUtils.getComplexValue
import io.zenwave360.language.zfl.internal.ZflListenerUtils.getOptionValue
import io.zenwave360.language.zfl.internal.ZflListenerUtils.getArray
import io.zenwave360.language.zfl.internal.ZflListenerUtils.camelCase
import io.zenwave360.language.zfl.internal.ZflListenerUtils.javadoc
import io.zenwave360.language.zfl.internal.ZflListenerUtils.getLocations
import io.zenwave360.language.zfl.internal.ZflListenerUtils.first

class ZflListenerImpl : ZflBaseListener() {

    val model = ZflModel()
    private val currentStack = ArrayDeque<MutableMap<String, Any?>>()

    override fun enterZfl(ctx: ZflParser.ZflContext) {
        // Entry point
    }

    override fun enterGlobal_javadoc(ctx: ZflParser.Global_javadocContext) {
        model.put("javadoc", javadoc(ctx))
    }

    override fun enterImport_(ctx: ZflParser.Import_Context) {
        model.appendToList("imports", buildMap()
            .with("key", getText(ctx.import_key()))
            .with("value", getValueText(ctx.import_value()?.string())))
    }

    override fun enterConfig_option(ctx: ZflParser.Config_optionContext) {
        val name = ctx.field_name().text
        val value = getComplexValue(ctx.complex_value())
        model.appendTo("config", name, value)
    }

    override fun enterFlow(ctx: ZflParser.FlowContext) {
        val name = getText(ctx.flow_name())
        val jd = javadoc(ctx.javadoc())
        
        currentStack.addLast(buildMap()
            .with("name", name)
            .with("className", camelCase(name!!))
            .with("javadoc", jd)
            .with("options", buildMap())
            .with("systems", buildMap())
            .with("starts", buildMap())
            .with("actions", buildMap())
            .with("whens", mutableListOf<Any?>())
            .with("end", buildMap())
        )
        model.appendTo("flows", name, currentStack.last())

        val flowLocation = "flows.$name"
        model.setLocation(flowLocation, getLocations(ctx))
        model.setLocation("$flowLocation.name", getLocations(ctx.flow_name()))
    }

    override fun exitFlow(ctx: ZflParser.FlowContext) {
        currentStack.removeLast()
    }

    override fun enterFlow_rule(ctx: ZflParser.Flow_ruleContext) {
        val flow = currentStack.lastOrNull() ?: return
        val flowName = flow["name"] as? String ?: return
        val name = getText(ctx.flow_rule_name()) ?: return
        val value = getValueText(ctx.flow_rule_value().simple())
        val aggregate = getText((ctx.getParent() as? ZflParser.Flow_rulesContext)?.rules_aggregate())
        val rule = buildMap()
            .with("name", name)
            .with("value", value)
            .with("aggregate", aggregate)
            .with("options", getOptions(ctx.annotations()))
            .with("javadoc", javadoc(ctx.javadoc()))
        @Suppress("UNCHECKED_CAST")
        val rules = flow.getOrPut("rules") { mutableListOf<Any?>() } as MutableList<Any?>
        rules.add(rule)
        model.setLocation("flows.$flowName.rules[${rules.size - 1}]", getLocations(ctx))
    }

    override fun enterOption(ctx: ZflParser.OptionContext) {
        // annotations of a rule are read by enterFlow_rule, they do not belong to the element on the stack
        if (ctx.getParent()?.getParent() is ZflParser.Flow_ruleContext) return
        val name = ctx.option_name().text.replace("@", "")
        val value = getOptionValue(ctx.option_value())
        if (currentStack.isNotEmpty()) {
            currentStack.last().appendTo("options", name, value)
            currentStack.last().appendToList("optionsList", buildMap().with("name", name).with("value", value))
        }
    }

    // Systems block
    override fun enterSystems(ctx: ZflParser.SystemsContext) {
        model.setLocation("systems", getLocations(ctx))
    }

    override fun enterSystem(ctx: ZflParser.SystemContext) {
        val name = getText(ctx.system_name())
        val jd = javadoc(ctx.javadoc())
        
        currentStack.addLast(buildMap()
            .with("name", name)
            .with("javadoc", jd)
            .with("options", buildMap())
            .with("zdl", null)
            .with("services", buildMap())
            .with("events", mutableListOf<Any?>())
        )

        model.setLocation("systems.$name", getLocations(ctx))
        model.setLocation("systems.${name}.name", getLocations(ctx.system_name()))

        @Suppress("UNCHECKED_CAST")
        (model["systems"] as MutableMap<String, Any?>)[name!!] = currentStack.last()
    }

    override fun exitSystem(ctx: ZflParser.SystemContext) {
        currentStack.removeLast()
    }

    override fun enterSystem_service(ctx: ZflParser.System_serviceContext) {
        val serviceName = if (ctx.system_service_name() != null)
            getText(ctx.system_service_name()) else "DefaultService"

        val service = buildMap()
            .with("name", serviceName)
            .with("options", buildMap())
            .with("aggregates", getArray(ctx.system_service_aggregates(), ","))
            .with("commands", mutableSetOf<Any?>())
        
        currentStack.addLast(service)
        val system = currentStack[currentStack.size - 2]
        @Suppress("UNCHECKED_CAST")
        (system["services"] as MutableMap<String, Any?>)[serviceName!!] = service

        val systemName = system["name"]
        model.setLocation("systems.${systemName}.services.$serviceName", getLocations(ctx))
        model.setLocation("systems.${systemName}.services.$serviceName.name", getLocations(ctx.system_service_name()))
    }

    override fun exitSystem_service(ctx: ZflParser.System_serviceContext) {
        currentStack.removeLast()
    }

    override fun enterSystem_service_body(ctx: ZflParser.System_service_bodyContext) {
        val commands = getArray(ctx.system_service_command_list(), ",")
        currentStack.last()["commands"] = commands
    }

    // Start events
    override fun enterFlow_start(ctx: ZflParser.Flow_startContext) {
        val name = getText(ctx.flow_start_name())
        val jd = javadoc(ctx.javadoc())

        val start = buildMap()
            .with("name", name)
            .with("className", camelCase(name!!))
            .with("javadoc", jd)
            .with("options", buildMap())
            .with("fields", buildMap())

        currentStack.addLast(start)
        val flow = currentStack[currentStack.size - 2]
        @Suppress("UNCHECKED_CAST")
        (flow["starts"] as MutableMap<String, Any?>)[name] = start

        model.setLocation("starts.$name", getLocations(ctx))
        model.setLocation("starts.${name}.name", getLocations(ctx.flow_start_name()))
    }

    override fun exitFlow_start(ctx: ZflParser.Flow_startContext) {
        currentStack.removeLast()
    }

    override fun enterField(ctx: ZflParser.FieldContext) {
        val name = getText(ctx.field_name())
        val type = if (ctx.field_type() != null && ctx.field_type().ID() != null)
            ctx.field_type().ID()!!.text else null
        val isArray = ctx.field_type().ARRAY() != null
        val jd = javadoc(first(ctx.javadoc(), ctx.suffix_javadoc()))

        val field = buildMap()
            .with("name", name)
            .with("type", type)
            .with("isArray", isArray)
            .with("javadoc", jd)
            .with("options", buildMap())

        currentStack.last().appendTo("fields", name!!, field)
    }

    // View block
    override fun enterFlow_view(ctx: ZflParser.Flow_viewContext) = guardedBlock("view", ctx) { enterFlowView(ctx) }

    private fun enterFlowView(ctx: ZflParser.Flow_viewContext) {
        val flow = currentStack.last()
        val flowName = flow["name"] as String
        val key = ctx.flow_view_key()
        val view = buildMap()
            .with("name", getText(ctx.flow_view_name()))
            .with("keyAggregate", getText(key.flow_view_aggregate()))
            .with("keyPath", pathSegments(key.flow_view_path()))
            .with("javadoc", javadoc(ctx.javadoc()))
            .with("options", buildMap())
            .with("members", mutableListOf<Any?>())
            // the view must be the first block of the flow
            .with("first", (ctx.getParent() as? ParserRuleContext)?.children?.firstOrNull() === ctx)
        @Suppress("UNCHECKED_CAST")
        val views = flow.getOrPut("views") { mutableListOf<Any?>() } as MutableList<Any?>
        views.add(view)
        val viewPath = "flows.$flowName.views[${views.size - 1}]"
        model.setLocation(viewPath, getLocations(ctx))
        model.setLocation("$viewPath.key", getLocations(key))
        expectWord(ctx.flow_view_keyword(), "view", "$viewPath.view")
        expectWord(ctx.flow_view_by(), "by", "$viewPath.by")
        @Suppress("UNCHECKED_CAST")
        val members = view["members"] as MutableList<Any?>
        ctx.flow_view_member().forEach { member ->
            members.add(buildMap()
                .with("aggregate", getText(member.flow_view_aggregate()))
                .with("path", pathSegments(member.flow_view_path()))
                .with("many", member.ARRAY() != null))
            model.setLocation("$viewPath.members[${members.size - 1}]", getLocations(member))
        }
        currentStack.addLast(view)
    }

    override fun exitFlow_view(ctx: ZflParser.Flow_viewContext) {
        currentStack.removeLast()
    }

    /**
     * A `view` or `timer` still being typed misses parts the grammar requires. That is a problem on the block, not
     * a failure of the walk: the block is dropped, the stack stays balanced for its exit, and the next block parses.
     */
    private fun guardedBlock(what: String, ctx: ParserRuleContext, enter: () -> Unit) {
        val depth = currentStack.size
        try {
            enter()
        } catch (e: Exception) {
            val flowName = currentStack.getOrNull(depth - 1)?.get("name")
            val path = "flows.$flowName.$what"
            model.setLocation(path, getLocations(ctx))
            model.addProblem(path, ctx.text, "Incomplete $what")
        }
        if (currentStack.size == depth) currentStack.addLast(buildMap())
    }

    /** `view`, `timer`, `by`, `after`, `at` and `unless` are contextual words: the grammar reads an ID, this checks which. */
    private fun expectWord(ctx: ParserRuleContext?, word: String, path: String) {
        if (ctx == null || ctx.text == word) return
        model.setLocation(path, getLocations(ctx))
        model.addProblem(path, ctx.text, "Expected '$word' but found '%s'")
    }

    private fun pathSegments(ctx: ZflParser.Flow_view_pathContext?): List<String> =
        ctx?.keyword()?.map { it.text }.orEmpty()

    // Timer steps
    override fun enterFlow_timer(ctx: ZflParser.Flow_timerContext) = guardedBlock("timer", ctx) { enterFlowTimer(ctx) }

    private fun enterFlowTimer(ctx: ZflParser.Flow_timerContext) {
        val flow = currentStack.last()
        val flowName = flow["name"] as String
        val actionName = getText(ctx.flow_command_name())
        val after = ctx.flow_timer_after()?.flow_timer_event()?.text
        val duration = ctx.flow_timer_after()?.flow_timer_duration()?.text?.let { it.substring(1, it.length - 1) }
        val at = ctx.flow_timer_at()?.let { listOf(getText(it.flow_view_aggregate())) + pathSegments(it.flow_view_path()) }
            ?.joinToString(".")
        val unless = ctx.flow_timer_unless()?.flow_timer_event()?.map { it.text }.orEmpty()
        val timerPath = "flows.$flowName.timers[${(flow["timers"] as? List<*>)?.size ?: 0}]"
        expectWord(ctx.flow_timer_start(), "timer", "$timerPath.timer")
        ctx.flow_timer_after()?.let { expectWord(it.flow_timer_keyword(), "after", "$timerPath.after") }
        ctx.flow_timer_at()?.let { expectWord(it.flow_timer_keyword(), "at", "$timerPath.at") }
        ctx.flow_timer_unless()?.let { expectWord(it.flow_timer_keyword(), "unless", "$timerPath.unless") }
        val occurrence = createOccurrence(
            flow = flow,
            actionName = actionName,
            description = javadoc(ctx.javadoc()),
            // the arming event triggers the command, so paths and diagrams follow the timer
            triggers = listOfNotNull(after),
            options = getOptions(ctx.annotations()),
            definition = false,
            locations = getLocations(ctx),
            annotations = ctx.annotations(),
            baseKey = "$actionName@timer[${after?.let { "after $it" } ?: "at $at"}]",
        )
        val timer = buildMap()
            .with("after", after)
            .with("duration", duration)
            .with("at", at)
            .with("unless", unless)
            // `triggers` and `action` let a timer body be read as a `when` body
            .with("triggers", listOfNotNull(after))
            .with("action", actionName)
            .with("javadoc", javadoc(ctx.javadoc()))
            .with("options", getOptions(ctx.annotations()))
            .with("occurrence", occurrence)
        @Suppress("UNCHECKED_CAST")
        val timers = flow.getOrPut("timers") { mutableListOf<Any?>() } as MutableList<Any?>
        timers.add(timer)
        model.setLocation("flows.$flowName.timers[${timers.size - 1}]", getLocations(ctx))
        currentStack.addLast(timer)
    }

    override fun exitFlow_timer(ctx: ZflParser.Flow_timerContext) {
        currentStack.removeLast()
    }

    // When blocks
    override fun enterFlow_when(ctx: ZflParser.Flow_whenContext) {
        val triggerGroups = mutableListOf<MutableMap<String, Any?>>()
        val collectedTriggers = mutableListOf<String>()
        var triggerSeparator: String? = null

        for (group in ctx.flow_when_trigger().flow_when_trigger_group()) {
            val events = group.flow_when_event_trigger().map { it.text }
            val commaCount = group.COMMA().size
            val orCount = group.OR().size
            val separatorCount = commaCount + orCount
            val hasMixedSeparators = commaCount > 0 && orCount > 0
            val hasTrailingSeparator = separatorCount >= events.size && separatorCount > 0
            val groupSeparator = when {
                commaCount > 0 && orCount == 0 -> ","
                orCount > 0 && commaCount == 0 -> "|"
                else -> null
            }

            if (triggerSeparator == null && groupSeparator != null) {
                triggerSeparator = groupSeparator
            }

            triggerGroups.add(buildMap()
                .with("events", events)
                .with("separator", groupSeparator)
                .with("hasMixedSeparators", hasMixedSeparators)
                .with("hasTrailingSeparator", hasTrailingSeparator))
            collectedTriggers.addAll(events)
        }

        val duplicateTriggers = collectedTriggers
            .groupingBy { it }
            .eachCount()
            .filterValues { it > 1 }
            .keys
        val triggers = collectedTriggers.distinct()
        val actionName = getText(ctx.flow_command_name())
        val flow = currentStack.last()
        val flowName = flow["name"] as String
        val occurrence = createOccurrence(
            flow = flow,
            actionName = actionName,
            description = javadoc(ctx.javadoc()),
            triggers = triggers,
            options = getOptions(ctx.annotations()),
            definition = false,
            locations = getLocations(ctx),
            annotations = ctx.annotations(),
        )

        val whenBlock = buildMap()
            .with("triggers", triggers)
            .with("triggerGroups", triggerGroups)
            .with("triggerSeparator", triggerSeparator)
            .with("action", actionName)
            .with("javadoc", javadoc(ctx.javadoc()))
            .with("options", getOptions(ctx.annotations()))
            .with("occurrence", occurrence)

        currentStack.addLast(whenBlock)

        @Suppress("UNCHECKED_CAST")
        val whens = (flow["whens"] as MutableList<Any?>)
        whens.add(whenBlock)

        model.setLocation("flows.$flowName.whens[${whens.size - 1}]", getLocations(ctx))
        model.setLocation("flows.$flowName.whens[${whens.size - 1}].triggers", getLocations(ctx.flow_when_trigger()))

        val triggerPath = "flows.$flowName.whens[${whens.size - 1}].triggers"
        triggerGroups.forEach { group ->
            if (group["hasMixedSeparators"] == true) {
                model.addProblem(triggerPath, null, "Mixed separators are not allowed in when triggers")
            }
            if (group["hasTrailingSeparator"] == true) {
                model.addProblem(triggerPath, null, "Trailing separators are not allowed in when triggers")
            }
        }
        duplicateTriggers.forEach { duplicate ->
            model.addProblem(triggerPath, duplicate, "Duplicate trigger event '%s' in when clause")
        }

    }

    override fun exitFlow_when(ctx: ZflParser.Flow_whenContext) {
        currentStack.removeLast()
    }

    override fun enterFlow_do(ctx: ZflParser.Flow_doContext) {
        val flow = currentStack.last()
        val actionName = getText(ctx.flow_command_name())
        currentStack.addLast(createOccurrence(
            flow = flow,
            actionName = actionName,
            description = javadoc(ctx.javadoc()),
            triggers = emptyList(),
            options = getOptions(ctx.annotations()),
            definition = true,
            locations = getLocations(ctx),
            annotations = ctx.annotations(),
        ))
    }

    override fun exitFlow_do(ctx: ZflParser.Flow_doContext) {
        val occurrence = currentStack.last()
        val flow = currentStack[currentStack.size - 2]
        mergeOccurrence(getOrCreateAction(flow, occurrence["name"] as? String, null), occurrence)
        currentStack.removeLast()
    }

    override fun enterFlow_do_body(ctx: ZflParser.Flow_do_bodyContext) {
        val current = currentStack.lastOrNull()
        if (current != null && current.containsKey("triggers") && current.containsKey("action")) {
            @Suppress("UNCHECKED_CAST")
            currentStack.addLast(current["occurrence"] as MutableMap<String, Any?>)
        }
    }

    override fun exitFlow_do_body(ctx: ZflParser.Flow_do_bodyContext) {
        val current = currentStack.lastOrNull()
        if (current != null && current.containsKey("steps") && currentStack.size >= 2) {
            val maybeWhen = currentStack[currentStack.size - 2]
            if (maybeWhen.containsKey("triggers") && maybeWhen.containsKey("action")) {
                val flow = currentStack[currentStack.size - 3]
                mergeOccurrence(getOrCreateAction(flow, current["name"] as? String, null), current)
                currentStack.removeLast()
            }
        }
    }

    override fun enterFlow_do_service(ctx: ZflParser.Flow_do_serviceContext) {
        val action = currentStack.last()
        val segments = ctx.flow_service_path().flow_service_segment().mapNotNull { getText(it) }
        val systemName = segments.firstOrNull() ?: "DefaultSystem"
        val serviceName = segments.getOrNull(1)
        val servicePath = segments.joinToString("/")

        if (action["system"] == null) action["system"] = systemName
        if (action["service"] == null) action["service"] = serviceName
        if (action["servicePath"] == null) action["servicePath"] = servicePath
        appendStep(action, buildMap()
            .with("type", "service")
            .with("system", systemName)
            .with("service", serviceName)
            .with("servicePath", servicePath))

        registerCommand(systemName, serviceName ?: systemName, action["name"] as? String)
    }

    override fun enterFlow_do_call(ctx: ZflParser.Flow_do_callContext) {
        appendStep(currentStack.last(), buildMap()
            .with("type", "call")
            .with("async", ctx.ASYNC() != null)
            .with("action", getText(ctx.flow_command_name())))
    }

    override fun enterFlow_do_on(ctx: ZflParser.Flow_do_onContext) {
        val endOutcomes = ctx.flow_event_list().flow_event_name().mapNotNull { getText(it) }
        val endOutcome = endOutcomes.firstOrNull()
        val step = buildMap()
            .with("type", "on")
            // Keep endOutcome for consumers of the pre-list grammar; endOutcomes is authoritative.
            .with("endOutcome", endOutcome)
            .with("endOutcomes", endOutcomes)

        when {
            ctx.CALL() != null -> {
                step["kind"] = "call"
                step["action"] = getText(ctx.flow_command_name())
            }
            ctx.flow_signal_body() != null -> {
                val options = getOptions(ctx.annotations())
                val signalBody = ctx.flow_signal_body() ?: return
                val eventNames = signalBody.flow_event_list().flow_event_name().mapNotNull { getText(it) }
                val explicitOutcome = options["outcome"] as? String
                step["kind"] = "signal"
                step["events"] = eventNames
                step["emits"] = signalBody.EMITS() != null
                step["response"] = signalBody.RESPONSE() != null
                step["options"] = options
                step["terminal"] = true
                step["outcome"] = explicitOutcome ?: if (signalBody.EMITS() != null) endOutcome else null
            }
        }

        appendStep(currentStack.last(), step)
    }

    override fun enterFlow_do_signal(ctx: ZflParser.Flow_do_signalContext) {
        val action = currentStack.last()
        val options = getOptions(ctx.annotations())
        val outcome = options["outcome"] as? String
        val signalBody = ctx.flow_signal_body()
        val eventNames = signalBody.flow_event_list().flow_event_name().mapNotNull { getText(it) }
        eventNames.forEachIndexed { index, endOutcome ->
            appendStep(action, buildMap()
                .with("type", "signal")
                .with("endOutcome", endOutcome)
                .with("emits", signalBody.EMITS() != null)
                .with("response", signalBody.RESPONSE() != null)
                .with("eventCount", eventNames.size)
                .with("eventIndex", index)
                .with("options", options)
                .with("outcome", if (signalBody.EMITS() != null) outcome else null))
            @Suppress("UNCHECKED_CAST")
            if (signalBody.EMITS() != null) {
                (action["emits"] as MutableList<Any?>).add(endOutcome)
                (action["emissions"] as MutableList<Any?>).add(buildMap()
                    .with("eventName", endOutcome)
                    .with("outcome", outcome)
                    .with("failure", options.containsKey("failure")))
            }
            @Suppress("UNCHECKED_CAST")
            if (signalBody.RESPONSE() != null) {
                (action["responses"] as MutableList<Any?>).add(endOutcome)
                (action["responseDetails"] as MutableList<Any?>).add(buildMap()
                    .with("name", endOutcome)
                    .with("outcome", outcome)
                    .with("options", options))
            }
        }
    }

    private fun getOptions(ctx: ZflParser.AnnotationsContext?): MutableMap<String, Any?> {
        val options = buildMap()
        ctx?.option()?.forEach { option ->
            val name = option.option_name().text.replace("@", "")
            val value = getOptionValue(option.option_value())
            options[name] = value
        }
        return options
    }

    // End block
    override fun enterFlow_end(ctx: ZflParser.Flow_endContext) {
        val end = buildMap()
            .with("endOutcomes", buildMap())
            .with("javadoc", javadoc(ctx.javadoc()))

        currentStack.addLast(end)
        val flow = currentStack[currentStack.size - 2]
        flow["end"] = end
        model.setLocation("flows.${flow["name"]}.end", getLocations(ctx))
    }

    override fun exitFlow_end(ctx: ZflParser.Flow_endContext) {
        currentStack.removeLast()
    }

    override fun enterFlow_end_outcomes(ctx: ZflParser.Flow_end_outcomesContext) {
        val endOutcomes = buildMap()
        val outcomes = mutableListOf<Any?>()
        val flowName = currentStack[currentStack.size - 2]["name"]
        ctx.flow_end_outcome().forEach { endOutcome ->
            try {
                val outcomeName = endOutcome.flow_end_outcome_name()?.text ?: return@forEach
                val outcomeEvents = getOutcomeEvents(endOutcome.flow_end_outcome_list()).orEmpty()
                // a repeated outcome is one outcome: its events merge, each line is a final-state variant
                @Suppress("UNCHECKED_CAST")
                val merged = (endOutcomes[outcomeName] as? List<String>).orEmpty()
                endOutcomes.with(outcomeName, (merged + outcomeEvents).distinct())
                // kept as a list, so a repeated aggregate reaches the analyzer
                val states = endOutcome.flow_end_states()?.flow_end_state().orEmpty().map { state ->
                    buildMap()
                        .with("aggregate", getText(state.flow_view_aggregate()))
                        .with("values", state.flow_end_state_value().keyword().map { it.text })
                }
                val path = "flows.$flowName.end.outcomes[${outcomes.size}]"
                model.setLocation(path, getLocations(endOutcome))
                outcomes.add(buildMap()
                    .with("name", outcomeName)
                    .with("events", outcomeEvents)
                    .with("states", states))
            } catch (e: Exception) {
                // an outcome line still being typed: the others keep their place
                model.addProblem("flows.$flowName.end.outcomes[${outcomes.size}]", endOutcome.text, "Incomplete end outcome")
            }
        }

        currentStack.last().appendToWithMap("endOutcomes", endOutcomes)
        currentStack.last()["outcomes"] = outcomes
    }

    private fun getOutcomeEvents(ctx: ZflParser.Flow_end_outcome_listContext?): List<String>? {
        if (ctx == null) return null
        return getArray(ctx, ",")
    }

    private fun getOrCreateAction(
        flow: MutableMap<String, Any?>,
        actionName: String?,
        jd: String?
    ): MutableMap<String, Any?> {
        @Suppress("UNCHECKED_CAST")
        val actions = flow.getOrPut("actions") { buildMap() } as MutableMap<String, Any?>
        val existing = actions[actionName] as? MutableMap<String, Any?>
        if (existing != null) {
            if (jd != null && existing["javadoc"] == null) {
                existing["javadoc"] = jd
            }
            return existing
        }

        val action = buildMap()
            .with("name", actionName)
            .with("className", camelCase(actionName ?: ""))
            .with("javadoc", jd)
            .with("options", buildMap())
            .with("steps", mutableListOf<Any?>())
            .with("emits", mutableListOf<Any?>())
            .with("emissions", mutableListOf<Any?>())
            .with("responses", mutableListOf<Any?>())
            .with("responseDetails", mutableListOf<Any?>())
            .with("occurrences", mutableListOf<Any?>())

        actions[actionName ?: ""] = action
        return action
    }

    private fun createOccurrence(
        flow: MutableMap<String, Any?>,
        actionName: String?,
        description: String?,
        triggers: List<String>,
        options: MutableMap<String, Any?>,
        definition: Boolean,
        locations: IntArray?,
        annotations: ZflParser.AnnotationsContext? = null,
        baseKey: String? = null,
    ): MutableMap<String, Any?> {
        val action = getOrCreateAction(flow, actionName, description)
        @Suppress("UNCHECKED_CAST")
        val occurrences = action["occurrences"] as MutableList<Any?>
        val baseKey = baseKey ?: if (definition) {
            "$actionName@definition"
        } else {
            "$actionName@when[${triggers.sorted().joinToString(",")}]"
        }
        val duplicate = occurrences.count {
            val key = (it as? Map<*, *>)?.get("occurrenceKey")?.toString().orEmpty()
            key == baseKey || key.startsWith("$baseKey#")
        }
        val key = if (duplicate == 0) baseKey else "$baseKey#${duplicate + 1}"
        val occurrenceIndex = (flow["occurrenceCount"] as? Int) ?: 0
        flow["occurrenceCount"] = occurrenceIndex + 1
        val locationPath = "flows.${flow["name"]}.actions.$actionName.occurrences[${occurrences.size}]"
        val occurrence = buildMap()
            .with("name", actionName)
            .with("javadoc", description)
            .with("triggers", triggers)
            .with("options", options)
            .with("rules", mutableListOf<Any?>())
            .with("occurrenceKey", key)
            .with("occurrenceIndex", occurrenceIndex)
            .with("definition", definition)
            .with("locationPath", locationPath)
            .with("steps", mutableListOf<Any?>())
            .with("emits", mutableListOf<Any?>())
            .with("emissions", mutableListOf<Any?>())
            .with("responses", mutableListOf<Any?>())
            .with("responseDetails", mutableListOf<Any?>())
        occurrences.add(occurrence)
        model.setLocation(locationPath, locations)
        addRuleNames(occurrence, locationPath, annotations)
        return occurrence
    }

    /** Names listed in `@rules(a, "b-c")`, each with the location of its token so a warning can point at the name. */
    @Suppress("UNCHECKED_CAST")
    private fun addRuleNames(occurrence: MutableMap<String, Any?>, locationPath: String, annotations: ZflParser.AnnotationsContext?) {
        val rules = occurrence["rules"] as MutableList<Any?>
        annotations?.option()?.filter { it.option_name().text == "@rules" }?.forEach { option ->
            val complex = option.option_value()?.complex_value() ?: return@forEach
            val simples = mutableListOf<ZflParser.SimpleContext>()
            complex.array_plain()?.simple()?.let { simples += it }
            complex.value()?.let { value ->
                value.simple()?.let { simples += it }
                value.array()?.value()?.forEach { item -> item.simple()?.let { simples += it } }
            }
            simples.forEach { simple ->
                val name = getValueText(simple)?.toString() ?: return@forEach
                val path = "$locationPath.rules[${rules.size}]"
                model.setLocation(path, getLocations(simple))
                rules.add(buildMap().with("name", name).with("locationPath", path))
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun mergeOccurrence(action: MutableMap<String, Any?>, occurrence: MutableMap<String, Any?>) {
        if (action["javadoc"] == null && occurrence["javadoc"] != null) action["javadoc"] = occurrence["javadoc"]
        listOf("system", "service", "servicePath").forEach { key ->
            if (action[key] == null && occurrence[key] != null) action[key] = occurrence[key]
        }
        (action["options"] as MutableMap<String, Any?>).putAll(occurrence["options"] as Map<String, Any?>)
        for (key in listOf("steps", "emits", "emissions", "responses", "responseDetails")) {
            val target = action[key] as MutableList<Any?>
            val source = occurrence[key] as List<Any?>
            source.forEach { if (it !in target) target.add(it) }
        }
    }

    private fun appendStep(action: MutableMap<String, Any?>, step: MutableMap<String, Any?>) {
        @Suppress("UNCHECKED_CAST")
        (action["steps"] as MutableList<Any?>).add(step)
    }

    private fun registerCommand(systemName: String, serviceName: String, commandName: String?) {
        val systems = model.getOrPut("systems") { mutableMapOf<String, Any>() } as MutableMap<String, Any>
        val system = systems.getOrPut(systemName) {
            buildMap()
                .with("name", systemName)
                .with("services", buildMap())
        } as MutableMap<String, Any>
        val services = system.getOrPut("services") { mutableMapOf<String, Any>() } as MutableMap<String, Any>
        val service = services.getOrPut(serviceName) {
            buildMap()
                .with("name", serviceName)
                .with("commands", mutableSetOf<Any?>())
        } as MutableMap<String, Any>
        @Suppress("UNCHECKED_CAST")
        (service.getOrPut("commands") { mutableSetOf<Any?>() } as MutableCollection<Any?>).add(commandName)
    }

    override fun exitEveryRule(ctx: ParserRuleContext) {
        super.exitEveryRule(ctx)
    }

    override fun visitTerminal(node: TerminalNode) {
        super.visitTerminal(node)
    }

    override fun visitErrorNode(node: ErrorNode) {
        super.visitErrorNode(node)
    }
}

