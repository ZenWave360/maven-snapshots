// Generated from /home/runner/work/dsl-kotlin/dsl-kotlin/dsl-kotlin/src/commonMain/antlr/io.zenwave360.language.antlr/Zfl.g4 by ANTLR 4.13.1
package io.zenwave360.language.antlr

import org.antlr.v4.kotlinruntime.ParserRuleContext
import org.antlr.v4.kotlinruntime.tree.ErrorNode
import org.antlr.v4.kotlinruntime.tree.TerminalNode

/**
 * This class provides an empty implementation of [ZflListener],
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
public open class ZflBaseListener : ZflListener {
    /**
     * The default implementation does nothing.
     */
    override fun enterZfl(ctx: ZflParser.ZflContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitZfl(ctx: ZflParser.ZflContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterImport_(ctx: ZflParser.Import_Context) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitImport_(ctx: ZflParser.Import_Context) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterImport_key(ctx: ZflParser.Import_keyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitImport_key(ctx: ZflParser.Import_keyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterImport_value(ctx: ZflParser.Import_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitImport_value(ctx: ZflParser.Import_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterGlobal_javadoc(ctx: ZflParser.Global_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitGlobal_javadoc(ctx: ZflParser.Global_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterJavadoc(ctx: ZflParser.JavadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitJavadoc(ctx: ZflParser.JavadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSuffix_javadoc(ctx: ZflParser.Suffix_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSuffix_javadoc(ctx: ZflParser.Suffix_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterKeyword(ctx: ZflParser.KeywordContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitKeyword(ctx: ZflParser.KeywordContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterComplex_value(ctx: ZflParser.Complex_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitComplex_value(ctx: ZflParser.Complex_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterValue(ctx: ZflParser.ValueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitValue(ctx: ZflParser.ValueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterString(ctx: ZflParser.StringContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitString(ctx: ZflParser.StringContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSimple(ctx: ZflParser.SimpleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSimple(ctx: ZflParser.SimpleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterObject(ctx: ZflParser.ObjectContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitObject(ctx: ZflParser.ObjectContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPair(ctx: ZflParser.PairContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPair(ctx: ZflParser.PairContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterArray(ctx: ZflParser.ArrayContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitArray(ctx: ZflParser.ArrayContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterArray_plain(ctx: ZflParser.Array_plainContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitArray_plain(ctx: ZflParser.Array_plainContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPairs(ctx: ZflParser.PairsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPairs(ctx: ZflParser.PairsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFields(ctx: ZflParser.FieldsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFields(ctx: ZflParser.FieldsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField(ctx: ZflParser.FieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField(ctx: ZflParser.FieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_name(ctx: ZflParser.Field_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_name(ctx: ZflParser.Field_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_type(ctx: ZflParser.Field_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_type(ctx: ZflParser.Field_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig(ctx: ZflParser.ConfigContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig(ctx: ZflParser.ConfigContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig_body(ctx: ZflParser.Config_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig_body(ctx: ZflParser.Config_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig_option(ctx: ZflParser.Config_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig_option(ctx: ZflParser.Config_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAnnotations(ctx: ZflParser.AnnotationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAnnotations(ctx: ZflParser.AnnotationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOption(ctx: ZflParser.OptionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOption(ctx: ZflParser.OptionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOption_name(ctx: ZflParser.Option_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOption_name(ctx: ZflParser.Option_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOption_value(ctx: ZflParser.Option_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOption_value(ctx: ZflParser.Option_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystems(ctx: ZflParser.SystemsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystems(ctx: ZflParser.SystemsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem(ctx: ZflParser.SystemContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem(ctx: ZflParser.SystemContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_name(ctx: ZflParser.System_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_name(ctx: ZflParser.System_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_body(ctx: ZflParser.System_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_body(ctx: ZflParser.System_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_services(ctx: ZflParser.System_servicesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_services(ctx: ZflParser.System_servicesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_service(ctx: ZflParser.System_serviceContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_service(ctx: ZflParser.System_serviceContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_service_name(ctx: ZflParser.System_service_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_service_name(ctx: ZflParser.System_service_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_service_aggregates(ctx: ZflParser.System_service_aggregatesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_service_aggregates(ctx: ZflParser.System_service_aggregatesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_service_body(ctx: ZflParser.System_service_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_service_body(ctx: ZflParser.System_service_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSystem_service_command_list(ctx: ZflParser.System_service_command_listContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSystem_service_command_list(ctx: ZflParser.System_service_command_listContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow(ctx: ZflParser.FlowContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow(ctx: ZflParser.FlowContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_name(ctx: ZflParser.Flow_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_name(ctx: ZflParser.Flow_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_body(ctx: ZflParser.Flow_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_body(ctx: ZflParser.Flow_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_start(ctx: ZflParser.Flow_startContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_start(ctx: ZflParser.Flow_startContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_start_name(ctx: ZflParser.Flow_start_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_start_name(ctx: ZflParser.Flow_start_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_when(ctx: ZflParser.Flow_whenContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_when(ctx: ZflParser.Flow_whenContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_when_trigger(ctx: ZflParser.Flow_when_triggerContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_when_trigger(ctx: ZflParser.Flow_when_triggerContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_when_trigger_group(ctx: ZflParser.Flow_when_trigger_groupContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_when_trigger_group(ctx: ZflParser.Flow_when_trigger_groupContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_when_event_trigger(ctx: ZflParser.Flow_when_event_triggerContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_when_event_trigger(ctx: ZflParser.Flow_when_event_triggerContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_command_name(ctx: ZflParser.Flow_command_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_command_name(ctx: ZflParser.Flow_command_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do(ctx: ZflParser.Flow_doContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do(ctx: ZflParser.Flow_doContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do_body(ctx: ZflParser.Flow_do_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do_body(ctx: ZflParser.Flow_do_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do_statement(ctx: ZflParser.Flow_do_statementContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do_statement(ctx: ZflParser.Flow_do_statementContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do_service(ctx: ZflParser.Flow_do_serviceContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do_service(ctx: ZflParser.Flow_do_serviceContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do_call(ctx: ZflParser.Flow_do_callContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do_call(ctx: ZflParser.Flow_do_callContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do_on(ctx: ZflParser.Flow_do_onContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do_on(ctx: ZflParser.Flow_do_onContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_do_signal(ctx: ZflParser.Flow_do_signalContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_do_signal(ctx: ZflParser.Flow_do_signalContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_signal_body(ctx: ZflParser.Flow_signal_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_signal_body(ctx: ZflParser.Flow_signal_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_event_list(ctx: ZflParser.Flow_event_listContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_event_list(ctx: ZflParser.Flow_event_listContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_service_path(ctx: ZflParser.Flow_service_pathContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_service_path(ctx: ZflParser.Flow_service_pathContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_service_segment(ctx: ZflParser.Flow_service_segmentContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_service_segment(ctx: ZflParser.Flow_service_segmentContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_event_name(ctx: ZflParser.Flow_event_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_event_name(ctx: ZflParser.Flow_event_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_end(ctx: ZflParser.Flow_endContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_end(ctx: ZflParser.Flow_endContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_end_outcomes(ctx: ZflParser.Flow_end_outcomesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_end_outcomes(ctx: ZflParser.Flow_end_outcomesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_end_outcome(ctx: ZflParser.Flow_end_outcomeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_end_outcome(ctx: ZflParser.Flow_end_outcomeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_end_outcome_name(ctx: ZflParser.Flow_end_outcome_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_end_outcome_name(ctx: ZflParser.Flow_end_outcome_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_end_outcome_list(ctx: ZflParser.Flow_end_outcome_listContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_end_outcome_list(ctx: ZflParser.Flow_end_outcome_listContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFlow_end_outcome_event(ctx: ZflParser.Flow_end_outcome_eventContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFlow_end_outcome_event(ctx: ZflParser.Flow_end_outcome_eventContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEveryRule(ctx: ParserRuleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEveryRule(ctx: ParserRuleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun visitTerminal(node: TerminalNode) {}

    /**
     * The default implementation does nothing.
     */
    override fun visitErrorNode(node: ErrorNode) {}
}
