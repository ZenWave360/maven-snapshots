// Generated from /home/runner/work/dsl-kotlin/dsl-kotlin/dsl-kotlin/src/commonMain/antlr/io.zenwave360.language.antlr/Zfl.g4 by ANTLR 4.13.1
package io.zenwave360.language.antlr

import org.antlr.v4.kotlinruntime.tree.ParseTreeListener

/**
 * This interface defines a complete listener for a parse tree produced by [ZflParser].
 */
public interface ZflListener : ParseTreeListener {
    /**
     * Enter a parse tree produced by [ZflParser.zfl].
     *
     * @param ctx The parse tree
     */
    public fun enterZfl(ctx: ZflParser.ZflContext)

    /**
     * Exit a parse tree produced by [ZflParser.zfl].
     *
     * @param ctx The parse tree
     */
    public fun exitZfl(ctx: ZflParser.ZflContext)

    /**
     * Enter a parse tree produced by [ZflParser.import_].
     *
     * @param ctx The parse tree
     */
    public fun enterImport_(ctx: ZflParser.Import_Context)

    /**
     * Exit a parse tree produced by [ZflParser.import_].
     *
     * @param ctx The parse tree
     */
    public fun exitImport_(ctx: ZflParser.Import_Context)

    /**
     * Enter a parse tree produced by [ZflParser.import_key].
     *
     * @param ctx The parse tree
     */
    public fun enterImport_key(ctx: ZflParser.Import_keyContext)

    /**
     * Exit a parse tree produced by [ZflParser.import_key].
     *
     * @param ctx The parse tree
     */
    public fun exitImport_key(ctx: ZflParser.Import_keyContext)

    /**
     * Enter a parse tree produced by [ZflParser.import_value].
     *
     * @param ctx The parse tree
     */
    public fun enterImport_value(ctx: ZflParser.Import_valueContext)

    /**
     * Exit a parse tree produced by [ZflParser.import_value].
     *
     * @param ctx The parse tree
     */
    public fun exitImport_value(ctx: ZflParser.Import_valueContext)

    /**
     * Enter a parse tree produced by [ZflParser.global_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun enterGlobal_javadoc(ctx: ZflParser.Global_javadocContext)

    /**
     * Exit a parse tree produced by [ZflParser.global_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun exitGlobal_javadoc(ctx: ZflParser.Global_javadocContext)

    /**
     * Enter a parse tree produced by [ZflParser.javadoc].
     *
     * @param ctx The parse tree
     */
    public fun enterJavadoc(ctx: ZflParser.JavadocContext)

    /**
     * Exit a parse tree produced by [ZflParser.javadoc].
     *
     * @param ctx The parse tree
     */
    public fun exitJavadoc(ctx: ZflParser.JavadocContext)

    /**
     * Enter a parse tree produced by [ZflParser.suffix_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun enterSuffix_javadoc(ctx: ZflParser.Suffix_javadocContext)

    /**
     * Exit a parse tree produced by [ZflParser.suffix_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun exitSuffix_javadoc(ctx: ZflParser.Suffix_javadocContext)

    /**
     * Enter a parse tree produced by [ZflParser.keyword].
     *
     * @param ctx The parse tree
     */
    public fun enterKeyword(ctx: ZflParser.KeywordContext)

    /**
     * Exit a parse tree produced by [ZflParser.keyword].
     *
     * @param ctx The parse tree
     */
    public fun exitKeyword(ctx: ZflParser.KeywordContext)

    /**
     * Enter a parse tree produced by [ZflParser.complex_value].
     *
     * @param ctx The parse tree
     */
    public fun enterComplex_value(ctx: ZflParser.Complex_valueContext)

    /**
     * Exit a parse tree produced by [ZflParser.complex_value].
     *
     * @param ctx The parse tree
     */
    public fun exitComplex_value(ctx: ZflParser.Complex_valueContext)

    /**
     * Enter a parse tree produced by [ZflParser.value].
     *
     * @param ctx The parse tree
     */
    public fun enterValue(ctx: ZflParser.ValueContext)

    /**
     * Exit a parse tree produced by [ZflParser.value].
     *
     * @param ctx The parse tree
     */
    public fun exitValue(ctx: ZflParser.ValueContext)

    /**
     * Enter a parse tree produced by [ZflParser.string].
     *
     * @param ctx The parse tree
     */
    public fun enterString(ctx: ZflParser.StringContext)

    /**
     * Exit a parse tree produced by [ZflParser.string].
     *
     * @param ctx The parse tree
     */
    public fun exitString(ctx: ZflParser.StringContext)

    /**
     * Enter a parse tree produced by [ZflParser.simple].
     *
     * @param ctx The parse tree
     */
    public fun enterSimple(ctx: ZflParser.SimpleContext)

    /**
     * Exit a parse tree produced by [ZflParser.simple].
     *
     * @param ctx The parse tree
     */
    public fun exitSimple(ctx: ZflParser.SimpleContext)

    /**
     * Enter a parse tree produced by [ZflParser.object].
     *
     * @param ctx The parse tree
     */
    public fun enterObject(ctx: ZflParser.ObjectContext)

    /**
     * Exit a parse tree produced by [ZflParser.object].
     *
     * @param ctx The parse tree
     */
    public fun exitObject(ctx: ZflParser.ObjectContext)

    /**
     * Enter a parse tree produced by [ZflParser.pair].
     *
     * @param ctx The parse tree
     */
    public fun enterPair(ctx: ZflParser.PairContext)

    /**
     * Exit a parse tree produced by [ZflParser.pair].
     *
     * @param ctx The parse tree
     */
    public fun exitPair(ctx: ZflParser.PairContext)

    /**
     * Enter a parse tree produced by [ZflParser.array].
     *
     * @param ctx The parse tree
     */
    public fun enterArray(ctx: ZflParser.ArrayContext)

    /**
     * Exit a parse tree produced by [ZflParser.array].
     *
     * @param ctx The parse tree
     */
    public fun exitArray(ctx: ZflParser.ArrayContext)

    /**
     * Enter a parse tree produced by [ZflParser.array_plain].
     *
     * @param ctx The parse tree
     */
    public fun enterArray_plain(ctx: ZflParser.Array_plainContext)

    /**
     * Exit a parse tree produced by [ZflParser.array_plain].
     *
     * @param ctx The parse tree
     */
    public fun exitArray_plain(ctx: ZflParser.Array_plainContext)

    /**
     * Enter a parse tree produced by [ZflParser.pairs].
     *
     * @param ctx The parse tree
     */
    public fun enterPairs(ctx: ZflParser.PairsContext)

    /**
     * Exit a parse tree produced by [ZflParser.pairs].
     *
     * @param ctx The parse tree
     */
    public fun exitPairs(ctx: ZflParser.PairsContext)

    /**
     * Enter a parse tree produced by [ZflParser.fields].
     *
     * @param ctx The parse tree
     */
    public fun enterFields(ctx: ZflParser.FieldsContext)

    /**
     * Exit a parse tree produced by [ZflParser.fields].
     *
     * @param ctx The parse tree
     */
    public fun exitFields(ctx: ZflParser.FieldsContext)

    /**
     * Enter a parse tree produced by [ZflParser.field].
     *
     * @param ctx The parse tree
     */
    public fun enterField(ctx: ZflParser.FieldContext)

    /**
     * Exit a parse tree produced by [ZflParser.field].
     *
     * @param ctx The parse tree
     */
    public fun exitField(ctx: ZflParser.FieldContext)

    /**
     * Enter a parse tree produced by [ZflParser.field_name].
     *
     * @param ctx The parse tree
     */
    public fun enterField_name(ctx: ZflParser.Field_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.field_name].
     *
     * @param ctx The parse tree
     */
    public fun exitField_name(ctx: ZflParser.Field_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.field_type].
     *
     * @param ctx The parse tree
     */
    public fun enterField_type(ctx: ZflParser.Field_typeContext)

    /**
     * Exit a parse tree produced by [ZflParser.field_type].
     *
     * @param ctx The parse tree
     */
    public fun exitField_type(ctx: ZflParser.Field_typeContext)

    /**
     * Enter a parse tree produced by [ZflParser.config].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig(ctx: ZflParser.ConfigContext)

    /**
     * Exit a parse tree produced by [ZflParser.config].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig(ctx: ZflParser.ConfigContext)

    /**
     * Enter a parse tree produced by [ZflParser.config_body].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig_body(ctx: ZflParser.Config_bodyContext)

    /**
     * Exit a parse tree produced by [ZflParser.config_body].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig_body(ctx: ZflParser.Config_bodyContext)

    /**
     * Enter a parse tree produced by [ZflParser.config_option].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig_option(ctx: ZflParser.Config_optionContext)

    /**
     * Exit a parse tree produced by [ZflParser.config_option].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig_option(ctx: ZflParser.Config_optionContext)

    /**
     * Enter a parse tree produced by [ZflParser.annotations].
     *
     * @param ctx The parse tree
     */
    public fun enterAnnotations(ctx: ZflParser.AnnotationsContext)

    /**
     * Exit a parse tree produced by [ZflParser.annotations].
     *
     * @param ctx The parse tree
     */
    public fun exitAnnotations(ctx: ZflParser.AnnotationsContext)

    /**
     * Enter a parse tree produced by [ZflParser.option].
     *
     * @param ctx The parse tree
     */
    public fun enterOption(ctx: ZflParser.OptionContext)

    /**
     * Exit a parse tree produced by [ZflParser.option].
     *
     * @param ctx The parse tree
     */
    public fun exitOption(ctx: ZflParser.OptionContext)

    /**
     * Enter a parse tree produced by [ZflParser.option_name].
     *
     * @param ctx The parse tree
     */
    public fun enterOption_name(ctx: ZflParser.Option_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.option_name].
     *
     * @param ctx The parse tree
     */
    public fun exitOption_name(ctx: ZflParser.Option_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.option_value].
     *
     * @param ctx The parse tree
     */
    public fun enterOption_value(ctx: ZflParser.Option_valueContext)

    /**
     * Exit a parse tree produced by [ZflParser.option_value].
     *
     * @param ctx The parse tree
     */
    public fun exitOption_value(ctx: ZflParser.Option_valueContext)

    /**
     * Enter a parse tree produced by [ZflParser.systems].
     *
     * @param ctx The parse tree
     */
    public fun enterSystems(ctx: ZflParser.SystemsContext)

    /**
     * Exit a parse tree produced by [ZflParser.systems].
     *
     * @param ctx The parse tree
     */
    public fun exitSystems(ctx: ZflParser.SystemsContext)

    /**
     * Enter a parse tree produced by [ZflParser.system].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem(ctx: ZflParser.SystemContext)

    /**
     * Exit a parse tree produced by [ZflParser.system].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem(ctx: ZflParser.SystemContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_name].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_name(ctx: ZflParser.System_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_name].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_name(ctx: ZflParser.System_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_body].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_body(ctx: ZflParser.System_bodyContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_body].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_body(ctx: ZflParser.System_bodyContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_services].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_services(ctx: ZflParser.System_servicesContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_services].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_services(ctx: ZflParser.System_servicesContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_service].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_service(ctx: ZflParser.System_serviceContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_service].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_service(ctx: ZflParser.System_serviceContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_service_name].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_service_name(ctx: ZflParser.System_service_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_service_name].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_service_name(ctx: ZflParser.System_service_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_service_aggregates].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_service_aggregates(ctx: ZflParser.System_service_aggregatesContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_service_aggregates].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_service_aggregates(ctx: ZflParser.System_service_aggregatesContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_service_body].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_service_body(ctx: ZflParser.System_service_bodyContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_service_body].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_service_body(ctx: ZflParser.System_service_bodyContext)

    /**
     * Enter a parse tree produced by [ZflParser.system_service_command_list].
     *
     * @param ctx The parse tree
     */
    public fun enterSystem_service_command_list(ctx: ZflParser.System_service_command_listContext)

    /**
     * Exit a parse tree produced by [ZflParser.system_service_command_list].
     *
     * @param ctx The parse tree
     */
    public fun exitSystem_service_command_list(ctx: ZflParser.System_service_command_listContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow(ctx: ZflParser.FlowContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow(ctx: ZflParser.FlowContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_name].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_name(ctx: ZflParser.Flow_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_name].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_name(ctx: ZflParser.Flow_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_body].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_body(ctx: ZflParser.Flow_bodyContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_body].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_body(ctx: ZflParser.Flow_bodyContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_start].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_start(ctx: ZflParser.Flow_startContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_start].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_start(ctx: ZflParser.Flow_startContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_start_name].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_start_name(ctx: ZflParser.Flow_start_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_start_name].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_start_name(ctx: ZflParser.Flow_start_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_when].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_when(ctx: ZflParser.Flow_whenContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_when].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_when(ctx: ZflParser.Flow_whenContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_when_trigger].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_when_trigger(ctx: ZflParser.Flow_when_triggerContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_when_trigger].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_when_trigger(ctx: ZflParser.Flow_when_triggerContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_when_trigger_group].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_when_trigger_group(ctx: ZflParser.Flow_when_trigger_groupContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_when_trigger_group].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_when_trigger_group(ctx: ZflParser.Flow_when_trigger_groupContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_when_event_trigger].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_when_event_trigger(ctx: ZflParser.Flow_when_event_triggerContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_when_event_trigger].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_when_event_trigger(ctx: ZflParser.Flow_when_event_triggerContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_command_name].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_command_name(ctx: ZflParser.Flow_command_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_command_name].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_command_name(ctx: ZflParser.Flow_command_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do(ctx: ZflParser.Flow_doContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do(ctx: ZflParser.Flow_doContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do_body].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do_body(ctx: ZflParser.Flow_do_bodyContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do_body].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do_body(ctx: ZflParser.Flow_do_bodyContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do_statement].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do_statement(ctx: ZflParser.Flow_do_statementContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do_statement].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do_statement(ctx: ZflParser.Flow_do_statementContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do_service].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do_service(ctx: ZflParser.Flow_do_serviceContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do_service].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do_service(ctx: ZflParser.Flow_do_serviceContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do_call].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do_call(ctx: ZflParser.Flow_do_callContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do_call].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do_call(ctx: ZflParser.Flow_do_callContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do_on].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do_on(ctx: ZflParser.Flow_do_onContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do_on].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do_on(ctx: ZflParser.Flow_do_onContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_do_signal].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_do_signal(ctx: ZflParser.Flow_do_signalContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_do_signal].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_do_signal(ctx: ZflParser.Flow_do_signalContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_signal_body].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_signal_body(ctx: ZflParser.Flow_signal_bodyContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_signal_body].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_signal_body(ctx: ZflParser.Flow_signal_bodyContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_event_list].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_event_list(ctx: ZflParser.Flow_event_listContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_event_list].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_event_list(ctx: ZflParser.Flow_event_listContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_service_path].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_service_path(ctx: ZflParser.Flow_service_pathContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_service_path].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_service_path(ctx: ZflParser.Flow_service_pathContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_service_segment].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_service_segment(ctx: ZflParser.Flow_service_segmentContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_service_segment].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_service_segment(ctx: ZflParser.Flow_service_segmentContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_event_name].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_event_name(ctx: ZflParser.Flow_event_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_event_name].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_event_name(ctx: ZflParser.Flow_event_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_end].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_end(ctx: ZflParser.Flow_endContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_end].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_end(ctx: ZflParser.Flow_endContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_end_outcomes].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_end_outcomes(ctx: ZflParser.Flow_end_outcomesContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_end_outcomes].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_end_outcomes(ctx: ZflParser.Flow_end_outcomesContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_end_outcome].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_end_outcome(ctx: ZflParser.Flow_end_outcomeContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_end_outcome].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_end_outcome(ctx: ZflParser.Flow_end_outcomeContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_end_outcome_name].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_end_outcome_name(ctx: ZflParser.Flow_end_outcome_nameContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_end_outcome_name].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_end_outcome_name(ctx: ZflParser.Flow_end_outcome_nameContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_end_outcome_list].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_end_outcome_list(ctx: ZflParser.Flow_end_outcome_listContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_end_outcome_list].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_end_outcome_list(ctx: ZflParser.Flow_end_outcome_listContext)

    /**
     * Enter a parse tree produced by [ZflParser.flow_end_outcome_event].
     *
     * @param ctx The parse tree
     */
    public fun enterFlow_end_outcome_event(ctx: ZflParser.Flow_end_outcome_eventContext)

    /**
     * Exit a parse tree produced by [ZflParser.flow_end_outcome_event].
     *
     * @param ctx The parse tree
     */
    public fun exitFlow_end_outcome_event(ctx: ZflParser.Flow_end_outcome_eventContext)

}
