// Generated from /home/runner/work/dsl-kotlin/dsl-kotlin/dsl-kotlin/src/commonMain/antlr/io.zenwave360.language.antlr/Zdl.g4 by ANTLR 4.13.1
package io.zenwave360.language.antlr

import org.antlr.v4.kotlinruntime.ParserRuleContext
import org.antlr.v4.kotlinruntime.tree.ErrorNode
import org.antlr.v4.kotlinruntime.tree.TerminalNode

/**
 * This class provides an empty implementation of [ZdlListener],
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
public open class ZdlBaseListener : ZdlListener {
    /**
     * The default implementation does nothing.
     */
    override fun enterZdl(ctx: ZdlParser.ZdlContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitZdl(ctx: ZdlParser.ZdlContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterImport_(ctx: ZdlParser.Import_Context) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitImport_(ctx: ZdlParser.Import_Context) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterImport_key(ctx: ZdlParser.Import_keyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitImport_key(ctx: ZdlParser.Import_keyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterImport_value(ctx: ZdlParser.Import_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitImport_value(ctx: ZdlParser.Import_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterGlobal_javadoc(ctx: ZdlParser.Global_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitGlobal_javadoc(ctx: ZdlParser.Global_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterJavadoc(ctx: ZdlParser.JavadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitJavadoc(ctx: ZdlParser.JavadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSuffix_javadoc(ctx: ZdlParser.Suffix_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSuffix_javadoc(ctx: ZdlParser.Suffix_javadocContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterLegacy_constants(ctx: ZdlParser.Legacy_constantsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitLegacy_constants(ctx: ZdlParser.Legacy_constantsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterKeyword(ctx: ZdlParser.KeywordContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitKeyword(ctx: ZdlParser.KeywordContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterComplex_value(ctx: ZdlParser.Complex_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitComplex_value(ctx: ZdlParser.Complex_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterValue(ctx: ZdlParser.ValueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitValue(ctx: ZdlParser.ValueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterString(ctx: ZdlParser.StringContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitString(ctx: ZdlParser.StringContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterSimple(ctx: ZdlParser.SimpleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitSimple(ctx: ZdlParser.SimpleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterObject(ctx: ZdlParser.ObjectContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitObject(ctx: ZdlParser.ObjectContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPair(ctx: ZdlParser.PairContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPair(ctx: ZdlParser.PairContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterArray(ctx: ZdlParser.ArrayContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitArray(ctx: ZdlParser.ArrayContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterArray_plain(ctx: ZdlParser.Array_plainContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitArray_plain(ctx: ZdlParser.Array_plainContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPairs(ctx: ZdlParser.PairsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPairs(ctx: ZdlParser.PairsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig(ctx: ZdlParser.ConfigContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig(ctx: ZdlParser.ConfigContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig_body(ctx: ZdlParser.Config_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig_body(ctx: ZdlParser.Config_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig_entry(ctx: ZdlParser.Config_entryContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig_entry(ctx: ZdlParser.Config_entryContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig_option(ctx: ZdlParser.Config_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig_option(ctx: ZdlParser.Config_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterConfig_cli_option(ctx: ZdlParser.Config_cli_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitConfig_cli_option(ctx: ZdlParser.Config_cli_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApis(ctx: ZdlParser.ApisContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApis(ctx: ZdlParser.ApisContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApis_body(ctx: ZdlParser.Apis_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApis_body(ctx: ZdlParser.Apis_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi(ctx: ZdlParser.ApiContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi(ctx: ZdlParser.ApiContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_type(ctx: ZdlParser.Api_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_type(ctx: ZdlParser.Api_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_role(ctx: ZdlParser.Api_roleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_role(ctx: ZdlParser.Api_roleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_name(ctx: ZdlParser.Api_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_name(ctx: ZdlParser.Api_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_uri(ctx: ZdlParser.Api_uriContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_uri(ctx: ZdlParser.Api_uriContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_body(ctx: ZdlParser.Api_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_body(ctx: ZdlParser.Api_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_configs(ctx: ZdlParser.Api_configsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_configs(ctx: ZdlParser.Api_configsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterApi_config(ctx: ZdlParser.Api_configContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitApi_config(ctx: ZdlParser.Api_configContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugins(ctx: ZdlParser.PluginsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugins(ctx: ZdlParser.PluginsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugins_body(ctx: ZdlParser.Plugins_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugins_body(ctx: ZdlParser.Plugins_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin(ctx: ZdlParser.PluginContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin(ctx: ZdlParser.PluginContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_disabled(ctx: ZdlParser.Plugin_disabledContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_disabled(ctx: ZdlParser.Plugin_disabledContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_name(ctx: ZdlParser.Plugin_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_name(ctx: ZdlParser.Plugin_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_options(ctx: ZdlParser.Plugin_optionsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_options(ctx: ZdlParser.Plugin_optionsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_options_inherit(ctx: ZdlParser.Plugin_options_inheritContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_options_inherit(ctx: ZdlParser.Plugin_options_inheritContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_body(ctx: ZdlParser.Plugin_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_body(ctx: ZdlParser.Plugin_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_configs(ctx: ZdlParser.Plugin_configsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_configs(ctx: ZdlParser.Plugin_configsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_config(ctx: ZdlParser.Plugin_configContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_config(ctx: ZdlParser.Plugin_configContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_config_option(ctx: ZdlParser.Plugin_config_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_config_option(ctx: ZdlParser.Plugin_config_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPlugin_config_cli_option(ctx: ZdlParser.Plugin_config_cli_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPlugin_config_cli_option(ctx: ZdlParser.Plugin_config_cli_optionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPolicies(ctx: ZdlParser.PoliciesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPolicies(ctx: ZdlParser.PoliciesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPolicy_aggregate(ctx: ZdlParser.Policy_aggregateContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPolicy_aggregate(ctx: ZdlParser.Policy_aggregateContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPolicies_body(ctx: ZdlParser.Policies_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPolicies_body(ctx: ZdlParser.Policies_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPolicie_body(ctx: ZdlParser.Policie_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPolicie_body(ctx: ZdlParser.Policie_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPolicie_name(ctx: ZdlParser.Policie_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPolicie_name(ctx: ZdlParser.Policie_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterPolicie_value(ctx: ZdlParser.Policie_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitPolicie_value(ctx: ZdlParser.Policie_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAnnotations(ctx: ZdlParser.AnnotationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAnnotations(ctx: ZdlParser.AnnotationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOption(ctx: ZdlParser.OptionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOption(ctx: ZdlParser.OptionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOption_name(ctx: ZdlParser.Option_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOption_name(ctx: ZdlParser.Option_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOption_value(ctx: ZdlParser.Option_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOption_value(ctx: ZdlParser.Option_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEntity(ctx: ZdlParser.EntityContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEntity(ctx: ZdlParser.EntityContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEntity_definition(ctx: ZdlParser.Entity_definitionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEntity_definition(ctx: ZdlParser.Entity_definitionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEntity_name(ctx: ZdlParser.Entity_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEntity_name(ctx: ZdlParser.Entity_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEntity_table_name(ctx: ZdlParser.Entity_table_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEntity_table_name(ctx: ZdlParser.Entity_table_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEntity_body(ctx: ZdlParser.Entity_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEntity_body(ctx: ZdlParser.Entity_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterFields(ctx: ZdlParser.FieldsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitFields(ctx: ZdlParser.FieldsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField(ctx: ZdlParser.FieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField(ctx: ZdlParser.FieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterNested_field(ctx: ZdlParser.Nested_fieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitNested_field(ctx: ZdlParser.Nested_fieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_name(ctx: ZdlParser.Field_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_name(ctx: ZdlParser.Field_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_type(ctx: ZdlParser.Field_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_type(ctx: ZdlParser.Field_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_initialization(ctx: ZdlParser.Field_initializationContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_initialization(ctx: ZdlParser.Field_initializationContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_initial_value(ctx: ZdlParser.Field_initial_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_initial_value(ctx: ZdlParser.Field_initial_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_validations(ctx: ZdlParser.Field_validationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_validations(ctx: ZdlParser.Field_validationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_validation_name(ctx: ZdlParser.Field_validation_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_validation_name(ctx: ZdlParser.Field_validation_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterField_validation_value(ctx: ZdlParser.Field_validation_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitField_validation_value(ctx: ZdlParser.Field_validation_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterNested_field_validations(ctx: ZdlParser.Nested_field_validationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitNested_field_validations(ctx: ZdlParser.Nested_field_validationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterNested_field_validation_name(ctx: ZdlParser.Nested_field_validation_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitNested_field_validation_name(ctx: ZdlParser.Nested_field_validation_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterNested_field_validation_value(ctx: ZdlParser.Nested_field_validation_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitNested_field_validation_value(ctx: ZdlParser.Nested_field_validation_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEnum(ctx: ZdlParser.EnumContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEnum(ctx: ZdlParser.EnumContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEnum_name(ctx: ZdlParser.Enum_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEnum_name(ctx: ZdlParser.Enum_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEnum_body(ctx: ZdlParser.Enum_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEnum_body(ctx: ZdlParser.Enum_bodyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEnum_value(ctx: ZdlParser.Enum_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEnum_value(ctx: ZdlParser.Enum_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEnum_value_name(ctx: ZdlParser.Enum_value_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEnum_value_name(ctx: ZdlParser.Enum_value_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEnum_value_value(ctx: ZdlParser.Enum_value_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEnum_value_value(ctx: ZdlParser.Enum_value_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterInput(ctx: ZdlParser.InputContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitInput(ctx: ZdlParser.InputContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterInput_name(ctx: ZdlParser.Input_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitInput_name(ctx: ZdlParser.Input_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOutput(ctx: ZdlParser.OutputContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOutput(ctx: ZdlParser.OutputContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterOutput_name(ctx: ZdlParser.Output_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitOutput_name(ctx: ZdlParser.Output_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEvent(ctx: ZdlParser.EventContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEvent(ctx: ZdlParser.EventContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEvent_name(ctx: ZdlParser.Event_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEvent_name(ctx: ZdlParser.Event_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationships(ctx: ZdlParser.RelationshipsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationships(ctx: ZdlParser.RelationshipsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_type(ctx: ZdlParser.Relationship_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_type(ctx: ZdlParser.Relationship_typeContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship(ctx: ZdlParser.RelationshipContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship(ctx: ZdlParser.RelationshipContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_from(ctx: ZdlParser.Relationship_fromContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_from(ctx: ZdlParser.Relationship_fromContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_to(ctx: ZdlParser.Relationship_toContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_to(ctx: ZdlParser.Relationship_toContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_definition(ctx: ZdlParser.Relationship_definitionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_definition(ctx: ZdlParser.Relationship_definitionContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_entity_name(ctx: ZdlParser.Relationship_entity_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_entity_name(ctx: ZdlParser.Relationship_entity_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_field_name(ctx: ZdlParser.Relationship_field_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_field_name(ctx: ZdlParser.Relationship_field_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_description_field(ctx: ZdlParser.Relationship_description_fieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_description_field(ctx: ZdlParser.Relationship_description_fieldContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_field_validations(ctx: ZdlParser.Relationship_field_validationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_field_validations(ctx: ZdlParser.Relationship_field_validationsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_field_required(ctx: ZdlParser.Relationship_field_requiredContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_field_required(ctx: ZdlParser.Relationship_field_requiredContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_field_min(ctx: ZdlParser.Relationship_field_minContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_field_min(ctx: ZdlParser.Relationship_field_minContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_field_max(ctx: ZdlParser.Relationship_field_maxContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_field_max(ctx: ZdlParser.Relationship_field_maxContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterRelationship_field_value(ctx: ZdlParser.Relationship_field_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitRelationship_field_value(ctx: ZdlParser.Relationship_field_valueContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAggregate(ctx: ZdlParser.AggregateContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAggregate(ctx: ZdlParser.AggregateContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAggregate_name(ctx: ZdlParser.Aggregate_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAggregate_name(ctx: ZdlParser.Aggregate_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAggregate_root(ctx: ZdlParser.Aggregate_rootContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAggregate_root(ctx: ZdlParser.Aggregate_rootContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAggregate_command(ctx: ZdlParser.Aggregate_commandContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAggregate_command(ctx: ZdlParser.Aggregate_commandContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAggregate_command_name(ctx: ZdlParser.Aggregate_command_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAggregate_command_name(ctx: ZdlParser.Aggregate_command_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterAggregate_command_parameter(ctx: ZdlParser.Aggregate_command_parameterContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitAggregate_command_parameter(ctx: ZdlParser.Aggregate_command_parameterContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService(ctx: ZdlParser.ServiceContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService(ctx: ZdlParser.ServiceContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_name(ctx: ZdlParser.Service_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_name(ctx: ZdlParser.Service_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_aggregates(ctx: ZdlParser.Service_aggregatesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_aggregates(ctx: ZdlParser.Service_aggregatesContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_method(ctx: ZdlParser.Service_methodContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_method(ctx: ZdlParser.Service_methodContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_method_name(ctx: ZdlParser.Service_method_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_method_name(ctx: ZdlParser.Service_method_nameContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_method_parameter_natural(ctx: ZdlParser.Service_method_parameter_naturalContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_method_parameter_natural(ctx: ZdlParser.Service_method_parameter_naturalContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_method_parameter_id(ctx: ZdlParser.Service_method_parameter_idContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_method_parameter_id(ctx: ZdlParser.Service_method_parameter_idContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_method_parameter(ctx: ZdlParser.Service_method_parameterContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_method_parameter(ctx: ZdlParser.Service_method_parameterContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_method_return(ctx: ZdlParser.Service_method_returnContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_method_return(ctx: ZdlParser.Service_method_returnContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterWith_events(ctx: ZdlParser.With_eventsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitWith_events(ctx: ZdlParser.With_eventsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterWith_events_events(ctx: ZdlParser.With_events_eventsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitWith_events_events(ctx: ZdlParser.With_events_eventsContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterWith_events_event(ctx: ZdlParser.With_events_eventContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitWith_events_event(ctx: ZdlParser.With_events_eventContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterWith_events_events_or(ctx: ZdlParser.With_events_events_orContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitWith_events_events_or(ctx: ZdlParser.With_events_events_orContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterService_legacy(ctx: ZdlParser.Service_legacyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitService_legacy(ctx: ZdlParser.Service_legacyContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun enterEveryRule(ctx: ParserRuleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun exitEveryRule(ctx: ParserRuleContext) {}

    /**
     * The default implementation does nothing.
     */
    override fun visitTerminal(node: TerminalNode) {}

    /**
     * The default implementation does nothing.
     */
    override fun visitErrorNode(node: ErrorNode) {}
}
