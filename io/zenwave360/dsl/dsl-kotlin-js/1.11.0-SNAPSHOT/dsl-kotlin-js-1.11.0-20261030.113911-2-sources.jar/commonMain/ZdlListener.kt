// Generated from /home/runner/work/dsl-kotlin/dsl-kotlin/dsl-kotlin/src/commonMain/antlr/io.zenwave360.language.antlr/Zdl.g4 by ANTLR 4.13.1
package io.zenwave360.language.antlr

import org.antlr.v4.kotlinruntime.tree.ParseTreeListener

/**
 * This interface defines a complete listener for a parse tree produced by [ZdlParser].
 */
public interface ZdlListener : ParseTreeListener {
    /**
     * Enter a parse tree produced by [ZdlParser.zdl].
     *
     * @param ctx The parse tree
     */
    public fun enterZdl(ctx: ZdlParser.ZdlContext)

    /**
     * Exit a parse tree produced by [ZdlParser.zdl].
     *
     * @param ctx The parse tree
     */
    public fun exitZdl(ctx: ZdlParser.ZdlContext)

    /**
     * Enter a parse tree produced by [ZdlParser.import_].
     *
     * @param ctx The parse tree
     */
    public fun enterImport_(ctx: ZdlParser.Import_Context)

    /**
     * Exit a parse tree produced by [ZdlParser.import_].
     *
     * @param ctx The parse tree
     */
    public fun exitImport_(ctx: ZdlParser.Import_Context)

    /**
     * Enter a parse tree produced by [ZdlParser.import_key].
     *
     * @param ctx The parse tree
     */
    public fun enterImport_key(ctx: ZdlParser.Import_keyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.import_key].
     *
     * @param ctx The parse tree
     */
    public fun exitImport_key(ctx: ZdlParser.Import_keyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.import_value].
     *
     * @param ctx The parse tree
     */
    public fun enterImport_value(ctx: ZdlParser.Import_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.import_value].
     *
     * @param ctx The parse tree
     */
    public fun exitImport_value(ctx: ZdlParser.Import_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.global_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun enterGlobal_javadoc(ctx: ZdlParser.Global_javadocContext)

    /**
     * Exit a parse tree produced by [ZdlParser.global_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun exitGlobal_javadoc(ctx: ZdlParser.Global_javadocContext)

    /**
     * Enter a parse tree produced by [ZdlParser.javadoc].
     *
     * @param ctx The parse tree
     */
    public fun enterJavadoc(ctx: ZdlParser.JavadocContext)

    /**
     * Exit a parse tree produced by [ZdlParser.javadoc].
     *
     * @param ctx The parse tree
     */
    public fun exitJavadoc(ctx: ZdlParser.JavadocContext)

    /**
     * Enter a parse tree produced by [ZdlParser.suffix_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun enterSuffix_javadoc(ctx: ZdlParser.Suffix_javadocContext)

    /**
     * Exit a parse tree produced by [ZdlParser.suffix_javadoc].
     *
     * @param ctx The parse tree
     */
    public fun exitSuffix_javadoc(ctx: ZdlParser.Suffix_javadocContext)

    /**
     * Enter a parse tree produced by [ZdlParser.legacy_constants].
     *
     * @param ctx The parse tree
     */
    public fun enterLegacy_constants(ctx: ZdlParser.Legacy_constantsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.legacy_constants].
     *
     * @param ctx The parse tree
     */
    public fun exitLegacy_constants(ctx: ZdlParser.Legacy_constantsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.keyword].
     *
     * @param ctx The parse tree
     */
    public fun enterKeyword(ctx: ZdlParser.KeywordContext)

    /**
     * Exit a parse tree produced by [ZdlParser.keyword].
     *
     * @param ctx The parse tree
     */
    public fun exitKeyword(ctx: ZdlParser.KeywordContext)

    /**
     * Enter a parse tree produced by [ZdlParser.complex_value].
     *
     * @param ctx The parse tree
     */
    public fun enterComplex_value(ctx: ZdlParser.Complex_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.complex_value].
     *
     * @param ctx The parse tree
     */
    public fun exitComplex_value(ctx: ZdlParser.Complex_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.value].
     *
     * @param ctx The parse tree
     */
    public fun enterValue(ctx: ZdlParser.ValueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.value].
     *
     * @param ctx The parse tree
     */
    public fun exitValue(ctx: ZdlParser.ValueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.string].
     *
     * @param ctx The parse tree
     */
    public fun enterString(ctx: ZdlParser.StringContext)

    /**
     * Exit a parse tree produced by [ZdlParser.string].
     *
     * @param ctx The parse tree
     */
    public fun exitString(ctx: ZdlParser.StringContext)

    /**
     * Enter a parse tree produced by [ZdlParser.simple].
     *
     * @param ctx The parse tree
     */
    public fun enterSimple(ctx: ZdlParser.SimpleContext)

    /**
     * Exit a parse tree produced by [ZdlParser.simple].
     *
     * @param ctx The parse tree
     */
    public fun exitSimple(ctx: ZdlParser.SimpleContext)

    /**
     * Enter a parse tree produced by [ZdlParser.object].
     *
     * @param ctx The parse tree
     */
    public fun enterObject(ctx: ZdlParser.ObjectContext)

    /**
     * Exit a parse tree produced by [ZdlParser.object].
     *
     * @param ctx The parse tree
     */
    public fun exitObject(ctx: ZdlParser.ObjectContext)

    /**
     * Enter a parse tree produced by [ZdlParser.pair].
     *
     * @param ctx The parse tree
     */
    public fun enterPair(ctx: ZdlParser.PairContext)

    /**
     * Exit a parse tree produced by [ZdlParser.pair].
     *
     * @param ctx The parse tree
     */
    public fun exitPair(ctx: ZdlParser.PairContext)

    /**
     * Enter a parse tree produced by [ZdlParser.array].
     *
     * @param ctx The parse tree
     */
    public fun enterArray(ctx: ZdlParser.ArrayContext)

    /**
     * Exit a parse tree produced by [ZdlParser.array].
     *
     * @param ctx The parse tree
     */
    public fun exitArray(ctx: ZdlParser.ArrayContext)

    /**
     * Enter a parse tree produced by [ZdlParser.array_plain].
     *
     * @param ctx The parse tree
     */
    public fun enterArray_plain(ctx: ZdlParser.Array_plainContext)

    /**
     * Exit a parse tree produced by [ZdlParser.array_plain].
     *
     * @param ctx The parse tree
     */
    public fun exitArray_plain(ctx: ZdlParser.Array_plainContext)

    /**
     * Enter a parse tree produced by [ZdlParser.pairs].
     *
     * @param ctx The parse tree
     */
    public fun enterPairs(ctx: ZdlParser.PairsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.pairs].
     *
     * @param ctx The parse tree
     */
    public fun exitPairs(ctx: ZdlParser.PairsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.config].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig(ctx: ZdlParser.ConfigContext)

    /**
     * Exit a parse tree produced by [ZdlParser.config].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig(ctx: ZdlParser.ConfigContext)

    /**
     * Enter a parse tree produced by [ZdlParser.config_body].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig_body(ctx: ZdlParser.Config_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.config_body].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig_body(ctx: ZdlParser.Config_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.config_entry].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig_entry(ctx: ZdlParser.Config_entryContext)

    /**
     * Exit a parse tree produced by [ZdlParser.config_entry].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig_entry(ctx: ZdlParser.Config_entryContext)

    /**
     * Enter a parse tree produced by [ZdlParser.config_option].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig_option(ctx: ZdlParser.Config_optionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.config_option].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig_option(ctx: ZdlParser.Config_optionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.config_cli_option].
     *
     * @param ctx The parse tree
     */
    public fun enterConfig_cli_option(ctx: ZdlParser.Config_cli_optionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.config_cli_option].
     *
     * @param ctx The parse tree
     */
    public fun exitConfig_cli_option(ctx: ZdlParser.Config_cli_optionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.apis].
     *
     * @param ctx The parse tree
     */
    public fun enterApis(ctx: ZdlParser.ApisContext)

    /**
     * Exit a parse tree produced by [ZdlParser.apis].
     *
     * @param ctx The parse tree
     */
    public fun exitApis(ctx: ZdlParser.ApisContext)

    /**
     * Enter a parse tree produced by [ZdlParser.apis_body].
     *
     * @param ctx The parse tree
     */
    public fun enterApis_body(ctx: ZdlParser.Apis_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.apis_body].
     *
     * @param ctx The parse tree
     */
    public fun exitApis_body(ctx: ZdlParser.Apis_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api].
     *
     * @param ctx The parse tree
     */
    public fun enterApi(ctx: ZdlParser.ApiContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api].
     *
     * @param ctx The parse tree
     */
    public fun exitApi(ctx: ZdlParser.ApiContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_type].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_type(ctx: ZdlParser.Api_typeContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_type].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_type(ctx: ZdlParser.Api_typeContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_role].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_role(ctx: ZdlParser.Api_roleContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_role].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_role(ctx: ZdlParser.Api_roleContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_name].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_name(ctx: ZdlParser.Api_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_name].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_name(ctx: ZdlParser.Api_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_uri].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_uri(ctx: ZdlParser.Api_uriContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_uri].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_uri(ctx: ZdlParser.Api_uriContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_body].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_body(ctx: ZdlParser.Api_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_body].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_body(ctx: ZdlParser.Api_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_configs].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_configs(ctx: ZdlParser.Api_configsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_configs].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_configs(ctx: ZdlParser.Api_configsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.api_config].
     *
     * @param ctx The parse tree
     */
    public fun enterApi_config(ctx: ZdlParser.Api_configContext)

    /**
     * Exit a parse tree produced by [ZdlParser.api_config].
     *
     * @param ctx The parse tree
     */
    public fun exitApi_config(ctx: ZdlParser.Api_configContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugins].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugins(ctx: ZdlParser.PluginsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugins].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugins(ctx: ZdlParser.PluginsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugins_body].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugins_body(ctx: ZdlParser.Plugins_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugins_body].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugins_body(ctx: ZdlParser.Plugins_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin(ctx: ZdlParser.PluginContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin(ctx: ZdlParser.PluginContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_disabled].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_disabled(ctx: ZdlParser.Plugin_disabledContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_disabled].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_disabled(ctx: ZdlParser.Plugin_disabledContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_name].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_name(ctx: ZdlParser.Plugin_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_name].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_name(ctx: ZdlParser.Plugin_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_options].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_options(ctx: ZdlParser.Plugin_optionsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_options].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_options(ctx: ZdlParser.Plugin_optionsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_options_inherit].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_options_inherit(ctx: ZdlParser.Plugin_options_inheritContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_options_inherit].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_options_inherit(ctx: ZdlParser.Plugin_options_inheritContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_body].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_body(ctx: ZdlParser.Plugin_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_body].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_body(ctx: ZdlParser.Plugin_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_configs].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_configs(ctx: ZdlParser.Plugin_configsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_configs].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_configs(ctx: ZdlParser.Plugin_configsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_config].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_config(ctx: ZdlParser.Plugin_configContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_config].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_config(ctx: ZdlParser.Plugin_configContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_config_option].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_config_option(ctx: ZdlParser.Plugin_config_optionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_config_option].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_config_option(ctx: ZdlParser.Plugin_config_optionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.plugin_config_cli_option].
     *
     * @param ctx The parse tree
     */
    public fun enterPlugin_config_cli_option(ctx: ZdlParser.Plugin_config_cli_optionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.plugin_config_cli_option].
     *
     * @param ctx The parse tree
     */
    public fun exitPlugin_config_cli_option(ctx: ZdlParser.Plugin_config_cli_optionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.policies].
     *
     * @param ctx The parse tree
     */
    public fun enterPolicies(ctx: ZdlParser.PoliciesContext)

    /**
     * Exit a parse tree produced by [ZdlParser.policies].
     *
     * @param ctx The parse tree
     */
    public fun exitPolicies(ctx: ZdlParser.PoliciesContext)

    /**
     * Enter a parse tree produced by [ZdlParser.policy_aggregate].
     *
     * @param ctx The parse tree
     */
    public fun enterPolicy_aggregate(ctx: ZdlParser.Policy_aggregateContext)

    /**
     * Exit a parse tree produced by [ZdlParser.policy_aggregate].
     *
     * @param ctx The parse tree
     */
    public fun exitPolicy_aggregate(ctx: ZdlParser.Policy_aggregateContext)

    /**
     * Enter a parse tree produced by [ZdlParser.policies_body].
     *
     * @param ctx The parse tree
     */
    public fun enterPolicies_body(ctx: ZdlParser.Policies_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.policies_body].
     *
     * @param ctx The parse tree
     */
    public fun exitPolicies_body(ctx: ZdlParser.Policies_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.policie_body].
     *
     * @param ctx The parse tree
     */
    public fun enterPolicie_body(ctx: ZdlParser.Policie_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.policie_body].
     *
     * @param ctx The parse tree
     */
    public fun exitPolicie_body(ctx: ZdlParser.Policie_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.policie_name].
     *
     * @param ctx The parse tree
     */
    public fun enterPolicie_name(ctx: ZdlParser.Policie_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.policie_name].
     *
     * @param ctx The parse tree
     */
    public fun exitPolicie_name(ctx: ZdlParser.Policie_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.policie_value].
     *
     * @param ctx The parse tree
     */
    public fun enterPolicie_value(ctx: ZdlParser.Policie_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.policie_value].
     *
     * @param ctx The parse tree
     */
    public fun exitPolicie_value(ctx: ZdlParser.Policie_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.annotations].
     *
     * @param ctx The parse tree
     */
    public fun enterAnnotations(ctx: ZdlParser.AnnotationsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.annotations].
     *
     * @param ctx The parse tree
     */
    public fun exitAnnotations(ctx: ZdlParser.AnnotationsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.option].
     *
     * @param ctx The parse tree
     */
    public fun enterOption(ctx: ZdlParser.OptionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.option].
     *
     * @param ctx The parse tree
     */
    public fun exitOption(ctx: ZdlParser.OptionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.option_name].
     *
     * @param ctx The parse tree
     */
    public fun enterOption_name(ctx: ZdlParser.Option_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.option_name].
     *
     * @param ctx The parse tree
     */
    public fun exitOption_name(ctx: ZdlParser.Option_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.option_value].
     *
     * @param ctx The parse tree
     */
    public fun enterOption_value(ctx: ZdlParser.Option_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.option_value].
     *
     * @param ctx The parse tree
     */
    public fun exitOption_value(ctx: ZdlParser.Option_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.entity].
     *
     * @param ctx The parse tree
     */
    public fun enterEntity(ctx: ZdlParser.EntityContext)

    /**
     * Exit a parse tree produced by [ZdlParser.entity].
     *
     * @param ctx The parse tree
     */
    public fun exitEntity(ctx: ZdlParser.EntityContext)

    /**
     * Enter a parse tree produced by [ZdlParser.entity_definition].
     *
     * @param ctx The parse tree
     */
    public fun enterEntity_definition(ctx: ZdlParser.Entity_definitionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.entity_definition].
     *
     * @param ctx The parse tree
     */
    public fun exitEntity_definition(ctx: ZdlParser.Entity_definitionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.entity_name].
     *
     * @param ctx The parse tree
     */
    public fun enterEntity_name(ctx: ZdlParser.Entity_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.entity_name].
     *
     * @param ctx The parse tree
     */
    public fun exitEntity_name(ctx: ZdlParser.Entity_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.entity_table_name].
     *
     * @param ctx The parse tree
     */
    public fun enterEntity_table_name(ctx: ZdlParser.Entity_table_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.entity_table_name].
     *
     * @param ctx The parse tree
     */
    public fun exitEntity_table_name(ctx: ZdlParser.Entity_table_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.entity_body].
     *
     * @param ctx The parse tree
     */
    public fun enterEntity_body(ctx: ZdlParser.Entity_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.entity_body].
     *
     * @param ctx The parse tree
     */
    public fun exitEntity_body(ctx: ZdlParser.Entity_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.fields].
     *
     * @param ctx The parse tree
     */
    public fun enterFields(ctx: ZdlParser.FieldsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.fields].
     *
     * @param ctx The parse tree
     */
    public fun exitFields(ctx: ZdlParser.FieldsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field].
     *
     * @param ctx The parse tree
     */
    public fun enterField(ctx: ZdlParser.FieldContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field].
     *
     * @param ctx The parse tree
     */
    public fun exitField(ctx: ZdlParser.FieldContext)

    /**
     * Enter a parse tree produced by [ZdlParser.nested_field].
     *
     * @param ctx The parse tree
     */
    public fun enterNested_field(ctx: ZdlParser.Nested_fieldContext)

    /**
     * Exit a parse tree produced by [ZdlParser.nested_field].
     *
     * @param ctx The parse tree
     */
    public fun exitNested_field(ctx: ZdlParser.Nested_fieldContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_name].
     *
     * @param ctx The parse tree
     */
    public fun enterField_name(ctx: ZdlParser.Field_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_name].
     *
     * @param ctx The parse tree
     */
    public fun exitField_name(ctx: ZdlParser.Field_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_type].
     *
     * @param ctx The parse tree
     */
    public fun enterField_type(ctx: ZdlParser.Field_typeContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_type].
     *
     * @param ctx The parse tree
     */
    public fun exitField_type(ctx: ZdlParser.Field_typeContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_initialization].
     *
     * @param ctx The parse tree
     */
    public fun enterField_initialization(ctx: ZdlParser.Field_initializationContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_initialization].
     *
     * @param ctx The parse tree
     */
    public fun exitField_initialization(ctx: ZdlParser.Field_initializationContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_initial_value].
     *
     * @param ctx The parse tree
     */
    public fun enterField_initial_value(ctx: ZdlParser.Field_initial_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_initial_value].
     *
     * @param ctx The parse tree
     */
    public fun exitField_initial_value(ctx: ZdlParser.Field_initial_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_validations].
     *
     * @param ctx The parse tree
     */
    public fun enterField_validations(ctx: ZdlParser.Field_validationsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_validations].
     *
     * @param ctx The parse tree
     */
    public fun exitField_validations(ctx: ZdlParser.Field_validationsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_validation_name].
     *
     * @param ctx The parse tree
     */
    public fun enterField_validation_name(ctx: ZdlParser.Field_validation_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_validation_name].
     *
     * @param ctx The parse tree
     */
    public fun exitField_validation_name(ctx: ZdlParser.Field_validation_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.field_validation_value].
     *
     * @param ctx The parse tree
     */
    public fun enterField_validation_value(ctx: ZdlParser.Field_validation_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.field_validation_value].
     *
     * @param ctx The parse tree
     */
    public fun exitField_validation_value(ctx: ZdlParser.Field_validation_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.nested_field_validations].
     *
     * @param ctx The parse tree
     */
    public fun enterNested_field_validations(ctx: ZdlParser.Nested_field_validationsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.nested_field_validations].
     *
     * @param ctx The parse tree
     */
    public fun exitNested_field_validations(ctx: ZdlParser.Nested_field_validationsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.nested_field_validation_name].
     *
     * @param ctx The parse tree
     */
    public fun enterNested_field_validation_name(ctx: ZdlParser.Nested_field_validation_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.nested_field_validation_name].
     *
     * @param ctx The parse tree
     */
    public fun exitNested_field_validation_name(ctx: ZdlParser.Nested_field_validation_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.nested_field_validation_value].
     *
     * @param ctx The parse tree
     */
    public fun enterNested_field_validation_value(ctx: ZdlParser.Nested_field_validation_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.nested_field_validation_value].
     *
     * @param ctx The parse tree
     */
    public fun exitNested_field_validation_value(ctx: ZdlParser.Nested_field_validation_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.enum].
     *
     * @param ctx The parse tree
     */
    public fun enterEnum(ctx: ZdlParser.EnumContext)

    /**
     * Exit a parse tree produced by [ZdlParser.enum].
     *
     * @param ctx The parse tree
     */
    public fun exitEnum(ctx: ZdlParser.EnumContext)

    /**
     * Enter a parse tree produced by [ZdlParser.enum_name].
     *
     * @param ctx The parse tree
     */
    public fun enterEnum_name(ctx: ZdlParser.Enum_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.enum_name].
     *
     * @param ctx The parse tree
     */
    public fun exitEnum_name(ctx: ZdlParser.Enum_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.enum_body].
     *
     * @param ctx The parse tree
     */
    public fun enterEnum_body(ctx: ZdlParser.Enum_bodyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.enum_body].
     *
     * @param ctx The parse tree
     */
    public fun exitEnum_body(ctx: ZdlParser.Enum_bodyContext)

    /**
     * Enter a parse tree produced by [ZdlParser.enum_value].
     *
     * @param ctx The parse tree
     */
    public fun enterEnum_value(ctx: ZdlParser.Enum_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.enum_value].
     *
     * @param ctx The parse tree
     */
    public fun exitEnum_value(ctx: ZdlParser.Enum_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.enum_value_name].
     *
     * @param ctx The parse tree
     */
    public fun enterEnum_value_name(ctx: ZdlParser.Enum_value_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.enum_value_name].
     *
     * @param ctx The parse tree
     */
    public fun exitEnum_value_name(ctx: ZdlParser.Enum_value_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.enum_value_value].
     *
     * @param ctx The parse tree
     */
    public fun enterEnum_value_value(ctx: ZdlParser.Enum_value_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.enum_value_value].
     *
     * @param ctx The parse tree
     */
    public fun exitEnum_value_value(ctx: ZdlParser.Enum_value_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.input].
     *
     * @param ctx The parse tree
     */
    public fun enterInput(ctx: ZdlParser.InputContext)

    /**
     * Exit a parse tree produced by [ZdlParser.input].
     *
     * @param ctx The parse tree
     */
    public fun exitInput(ctx: ZdlParser.InputContext)

    /**
     * Enter a parse tree produced by [ZdlParser.input_name].
     *
     * @param ctx The parse tree
     */
    public fun enterInput_name(ctx: ZdlParser.Input_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.input_name].
     *
     * @param ctx The parse tree
     */
    public fun exitInput_name(ctx: ZdlParser.Input_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.output].
     *
     * @param ctx The parse tree
     */
    public fun enterOutput(ctx: ZdlParser.OutputContext)

    /**
     * Exit a parse tree produced by [ZdlParser.output].
     *
     * @param ctx The parse tree
     */
    public fun exitOutput(ctx: ZdlParser.OutputContext)

    /**
     * Enter a parse tree produced by [ZdlParser.output_name].
     *
     * @param ctx The parse tree
     */
    public fun enterOutput_name(ctx: ZdlParser.Output_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.output_name].
     *
     * @param ctx The parse tree
     */
    public fun exitOutput_name(ctx: ZdlParser.Output_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.event].
     *
     * @param ctx The parse tree
     */
    public fun enterEvent(ctx: ZdlParser.EventContext)

    /**
     * Exit a parse tree produced by [ZdlParser.event].
     *
     * @param ctx The parse tree
     */
    public fun exitEvent(ctx: ZdlParser.EventContext)

    /**
     * Enter a parse tree produced by [ZdlParser.event_name].
     *
     * @param ctx The parse tree
     */
    public fun enterEvent_name(ctx: ZdlParser.Event_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.event_name].
     *
     * @param ctx The parse tree
     */
    public fun exitEvent_name(ctx: ZdlParser.Event_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationships].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationships(ctx: ZdlParser.RelationshipsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationships].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationships(ctx: ZdlParser.RelationshipsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_type].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_type(ctx: ZdlParser.Relationship_typeContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_type].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_type(ctx: ZdlParser.Relationship_typeContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship(ctx: ZdlParser.RelationshipContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship(ctx: ZdlParser.RelationshipContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_from].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_from(ctx: ZdlParser.Relationship_fromContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_from].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_from(ctx: ZdlParser.Relationship_fromContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_to].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_to(ctx: ZdlParser.Relationship_toContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_to].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_to(ctx: ZdlParser.Relationship_toContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_definition].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_definition(ctx: ZdlParser.Relationship_definitionContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_definition].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_definition(ctx: ZdlParser.Relationship_definitionContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_entity_name].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_entity_name(ctx: ZdlParser.Relationship_entity_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_entity_name].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_entity_name(ctx: ZdlParser.Relationship_entity_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_field_name].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_field_name(ctx: ZdlParser.Relationship_field_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_field_name].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_field_name(ctx: ZdlParser.Relationship_field_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_description_field].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_description_field(ctx: ZdlParser.Relationship_description_fieldContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_description_field].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_description_field(ctx: ZdlParser.Relationship_description_fieldContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_field_validations].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_field_validations(ctx: ZdlParser.Relationship_field_validationsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_field_validations].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_field_validations(ctx: ZdlParser.Relationship_field_validationsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_field_required].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_field_required(ctx: ZdlParser.Relationship_field_requiredContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_field_required].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_field_required(ctx: ZdlParser.Relationship_field_requiredContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_field_min].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_field_min(ctx: ZdlParser.Relationship_field_minContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_field_min].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_field_min(ctx: ZdlParser.Relationship_field_minContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_field_max].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_field_max(ctx: ZdlParser.Relationship_field_maxContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_field_max].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_field_max(ctx: ZdlParser.Relationship_field_maxContext)

    /**
     * Enter a parse tree produced by [ZdlParser.relationship_field_value].
     *
     * @param ctx The parse tree
     */
    public fun enterRelationship_field_value(ctx: ZdlParser.Relationship_field_valueContext)

    /**
     * Exit a parse tree produced by [ZdlParser.relationship_field_value].
     *
     * @param ctx The parse tree
     */
    public fun exitRelationship_field_value(ctx: ZdlParser.Relationship_field_valueContext)

    /**
     * Enter a parse tree produced by [ZdlParser.aggregate].
     *
     * @param ctx The parse tree
     */
    public fun enterAggregate(ctx: ZdlParser.AggregateContext)

    /**
     * Exit a parse tree produced by [ZdlParser.aggregate].
     *
     * @param ctx The parse tree
     */
    public fun exitAggregate(ctx: ZdlParser.AggregateContext)

    /**
     * Enter a parse tree produced by [ZdlParser.aggregate_name].
     *
     * @param ctx The parse tree
     */
    public fun enterAggregate_name(ctx: ZdlParser.Aggregate_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.aggregate_name].
     *
     * @param ctx The parse tree
     */
    public fun exitAggregate_name(ctx: ZdlParser.Aggregate_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.aggregate_root].
     *
     * @param ctx The parse tree
     */
    public fun enterAggregate_root(ctx: ZdlParser.Aggregate_rootContext)

    /**
     * Exit a parse tree produced by [ZdlParser.aggregate_root].
     *
     * @param ctx The parse tree
     */
    public fun exitAggregate_root(ctx: ZdlParser.Aggregate_rootContext)

    /**
     * Enter a parse tree produced by [ZdlParser.aggregate_command].
     *
     * @param ctx The parse tree
     */
    public fun enterAggregate_command(ctx: ZdlParser.Aggregate_commandContext)

    /**
     * Exit a parse tree produced by [ZdlParser.aggregate_command].
     *
     * @param ctx The parse tree
     */
    public fun exitAggregate_command(ctx: ZdlParser.Aggregate_commandContext)

    /**
     * Enter a parse tree produced by [ZdlParser.aggregate_command_name].
     *
     * @param ctx The parse tree
     */
    public fun enterAggregate_command_name(ctx: ZdlParser.Aggregate_command_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.aggregate_command_name].
     *
     * @param ctx The parse tree
     */
    public fun exitAggregate_command_name(ctx: ZdlParser.Aggregate_command_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.aggregate_command_parameter].
     *
     * @param ctx The parse tree
     */
    public fun enterAggregate_command_parameter(ctx: ZdlParser.Aggregate_command_parameterContext)

    /**
     * Exit a parse tree produced by [ZdlParser.aggregate_command_parameter].
     *
     * @param ctx The parse tree
     */
    public fun exitAggregate_command_parameter(ctx: ZdlParser.Aggregate_command_parameterContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service].
     *
     * @param ctx The parse tree
     */
    public fun enterService(ctx: ZdlParser.ServiceContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service].
     *
     * @param ctx The parse tree
     */
    public fun exitService(ctx: ZdlParser.ServiceContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_name].
     *
     * @param ctx The parse tree
     */
    public fun enterService_name(ctx: ZdlParser.Service_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_name].
     *
     * @param ctx The parse tree
     */
    public fun exitService_name(ctx: ZdlParser.Service_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_aggregates].
     *
     * @param ctx The parse tree
     */
    public fun enterService_aggregates(ctx: ZdlParser.Service_aggregatesContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_aggregates].
     *
     * @param ctx The parse tree
     */
    public fun exitService_aggregates(ctx: ZdlParser.Service_aggregatesContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_method].
     *
     * @param ctx The parse tree
     */
    public fun enterService_method(ctx: ZdlParser.Service_methodContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_method].
     *
     * @param ctx The parse tree
     */
    public fun exitService_method(ctx: ZdlParser.Service_methodContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_method_name].
     *
     * @param ctx The parse tree
     */
    public fun enterService_method_name(ctx: ZdlParser.Service_method_nameContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_method_name].
     *
     * @param ctx The parse tree
     */
    public fun exitService_method_name(ctx: ZdlParser.Service_method_nameContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_method_parameter_natural].
     *
     * @param ctx The parse tree
     */
    public fun enterService_method_parameter_natural(ctx: ZdlParser.Service_method_parameter_naturalContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_method_parameter_natural].
     *
     * @param ctx The parse tree
     */
    public fun exitService_method_parameter_natural(ctx: ZdlParser.Service_method_parameter_naturalContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_method_parameter_id].
     *
     * @param ctx The parse tree
     */
    public fun enterService_method_parameter_id(ctx: ZdlParser.Service_method_parameter_idContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_method_parameter_id].
     *
     * @param ctx The parse tree
     */
    public fun exitService_method_parameter_id(ctx: ZdlParser.Service_method_parameter_idContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_method_parameter].
     *
     * @param ctx The parse tree
     */
    public fun enterService_method_parameter(ctx: ZdlParser.Service_method_parameterContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_method_parameter].
     *
     * @param ctx The parse tree
     */
    public fun exitService_method_parameter(ctx: ZdlParser.Service_method_parameterContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_method_return].
     *
     * @param ctx The parse tree
     */
    public fun enterService_method_return(ctx: ZdlParser.Service_method_returnContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_method_return].
     *
     * @param ctx The parse tree
     */
    public fun exitService_method_return(ctx: ZdlParser.Service_method_returnContext)

    /**
     * Enter a parse tree produced by [ZdlParser.with_events].
     *
     * @param ctx The parse tree
     */
    public fun enterWith_events(ctx: ZdlParser.With_eventsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.with_events].
     *
     * @param ctx The parse tree
     */
    public fun exitWith_events(ctx: ZdlParser.With_eventsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.with_events_events].
     *
     * @param ctx The parse tree
     */
    public fun enterWith_events_events(ctx: ZdlParser.With_events_eventsContext)

    /**
     * Exit a parse tree produced by [ZdlParser.with_events_events].
     *
     * @param ctx The parse tree
     */
    public fun exitWith_events_events(ctx: ZdlParser.With_events_eventsContext)

    /**
     * Enter a parse tree produced by [ZdlParser.with_events_event].
     *
     * @param ctx The parse tree
     */
    public fun enterWith_events_event(ctx: ZdlParser.With_events_eventContext)

    /**
     * Exit a parse tree produced by [ZdlParser.with_events_event].
     *
     * @param ctx The parse tree
     */
    public fun exitWith_events_event(ctx: ZdlParser.With_events_eventContext)

    /**
     * Enter a parse tree produced by [ZdlParser.with_events_events_or].
     *
     * @param ctx The parse tree
     */
    public fun enterWith_events_events_or(ctx: ZdlParser.With_events_events_orContext)

    /**
     * Exit a parse tree produced by [ZdlParser.with_events_events_or].
     *
     * @param ctx The parse tree
     */
    public fun exitWith_events_events_or(ctx: ZdlParser.With_events_events_orContext)

    /**
     * Enter a parse tree produced by [ZdlParser.service_legacy].
     *
     * @param ctx The parse tree
     */
    public fun enterService_legacy(ctx: ZdlParser.Service_legacyContext)

    /**
     * Exit a parse tree produced by [ZdlParser.service_legacy].
     *
     * @param ctx The parse tree
     */
    public fun exitService_legacy(ctx: ZdlParser.Service_legacyContext)

}
