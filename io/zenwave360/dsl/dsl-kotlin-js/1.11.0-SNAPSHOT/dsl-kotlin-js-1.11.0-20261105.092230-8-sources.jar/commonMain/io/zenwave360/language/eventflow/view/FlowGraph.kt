package io.zenwave360.language.eventflow.view

import io.zenwave360.language.source.SourceRef

data class FlowGraph(
    val nodes: List<FlowGraphNode>,
    val edges: List<FlowGraphEdge>
)

data class FlowGraphNode(
    val id: String,
    val type: FlowGraphNodeType,
    val label: String,
    val system: String?,
    val service: String?,
    val sourceRef: SourceRef,
    val endOutcomeLabels: List<String>? = null,
    val startKind: String? = null,
    val actor: String? = null,
    /** `@title` of a policy; replaces its text. Present for POLICY nodes that declare it. */
    val title: String? = null,
    /** What a policy waits on: actor or timer. Absent when it declares neither. */
    val policyKind: String? = null,
    /** Timer text of a policy with `@timer`/`@time`. */
    val timer: String? = null
)

enum class FlowGraphNodeType {
    START,
    ACTION,
    OUTCOME,
    READ_MODEL,
    POLICY
}

data class FlowGraphEdge(
    val id: String,
    val source: String,
    val target: String,
    val type: FlowGraphEdgeType,
    val label: String? = null,
    val outcome: String? = null,
    val sourceRef: SourceRef? = null
)

enum class FlowGraphEdgeType {
    CAUSATION,
    CALL,
    OUTCOME_HANDLER,
    TRIGGER,
    CONDITIONAL
}
