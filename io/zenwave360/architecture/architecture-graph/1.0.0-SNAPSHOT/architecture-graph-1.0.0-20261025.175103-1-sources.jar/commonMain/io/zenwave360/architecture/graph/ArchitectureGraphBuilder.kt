package io.zenwave360.architecture.graph

import io.zenwave360.architecture.manifest.ManifestArtifactCatalog
import io.zenwave360.architecture.manifest.ApiConsumptionOptions
import io.zenwave360.architecture.manifest.ManifestApiConsumptions
import io.zenwave360.architecture.manifest.ManifestConsumerIndex
import io.zenwave360.architecture.manifest.ManifestDiagnosticSeverity
import io.zenwave360.architecture.manifest.ManifestDomain
import io.zenwave360.architecture.manifest.ManifestService
import io.zenwave360.architecture.manifest.ResolvedManifestArtifact
import io.zenwave360.architecture.manifest.ZenWaveManifest
import io.zenwave360.architecture.manifest.ZenWaveManifestLoader
import kotlin.jvm.JvmOverloads

class ArchitectureGraphBuilder @JvmOverloads constructor(
    private val loader: ZenWaveManifestLoader = ZenWaveManifestLoader(),
    private val analyzers: List<ManifestGraphArtifactAnalyzer> = defaultArtifactAnalyzers(),
    private val relationshipResolvers: List<RelationshipResolver> = emptyList(),
) {
    suspend fun build(
        manifest: ZenWaveManifest,
        options: ArchitectureGraphBuildOptions = ArchitectureGraphBuildOptions(),
    ): ArchitectureGraphResult {
        val nodes = linkedMapOf<String, ArchitectureNode>()
        val edges = linkedMapOf<String, ArchitectureEdge>()
        val diagnostics = manifest.diagnostics.mapTo(mutableListOf()) { diagnostic ->
            ArchitectureDiagnostic(
                message = diagnostic.message,
                severity = when (diagnostic.severity) {
                    ManifestDiagnosticSeverity.ERROR -> ArchitectureDiagnosticSeverity.ERROR
                    ManifestDiagnosticSeverity.WARNING -> ArchitectureDiagnosticSeverity.WARNING
                },
                code = diagnostic.code ?: "manifest-diagnostic",
                source = ArchitectureSource(manifest.uri, semanticPath = diagnostic.location),
            )
        }

        addManifestStructure(manifest, nodes, edges)
        validateSemanticNamespace(nodes, diagnostics)

        val catalog = try {
            ManifestArtifactCatalog.resolve(manifest, loader)
        } catch (error: Exception) {
            diagnostics += ArchitectureDiagnostic(
                message = error.message ?: "Cannot resolve manifest artifacts",
                severity = ArchitectureDiagnosticSeverity.ERROR,
                code = "artifact-catalog-failed",
                source = ArchitectureSource(manifest.uri),
            )
            return ArchitectureGraphResult(ArchitectureGraph(nodes.values.toList(), edges.values.toList()), diagnostics)
        }

        catalog.artifacts.forEach { artifact -> addArtifact(artifact, manifest, nodes, edges) }

        val hasApiArtifacts = catalog.artifacts.any { it.artifact.type in setOf("openapi", "asyncapi", "asyncapi-client") }
        val apiConsumptions = if (options.includeDeclaredConsumers || options.includeApiConsumptions || hasApiArtifacts) {
            ManifestApiConsumptions.build(
                manifest,
                loader,
                ApiConsumptionOptions(
                    loadOptions = options.loadOptions,
                    rules = options.consumptionRules,
                    legacyAddressMatching = options.legacyAddressMatching,
                ),
            ).also { result -> diagnostics += result.diagnostics.map { it.toArchitectureDiagnostic(manifest.uri) } }
        } else {
            null
        }

        if (options.includeDeclaredConsumers && apiConsumptions != null) {
            addDeclaredConsumers(apiConsumptions.consumerIndex, manifest, nodes, edges)
        }
        if (apiConsumptions != null && hasApiArtifacts) {
            merge(
                ApiConsumptionGraphContributor.contribute(
                    apiConsumptions, catalog, manifest.uri,
                    includeConsumptionMatches = options.includeApiConsumptions,
                ),
                nodes,
                edges,
                diagnostics,
            )
        }

        for (artifact in catalog.artifacts) {
            if (options.artifactTypes.isNotEmpty() && artifact.artifact.type !in options.artifactTypes) continue
            val matchingAnalyzers = analyzers.filter { it.supports(artifact) }
            if (matchingAnalyzers.isEmpty()) continue
            val loaded = loader.loadArtifactResult(manifest, artifact.owner, artifact.artifact, options.loadOptions)
            val content = loaded.content
            val resource = loaded.resource
            if (content == null || resource == null) {
                diagnostics += ArchitectureDiagnostic(
                    message = loaded.errorMessage ?: "Cannot load artifact '${artifact.artifact.path}'",
                    severity = if (artifact.isRemoteLocation(loaded.errorMessage)) ArchitectureDiagnosticSeverity.WARNING else ArchitectureDiagnosticSeverity.ERROR,
                    code = "artifact-load-failed",
                    source = artifactSource(manifest.uri, artifact),
                    semanticId = artifactNodeId(artifact),
                )
                continue
            }
            val context = ManifestGraphArtifactContext(
                manifest = manifest,
                catalog = catalog,
                artifact = artifact,
                content = content,
                sourceUri = resource.referenceUri(),
            )
            matchingAnalyzers.forEach { analyzer ->
                val contribution = try {
                    analyzer.analyze(context)
                } catch (error: Exception) {
                    diagnostics += ArchitectureDiagnostic(
                        message = error.message ?: "Analyzer failed for '${artifact.artifact.path}'",
                        severity = ArchitectureDiagnosticSeverity.WARNING,
                        code = "artifact-analysis-failed",
                        source = artifactSource(resource.referenceUri(), artifact),
                        semanticId = artifactNodeId(artifact),
                    )
                    return@forEach
                }
                merge(contribution, nodes, edges, diagnostics)
            }
        }

        linkCrossArtifactEvidence(nodes, edges, diagnostics)
        validateBindingEdges(nodes, edges, diagnostics)
        merge(ConceptGraphContributor.contribute(nodes, edges), nodes, edges, diagnostics)
        relationshipResolvers.forEach { resolver ->
            val contribution = resolver.resolve(
                RelationshipResolverContext(manifest, ArchitectureGraph(nodes.values.toList(), edges.values.toList())),
            )
            merge(
                enforceResolverConfidence(contribution, resolver.maxConfidence, diagnostics),
                nodes, edges, diagnostics,
            )
        }
        validateConceptRepresentations(nodes, edges, diagnostics)

        val unresolvedSemanticInvocations = edges.values.filter { edge ->
            edge.kind == ArchitectureEdgeKind.INVOKES &&
                edge.provenance == ArchitectureProvenanceKind.INFERRED &&
                edge.target !in nodes
        }
        unresolvedSemanticInvocations.forEach { edge ->
            diagnostics += ArchitectureDiagnostic(
                message = "ZFL invocation '${edge.source}' cannot resolve ZDL method '${edge.target}'",
                    severity = ArchitectureDiagnosticSeverity.ERROR,
                    code = "unresolved-zdl-method-reference",
                source = edge.sourceInfo,
            )
            edges.remove(edge.id)
        }

        edges.values.filter { edge ->
            edge.kind == ArchitectureEdgeKind.RESOLVES_TO && edge.target !in nodes
        }.toList().forEach { edge ->
            val sourceNode = nodes[edge.source]
            diagnostics += ArchitectureDiagnostic(
                message = "ZFL ${if (sourceNode?.kind == ArchitectureNodeKind.ZFL_EVENT) "event" else "operation"} " +
                    "'${sourceNode?.label ?: edge.source}' cannot resolve its declared ZDL target",
                    severity = ArchitectureDiagnosticSeverity.ERROR,
                    code = if (sourceNode?.kind == ArchitectureNodeKind.ZFL_EVENT) "unresolved-zfl-event" else "unresolved-zfl-operation",
                source = edge.sourceInfo ?: sourceNode?.source,
            )
            edges.remove(edge.id)
        }

        val missingTargets = edges.values.filter { it.source !in nodes || it.target !in nodes }
        missingTargets.forEach { edge ->
            diagnostics += ArchitectureDiagnostic(
                message = "Graph edge '${edge.id}' refers to a missing node",
                severity = ArchitectureDiagnosticSeverity.ERROR,
                code = "dangling-graph-edge",
                source = edge.sourceInfo,
            )
            edges.remove(edge.id)
        }

        val semanticAliases = semanticAliases(manifest, nodes.keys)
        diagnostics += semanticAliases.diagnostics
        val keyedDiagnostics = keyDiagnostics(diagnostics, nodes, edges)
        return ArchitectureGraphResult(
            graph = ArchitectureGraph(nodes.values.toList(), edges.values.toList(), semanticAliases.values),
            diagnostics = keyedDiagnostics,
        )
    }

    private fun addManifestStructure(
        manifest: ZenWaveManifest,
        nodes: MutableMap<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
    ) {
        manifest.domains.forEach { domain ->
            val domainId = ArchitectureGraphIds.domain(domain.key)
            nodes[domainId] = ArchitectureNode(
                id = domainId,
                kind = ArchitectureNodeKind.DOMAIN,
                label = domain.name ?: domain.id,
                attributes = attributes("key" to domain.key, "version" to domain.version),
                source = ArchitectureSource(manifest.uri, semanticPath = "domains.${domain.key}"),
                identityOrigin = ArchitectureIdentityOrigin.EXPLICIT,
            )
            domain.subdomains.forEach { subdomain ->
                val subdomainId = ArchitectureGraphIds.subdomain(domain.key, subdomain.key)
                nodes[subdomainId] = ArchitectureNode(
                    id = subdomainId,
                    kind = ArchitectureNodeKind.SUBDOMAIN,
                    label = subdomain.name ?: subdomain.id,
                    ownerId = domainId,
                    attributes = attributes("key" to subdomain.key, "version" to subdomain.version),
                    source = ArchitectureSource(
                        manifest.uri,
                        semanticPath = "domains.${domain.key}.subdomains.${subdomain.key}",
                    ),
                    identityOrigin = ArchitectureIdentityOrigin.EXPLICIT,
                )
                addEdge(edges, ArchitectureEdgeKind.CONTAINS, domainId, subdomainId, ArchitectureProvenanceKind.MANIFEST)
                subdomain.services.forEach { service -> addService(manifest, service, subdomainId, nodes, edges) }
            }
            domain.services.forEach { service ->
                val parent = service.subdomainKey?.let { ArchitectureGraphIds.subdomain(domain.key, it) } ?: domainId
                addService(manifest, service, parent, nodes, edges)
            }
        }
        manifest.services.forEach { service ->
            val serviceId = ArchitectureGraphIds.service(service.serviceRef)
            if (serviceId !in nodes) addService(manifest, service, null, nodes, edges)
        }
    }

    private fun addService(
        manifest: ZenWaveManifest,
        service: ManifestService,
        parentId: String?,
        nodes: MutableMap<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
    ) {
        val serviceId = ArchitectureGraphIds.service(service.serviceRef)
        nodes[serviceId] = ArchitectureNode(
            id = serviceId,
            kind = ArchitectureNodeKind.SERVICE,
            label = service.name ?: service.id,
            ownerId = parentId,
            attributes = attributes(
                "serviceRef" to service.serviceRef,
                "repository" to service.repository,
                "version" to service.version,
            ),
            source = ArchitectureSource(manifest.uri, semanticPath = service.serviceRef),
            identityOrigin = ArchitectureIdentityOrigin.EXPLICIT,
        )
        if (parentId != null) addEdge(edges, ArchitectureEdgeKind.CONTAINS, parentId, serviceId, ArchitectureProvenanceKind.MANIFEST)
    }

    private fun addArtifact(
        artifact: ResolvedManifestArtifact,
        manifest: ZenWaveManifest,
        nodes: MutableMap<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
    ) {
        val id = artifactNodeId(artifact)
        val ownerId = when (val owner = artifact.owner) {
            is ManifestDomain -> ArchitectureGraphIds.domain(owner.key)
            is ManifestService -> ArchitectureGraphIds.service(owner.serviceRef)
        }
        nodes[id] = ArchitectureNode(
            id = id,
            kind = ArchitectureNodeKind.ARTIFACT,
            label = artifact.artifact.name ?: artifact.artifactId,
            ownerId = ownerId,
            attributes = attributes(
                "artifactId" to artifact.artifactId,
                "type" to artifact.artifact.type,
                "path" to artifact.artifact.path,
                "version" to artifact.artifact.resolvedVersion,
                "repository" to artifact.repository,
            ),
            source = artifactSource(manifest.uri, artifact),
            identityOrigin = if (artifact.artifact.artifactId.isNullOrBlank()) {
                ArchitectureIdentityOrigin.DERIVED
            } else ArchitectureIdentityOrigin.EXPLICIT,
        )
        addEdge(edges, ArchitectureEdgeKind.DECLARES_ARTIFACT, ownerId, id, ArchitectureProvenanceKind.MANIFEST)
    }

    private fun addDeclaredConsumers(
        index: ManifestConsumerIndex,
        manifest: ZenWaveManifest,
        nodes: Map<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
    ) {
        index.edges.forEach { consumption ->
            val consumerId = artifactNodeId(consumption.consumerArtifact)
            consumption.providerArtifacts.forEach { provider ->
                val providerId = artifactNodeId(provider)
                if (consumerId in nodes && providerId in nodes) {
                    addEdge(
                        edges,
                        ArchitectureEdgeKind.CONSUMES,
                        consumerId,
                        providerId,
                        ArchitectureProvenanceKind.DECLARED_CONSUMER,
                        discriminator = consumption.reference.raw,
                        attributes = mapOf("consumerReference" to consumption.reference.raw),
                        source = ArchitectureSource(
                            manifest.uri,
                            semanticPath = "${consumption.providerService.serviceRef}.consumers",
                        ),
                    )
                }
            }
        }
    }

    private fun linkCrossArtifactEvidence(
        nodes: MutableMap<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
        diagnostics: MutableList<ArchitectureDiagnostic>,
    ) {
        val artifactNodes = nodes.values.filter { it.kind == ArchitectureNodeKind.ARTIFACT }
        val channels = nodes.values.filter { it.kind == ArchitectureNodeKind.CHANNEL }

        nodes.values.filter { it.kind == ArchitectureNodeKind.ZDL_METHOD }.forEach { method ->
            val referencedApis = outgoingEdgeTargets(method.id, ArchitectureEdgeKind.REFERENCES_API, nodes, edges)
                .filter { it.kind == ArchitectureNodeKind.ZDL_API }

            val httpMethod = method.attributes["httpMethod"]
            val restPath = method.attributes["restPath"]
            if (httpMethod != null && restPath != null) {
                val openApiArtifacts = referencedApis
                    .filter { it.attributes["type"] == "openapi" }
                    .flatMap { outgoingEdgeTargets(it.id, ArchitectureEdgeKind.REFERENCES_API, nodes, edges) }
                    .filter { it.kind == ArchitectureNodeKind.ARTIFACT }
                    .distinctBy { it.id }
                val matches = openApiArtifacts.flatMap { artifact ->
                    nodes.values.filter { candidate ->
                        candidate.kind == ArchitectureNodeKind.API_OPERATION &&
                            candidate.ownerId == artifact.id &&
                            candidate.attributes["method"] == httpMethod &&
                            normalizePath(candidate.attributes["path"].orEmpty()) == normalizePath(restPath)
                    }
                }
                if (matches.size == 1) {
                    val target = matches.single()
                    val intent = target.attributes["intent"] ?: if (httpMethod in setOf("GET", "HEAD")) "query" else "command"
                    addEdge(
                        edges, ArchitectureEdgeKind.BINDS_TO, method.id, target.id,
                        ArchitectureProvenanceKind.INFERRED, discriminator = "openapi-invocation",
                        attributes = attributes(
                            ArchitectureBindingAttributes.ROLE to ArchitectureBindingValues.ROLE_INVOCATION,
                            ArchitectureBindingAttributes.TRANSPORT to ArchitectureBindingValues.TRANSPORT_OPENAPI,
                            ArchitectureBindingAttributes.MESSAGE_KIND to intent,
                            ArchitectureBindingAttributes.DIRECTION to ArchitectureBindingValues.DIRECTION_RECEIVE,
                            ArchitectureBindingAttributes.OPERATION_ID to target.attributes["operationId"],
                            ArchitectureBindingAttributes.METHOD to httpMethod,
                            ArchitectureBindingAttributes.PATH to target.attributes["path"],
                        ),
                        source = method.source,
                        confidence = ArchitectureConfidence.INFERRED_HEURISTIC,
                    )
                } else {
                    diagnostics += ArchitectureDiagnostic(
                        message = "ZDL method '${method.label}' ${if (matches.isEmpty()) "cannot resolve" else "ambiguously resolves"} OpenAPI operation '$httpMethod $restPath'",
                        severity = ArchitectureDiagnosticSeverity.WARNING,
                        code = if (matches.isEmpty()) "unresolved-openapi-operation-binding" else "ambiguous-openapi-operation-binding",
                        source = method.source,
                    )
                }
            }

            val apiName = method.attributes["asyncapiApi"] ?: return@forEach
            val channelKey = method.attributes["asyncapiChannel"]
            val topic = method.attributes["asyncapiTopic"]
            val apiNode = outgoingEdgeTargets(method.id, ArchitectureEdgeKind.REFERENCES_API, nodes, edges)
                .firstOrNull { it.kind == ArchitectureNodeKind.ZDL_API && (it.label == apiName || it.attributes["name"] == apiName) }
                ?: return@forEach
            val providerArtifact = outgoingEdgeTargets(apiNode.id, ArchitectureEdgeKind.REFERENCES_API, nodes, edges)
                .singleOrNull { it.kind == ArchitectureNodeKind.ARTIFACT }
            val channel = providerArtifact?.let { artifact ->
                channels.filter { it.ownerId == artifact.id }.singleOrNull {
                    (channelKey != null && it.attributes["channelKey"] == channelKey) ||
                        (topic != null && it.attributes["address"] == topic)
                }
            }
            if (channel == null) {
                diagnostics += ArchitectureDiagnostic(
                    message = "ZDL method '${method.label}' references unresolved AsyncAPI channel '${channelKey ?: topic}'",
                    severity = ArchitectureDiagnosticSeverity.ERROR,
                    code = "unresolved-channel-reference",
                    source = method.source,
                )
                return@forEach
            }
            val kind = if (apiNode.attributes["role"] == "client") {
                ArchitectureEdgeKind.CONSUMES
            } else {
                ArchitectureEdgeKind.EMITS
            }
            addEdge(
                edges, kind, method.id, channel.id, ArchitectureProvenanceKind.INFERRED,
                discriminator = apiNode.id,
                attributes = attributes(
                    "api" to apiName,
                    "channel" to channelKey,
                    "topic" to topic,
                ),
                source = method.source,
            )
            val channelOperations = nodes.values.filter { operation ->
                operation.kind == ArchitectureNodeKind.API_OPERATION && operation.ownerId == channel.ownerId
            }.filter { operation ->
                edges.values.any { edge -> edge.source == operation.id && edge.target == channel.id }
            }
            val action = channelOperations.mapNotNull { it.attributes["action"] }.distinct().singleOrNull()
            if (action == null) {
                diagnostics += ArchitectureDiagnostic(
                    message = "ZDL method '${method.label}' references AsyncAPI channel '${channel.label}' without one unambiguous direction",
                    severity = ArchitectureDiagnosticSeverity.WARNING,
                    code = "unsupported-asyncapi-binding-direction",
                    source = method.source,
                )
            } else {
                val messageKind = channel.attributes["messageKind"] ?: ArchitectureBindingValues.KIND_EVENT
                val role = when {
                    messageKind == ArchitectureBindingValues.KIND_COMMAND && action == ArchitectureBindingValues.DIRECTION_RECEIVE -> ArchitectureBindingValues.ROLE_INVOCATION
                    messageKind == ArchitectureBindingValues.KIND_EVENT && action == ArchitectureBindingValues.DIRECTION_RECEIVE -> ArchitectureBindingValues.ROLE_TRIGGER
                    else -> ArchitectureBindingValues.ROLE_EMISSION
                }
                addEdge(
                    edges, ArchitectureEdgeKind.BINDS_TO, method.id, channel.id,
                    ArchitectureProvenanceKind.INFERRED, discriminator = "asyncapi-$role",
                    attributes = attributes(
                        ArchitectureBindingAttributes.ROLE to role,
                        ArchitectureBindingAttributes.TRANSPORT to ArchitectureBindingValues.TRANSPORT_ASYNCAPI,
                        ArchitectureBindingAttributes.MESSAGE_KIND to messageKind,
                        ArchitectureBindingAttributes.DIRECTION to action,
                        ArchitectureBindingAttributes.CHANNEL_KEY to channel.attributes["channelKey"],
                        ArchitectureBindingAttributes.ADDRESS to channel.attributes["address"],
                        ArchitectureBindingAttributes.OPERATION_ID to channelOperations.singleOrNull()?.label,
                    ),
                    source = method.source,
                )
            }
        }

        nodes.values.filter { it.kind == ArchitectureNodeKind.ZDL_EVENT }.forEach { event ->
            val channelKey = event.attributes["asyncapiChannel"]
            val topic = event.attributes["asyncapiTopic"]
            if (channelKey == null && topic == null) return@forEach
            val zdlArtifact = event.ownerChain(nodes).firstOrNull { it.kind == ArchitectureNodeKind.ARTIFACT }
                ?: return@forEach
            val manifestOwnerId = zdlArtifact.ownerId ?: return@forEach
            val asyncApiArtifactIds = artifactNodes.filter {
                it.ownerId == manifestOwnerId && it.attributes["type"] == "asyncapi"
            }.mapTo(mutableSetOf()) { it.id }
            val channel = channels.filter { it.ownerId in asyncApiArtifactIds }.singleOrNull {
                (channelKey != null && it.attributes["channelKey"] == channelKey) ||
                    (topic != null && it.attributes["address"] == topic)
            }
            if (channel == null) {
                diagnostics += ArchitectureDiagnostic(
                    message = "ZDL event '${event.label}' references unresolved AsyncAPI channel '${channelKey ?: topic}'",
                    severity = ArchitectureDiagnosticSeverity.ERROR,
                    code = "unresolved-channel-reference",
                    source = event.source,
                )
                return@forEach
            }
            addEdge(
                edges, ArchitectureEdgeKind.EMITS, event.id, channel.id, ArchitectureProvenanceKind.INFERRED,
                discriminator = "zdl-event-channel",
                attributes = attributes("channel" to channelKey, "topic" to topic),
                source = event.source,
            )
            addEdge(
                edges, ArchitectureEdgeKind.BINDS_TO, event.id, channel.id, ArchitectureProvenanceKind.INFERRED,
                discriminator = "asyncapi-emission",
                attributes = attributes(
                    ArchitectureBindingAttributes.ROLE to ArchitectureBindingValues.ROLE_EMISSION,
                    ArchitectureBindingAttributes.TRANSPORT to ArchitectureBindingValues.TRANSPORT_ASYNCAPI,
                    ArchitectureBindingAttributes.MESSAGE_KIND to ArchitectureBindingValues.KIND_EVENT,
                    ArchitectureBindingAttributes.DIRECTION to ArchitectureBindingValues.DIRECTION_SEND,
                    ArchitectureBindingAttributes.CHANNEL_KEY to channel.attributes["channelKey"],
                    ArchitectureBindingAttributes.ADDRESS to channel.attributes["address"],
                ),
                source = event.source,
            )
        }
    }

    private fun validateBindingEdges(
        nodes: Map<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
        diagnostics: MutableList<ArchitectureDiagnostic>,
    ) {
        edges.values.filter { it.kind == ArchitectureEdgeKind.BINDS_TO }.toList().forEach { edge ->
            val binding = ArchitectureOperationBinding.from(edge)
            val source = nodes[edge.source]
            val target = nodes[edge.target]
            val validTarget = when (binding?.transport) {
                ArchitectureBindingTransport.OPENAPI -> target?.kind == ArchitectureNodeKind.API_OPERATION
                ArchitectureBindingTransport.ASYNCAPI -> target?.kind == ArchitectureNodeKind.CHANNEL
                null -> false
            }
            val validSource = source?.kind in setOf(ArchitectureNodeKind.ZDL_METHOD, ArchitectureNodeKind.ZDL_EVENT)
            val validInvocation = binding?.role != ArchitectureBindingRole.INVOCATION ||
                (binding.direction == ArchitectureBindingDirection.RECEIVE &&
                    (binding.messageKind != ArchitectureBindingMessageKind.QUERY ||
                        binding.transport == ArchitectureBindingTransport.OPENAPI && binding.method in setOf("GET", "HEAD")))
            if (binding == null || !validTarget || !validSource || !validInvocation) {
                diagnostics += ArchitectureDiagnostic(
                    message = "Invalid operation binding edge '${edge.id}'",
                    severity = ArchitectureDiagnosticSeverity.WARNING,
                    code = "invalid-binding-edge",
                    source = edge.sourceInfo,
                )
                edges.remove(edge.id)
            }
        }
    }

    private fun merge(
        contribution: ManifestGraphContribution,
        nodes: MutableMap<String, ArchitectureNode>,
        edges: MutableMap<String, ArchitectureEdge>,
        diagnostics: MutableList<ArchitectureDiagnostic>,
    ) {
        contribution.nodes.forEach { node ->
            val existing = nodes[node.id]
            if (existing != null && existing.copy(evidence = emptyList()) != node.copy(evidence = emptyList())) {
                diagnostics += ArchitectureDiagnostic(
                    message = "Analyzer produced conflicting node id '${node.id}'",
                    severity = ArchitectureDiagnosticSeverity.ERROR,
                    code = "duplicate-graph-node",
                    source = node.source,
                )
            } else {
                nodes[node.id] = if (existing == null) node else existing.copy(
                    evidence = (existing.evidence + node.evidence).distinct(),
                )
            }
        }
        contribution.edges.forEach { edge ->
            val existing = edges[edge.id]
            if (existing != null && existing.structuralIdentity() != edge.structuralIdentity()) {
                diagnostics += ArchitectureDiagnostic(
                    message = "Analyzer produced conflicting edge id '${edge.id}'",
                    severity = ArchitectureDiagnosticSeverity.ERROR,
                    code = "duplicate-graph-edge",
                    source = edge.sourceInfo,
                )
            } else {
                edges[edge.id] = if (existing == null) edge else existing.copy(
                    confidence = strongerConfidence(existing.confidence, edge.confidence),
                    evidence = (existing.evidence + edge.evidence).distinct(),
                )
            }
        }
        diagnostics += contribution.diagnostics
    }
}

private fun io.zenwave360.architecture.manifest.ManifestDiagnostic.toArchitectureDiagnostic(manifestUri: String): ArchitectureDiagnostic =
    ArchitectureDiagnostic(
        message = message,
        severity = when (severity) {
            ManifestDiagnosticSeverity.ERROR -> ArchitectureDiagnosticSeverity.ERROR
            ManifestDiagnosticSeverity.WARNING -> ArchitectureDiagnosticSeverity.WARNING
        },
        code = code ?: "api-consumption-diagnostic",
        source = ArchitectureSource(manifestUri, semanticPath = location),
    )

private fun outgoingEdgeTargets(
    sourceId: String,
    kind: ArchitectureEdgeKind,
    nodes: Map<String, ArchitectureNode>,
    edges: Map<String, ArchitectureEdge>,
): List<ArchitectureNode> = edges.values.filter { it.source == sourceId && it.kind == kind }
    .mapNotNull { nodes[it.target] }

private fun ArchitectureNode.ownerChain(nodes: Map<String, ArchitectureNode>): Sequence<ArchitectureNode> = sequence {
    var current: ArchitectureNode? = this@ownerChain
    val visited = mutableSetOf<String>()
    while (current != null && visited.add(current.id)) {
        yield(current)
        current = current.ownerId?.let(nodes::get)
    }
}

private fun strongerConfidence(
    left: ArchitectureConfidence,
    right: ArchitectureConfidence,
): ArchitectureConfidence {
    val order = listOf(
        ArchitectureConfidence.INFERRED_HEURISTIC,
        ArchitectureConfidence.INFERRED_EXACT,
        ArchitectureConfidence.RESOLVED,
        ArchitectureConfidence.DECLARED,
    )
    return if (order.indexOf(left) >= order.indexOf(right)) left else right
}

private fun enforceResolverConfidence(
    contribution: ManifestGraphContribution,
    maximum: ArchitectureConfidence,
    diagnostics: MutableList<ArchitectureDiagnostic>,
): ManifestGraphContribution {
    val strength = listOf(
        ArchitectureConfidence.INFERRED_HEURISTIC,
        ArchitectureConfidence.INFERRED_EXACT,
        ArchitectureConfidence.RESOLVED,
        ArchitectureConfidence.DECLARED,
    )
    fun capped(evidence: ArchitectureEvidence): ArchitectureEvidence =
        if (strength.indexOf(evidence.confidence) > strength.indexOf(maximum)) evidence.copy(confidence = maximum)
        else evidence
    val nodes = contribution.nodes.map { node ->
        val exceeded = node.evidence.any { strength.indexOf(it.confidence) > strength.indexOf(maximum) }
        if (exceeded) diagnostics += ArchitectureDiagnostic(
            message = "Relationship resolver emitted node evidence above its declared maximum $maximum",
            severity = ArchitectureDiagnosticSeverity.ERROR,
            code = "resolver-confidence-exceeded",
            source = node.source,
            semanticId = node.id.takeIf { it.startsWith("zw:") },
        )
        node.copy(evidence = node.evidence.map(::capped))
    }
    return contribution.copy(nodes = nodes, edges = contribution.edges.map { edge ->
        if (strength.indexOf(edge.confidence) <= strength.indexOf(maximum)) return@map edge
        diagnostics += ArchitectureDiagnostic(
            message = "Relationship resolver emitted ${edge.confidence} above its declared maximum $maximum",
            severity = ArchitectureDiagnosticSeverity.ERROR,
            code = "resolver-confidence-exceeded",
            source = edge.sourceInfo,
            semanticId = edge.source.takeIf { it.startsWith("zw:") },
        )
        edge.copy(
            confidence = maximum,
            evidence = edge.evidence.map { evidence -> evidence.copy(confidence = maximum) },
        )
    })
}

private fun keyDiagnostics(
    diagnostics: List<ArchitectureDiagnostic>,
    nodes: Map<String, ArchitectureNode>,
    edges: Map<String, ArchitectureEdge>,
): List<ArchitectureDiagnostic> {
    val representedConcept = edges.values
        .filter { it.kind == ArchitectureEdgeKind.REPRESENTS }
        .associate { it.source to it.target }
    return diagnostics.map { diagnostic ->
        if (diagnostic.semanticId != null) return@map diagnostic
        val source = diagnostic.source ?: return@map diagnostic
        val representation = nodes.values.firstOrNull { node ->
            val nodeSource = node.source
            nodeSource?.artifactOwnerRef == source.artifactOwnerRef &&
                nodeSource?.artifactId == source.artifactId &&
                source.artifactId != null &&
                (source.semanticPath == null || nodeSource?.semanticPath == source.semanticPath)
        } ?: nodes.values.firstOrNull { node ->
            val nodeSource = node.source
            source.semanticPath != null && nodeSource?.uri == source.uri && nodeSource.semanticPath == source.semanticPath
        }
        diagnostic.copy(semanticId = representation?.let { representedConcept[it.id] ?: it.id })
    }
}

private fun ArchitectureEdge.structuralIdentity(): List<Any?> =
    listOf(id, kind, source, target, label, attributes)

private fun ResolvedManifestArtifact.isRemoteLocation(errorMessage: String?): Boolean {
    val values = listOfNotNull(artifact.path, repository, errorMessage)
    return values.any {
        it.contains("http://") || it.contains("https://") || it.contains("git:") ||
            it.contains("maven:") || it.contains("jar:")
    }
}

private fun validateConceptRepresentations(
    nodes: Map<String, ArchitectureNode>,
    edges: Map<String, ArchitectureEdge>,
    diagnostics: MutableList<ArchitectureDiagnostic>,
) {
    val represented = edges.values.asSequence()
        .filter { it.kind == ArchitectureEdgeKind.REPRESENTS }
        .map { it.source }
        .toSet()
    nodes.values.filter { node ->
        node.kind == ArchitectureNodeKind.CHANNEL ||
            node.kind == ArchitectureNodeKind.API_OPERATION && node.attributes["intent"] == "command"
    }.filter { it.id !in represented }.forEach { node ->
        diagnostics += ArchitectureDiagnostic(
            message = "${node.kind.name.lowercase().replace('_', ' ')} '${node.label}' has no architecture concept",
            severity = ArchitectureDiagnosticSeverity.ERROR,
            code = "missing-represents-edge",
            source = node.source,
            semanticId = node.id,
        )
    }
}

private fun validateSemanticNamespace(
    nodes: Map<String, ArchitectureNode>,
    diagnostics: MutableList<ArchitectureDiagnostic>,
) {
    val reserved = conceptKinds.map { it.name.lowercase().replace('_', '-') }.toSet() +
        setOf("artifact", "channel", "api-operation")
    nodes.values.filter { node ->
        val ownerKind = node.ownerId?.let(nodes::get)?.kind
        (node.kind == ArchitectureNodeKind.SUBDOMAIN ||
            node.kind == ArchitectureNodeKind.SERVICE && ownerKind == ArchitectureNodeKind.DOMAIN) &&
            node.id.substringAfterLast('/') in reserved
    }.forEach { node ->
        diagnostics += ArchitectureDiagnostic(
            message = "Structural segment '${node.id.substringAfterLast('/')}' is reserved for semantic node kinds",
            severity = ArchitectureDiagnosticSeverity.ERROR,
            code = "reserved-semantic-segment",
            source = node.source,
            semanticId = node.id,
        )
    }
}

private fun normalizePath(path: String): String = path
    .replace(Regex("\\{[^}/]+}"), "{}")
    .replace(Regex("/+"), "/")
    .removeSuffix("/")
    .ifEmpty { "/" }

internal fun artifactNodeId(artifact: ResolvedManifestArtifact): String =
    ArchitectureGraphIds.artifact(artifact.ownerRef, artifact.artifactId)

internal fun artifactSource(uri: String, artifact: ResolvedManifestArtifact, path: String? = null): ArchitectureSource =
    ArchitectureSource(uri, artifact.ownerRef, artifact.artifactId, path)

internal fun addEdge(
    edges: MutableMap<String, ArchitectureEdge>,
    kind: ArchitectureEdgeKind,
    sourceId: String,
    targetId: String,
    provenance: ArchitectureProvenanceKind,
    discriminator: String = "",
    label: String? = null,
    attributes: Map<String, String> = emptyMap(),
    source: ArchitectureSource? = null,
    confidence: ArchitectureConfidence = provenance.defaultConfidence(),
) {
    val id = ArchitectureGraphIds.edge(kind, sourceId, targetId, discriminator)
    edges[id] = ArchitectureEdge(
        id, kind, sourceId, targetId, label, attributes, provenance, source, confidence,
    )
}

internal fun attributes(vararg values: Pair<String, String?>): Map<String, String> =
    values.mapNotNull { (key, value) -> value?.takeIf(String::isNotBlank)?.let { key to it } }.toMap()

private fun defaultArtifactAnalyzers(): List<ManifestGraphArtifactAnalyzer> =
    listOf(ZdlGraphArtifactAnalyzer(), ZflGraphArtifactAnalyzer())
