package io.zenwave360.architecture.manifest

import io.zenwave360.jsonrefparser.RefParser
import io.zenwave360.jsonrefparser.io.DocumentLoader
import io.zenwave360.jsonrefparser.io.defaultLoaders
import io.zenwave360.jsonrefparser.model.ParsedDocument
import kotlin.jvm.JvmOverloads

class ManifestResolutionException(message: String) : IllegalArgumentException(message)

class ManifestResourceLoadException(
    message: String,
    val candidates: List<ManifestResolvedResource>,
    cause: Throwable? = null,
    /** What happened to the last candidate tried, credentials removed; null when no candidate was tried. */
    val finalError: String? = null,
    /** What happened to each candidate, in the order of [candidates], credentials removed. */
    val candidateErrors: List<String> = emptyList(),
) : IllegalStateException(message, cause)

/**
 * Internal parser result used by manifest editors that need to retain the source document and
 * JSON-pointer location of a resolved manifest node.
 */
internal data class ParsedManifestDocument(
    val manifest: ZenWaveManifest,
    val document: ParsedDocument,
)

@Suppress("unused")
class ZenWaveManifestLoader(
    private val documentLoaders: List<DocumentLoader> = defaultLoaders(),
    private val archiveEntryLoader: ManifestArchiveEntryLoader? = defaultManifestArchiveEntryLoader(),
) {
    suspend fun load(uri: String): ZenWaveManifest {
        val normalizedUri = ManifestReferenceResolver.normalizeUri(uri)
        return parse(normalizedUri, loadText(normalizedUri))
    }

    suspend fun parse(uri: String, text: String): ZenWaveManifest {
        return parseDocument(uri, text).manifest
    }

    internal suspend fun parseDocument(uri: String, text: String): ParsedManifestDocument {
        val normalizedUri = ManifestReferenceResolver.normalizeUri(uri)
        val document = RefParser.fromText(
            shieldConsumerRefs(text),
            baseUri = normalizedUri,
            loaders = manifestDocumentLoaders(),
        ).dereference().getParsedDocument()
        val root = document.schema
        val configNode = root.mapAt("config")
        val diagnostics = mutableListOf<ManifestDiagnostic>()
        val properties = parseProperties(configNode.mapAt("properties"), diagnostics)
        val contentResolution = (configNode["contentResolution"] as? List<*>)
            ?.mapNotNull { it?.toString() }
            ?: listOf(ManifestSourceName.WORKSPACE)
        val groupIdExpression = expandStatic(
            configNode["groupIdExpression"]?.toString() ?: "\${owner.id}",
            "config.groupIdExpression",
            properties,
            diagnostics,
            allowRuntime = true,
        )
        val artifactIdExpression = expandStatic(
            configNode["artifactIdExpression"]?.toString() ?: "\${artifact.pathWithoutExtension}",
            "config.artifactIdExpression",
            properties,
            diagnostics,
            allowRuntime = true,
        )
        validateCoordinateExpression(groupIdExpression, "config.groupIdExpression", diagnostics)
        validateCoordinateExpression(artifactIdExpression, "config.artifactIdExpression", diagnostics)
        val sources = parseSources(configNode.mapAt("sources"), properties, diagnostics)
        validateContentResolution(contentResolution, sources, diagnostics)
        val config = ManifestConfig(
            title = configNode["title"]?.toString(),
            version = configNode["version"].stringValue(),
            groupIdExpression = groupIdExpression,
            artifactIdExpression = artifactIdExpression,
            properties = properties,
            contentResolution = contentResolution,
            sources = sources,
        )

        val allServices = mutableListOf<ManifestService>()
        val domains = root.mapAt("domains").map { (domainKey, domainValue) ->
            parseDomain(properties, diagnostics, allServices, domainKey, domainValue.asMap())
        }
        diagnoseConsumerServices(allServices, diagnostics)
        return ParsedManifestDocument(
            ZenWaveManifest(normalizedUri, config, domains, allServices, diagnostics),
            document,
        )
    }

    suspend fun loadResourceText(uri: String): String =
        loadText(ManifestReferenceResolver.normalizeUri(uri))

    suspend fun loadServiceDocs(
        manifest: ZenWaveManifest,
        service: ManifestService,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): Map<String, String> = service.docs.mapValues { (key, path) ->
        loadOwnedResourceText(
            manifest,
            service,
            path,
            artifact = null,
            location = "${service.serviceRef}.docs.$key",
            options = options,
        ).second
    }

    /**
     * Loads every configured service document independently, retaining failures as values.
     *
     * This is the preferred batch API for LSP/MCP and other tooling that should report a broken
     * document without discarding documents that loaded successfully.
     */
    suspend fun loadServiceDocResults(
        manifest: ZenWaveManifest,
        service: ManifestService,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): Map<String, ManifestResourceLoadResult> = buildMap {
        service.docs.forEach { (key, path) ->
            val result = try {
                val (resource, content) = loadOwnedResourceText(
                    manifest,
                    service,
                    path,
                    artifact = null,
                    location = "${service.serviceRef}.docs.$key",
                    options = options,
                )
                ManifestResourceLoadResult(path, resource, content)
            } catch (error: Exception) {
                ManifestResourceLoadResult(
                    path = path,
                    errorMessage = error.message ?: "Cannot load document '$path'",
                )
            }
            put(key, result)
        }
    }

    /**
     * Convenience batch API that skips documents which cannot be loaded.
     *
     * Use [loadServiceDocResults] when callers need per-document failure details.
     */
    suspend fun loadAvailableServiceDocs(
        manifest: ZenWaveManifest,
        service: ManifestService,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): Map<String, String> = loadServiceDocResults(manifest, service, options)
        .mapNotNull { (key, result) -> result.content?.let { key to it } }
        .toMap()

    suspend fun loadServiceArtifacts(
        manifest: ZenWaveManifest,
        service: ManifestService,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): Map<ManifestArtifact, String> = service.artifacts.associateWith {
        loadArtifactText(manifest, service, it, options)
    }

    suspend fun loadArtifactText(
        manifest: ZenWaveManifest,
        service: ManifestService,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): String = loadArtifactText(manifest, service as ManifestArtifactOwner, artifact, options)

    suspend fun loadArtifactText(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): String = loadOwnedResourceText(
        manifest,
        owner,
        artifact.path,
        artifact,
        "${owner.artifactOwnerRef}.artifacts.${artifact.name ?: artifact.path}",
        options,
    ).second

    suspend fun loadArtifactResult(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResourceLoadResult = try {
        val (resource, content) = loadOwnedResourceText(
            manifest,
            owner,
            artifact.path,
            artifact,
            "${owner.artifactOwnerRef}.artifacts.${artifact.name ?: artifact.path}",
            options,
        )
        ManifestResourceLoadResult(artifact.path, resource, content)
    } catch (error: ManifestResourceLoadException) {
        ManifestResourceLoadResult(
            path = artifact.path,
            errorMessage = error.message ?: "Cannot load artifact '${artifact.path}'",
            candidates = error.candidates,
            finalError = error.finalError,
            candidateErrors = error.candidateErrors,
        )
    } catch (error: Exception) {
        ManifestResourceLoadResult(
            path = artifact.path,
            errorMessage = error.message ?: "Cannot load artifact '${artifact.path}'",
        )
    }

    suspend fun resolveArtifact(
        manifest: ZenWaveManifest,
        service: ManifestService,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResolvedResource = resolveArtifact(manifest, service as ManifestArtifactOwner, artifact, options)

    suspend fun resolveArtifact(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResolvedResource = loadOwnedResourceText(
        manifest,
        owner,
        artifact.path,
        artifact,
        "${owner.artifactOwnerRef}.artifacts.${artifact.name ?: artifact.path}",
        options,
    ).first

    fun artifactResolutionContext(
        manifest: ZenWaveManifest,
        service: ManifestService,
        artifact: ManifestArtifact,
    ): ManifestResolutionContext = artifactResolutionContext(manifest, service as ManifestArtifactOwner, artifact)

    fun artifactResolutionContext(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
    ): ManifestResolutionContext {
        val base = baseContext(owner, artifact, artifact.path).copy(properties = manifest.config.properties)
        val coordinates = resolveCoordinates(manifest, base, owner, artifact)
        return base.copy(groupId = coordinates.groupId, artifactId = coordinates.artifactId)
    }

    fun documentResolutionContext(
        manifest: ZenWaveManifest,
        service: ManifestService,
        path: String,
    ): ManifestResolutionContext = baseContext(service, null, path).copy(properties = manifest.config.properties)

    fun buildArtifactCandidates(
        manifest: ZenWaveManifest,
        service: ManifestService,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): List<ManifestResolvedResource> =
        buildArtifactCandidates(manifest, service as ManifestArtifactOwner, artifact, options)

    fun buildArtifactCandidates(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): List<ManifestResolvedResource> {
        if (ManifestReferenceResolver.hasScheme(artifact.path)) return listOf(directResource(artifact.path))
        return buildResourceCandidates(
            manifest,
            owner,
            artifact,
            artifact.path,
            baseContext(owner, artifact, artifact.path).copy(properties = manifest.config.properties),
            options,
        )
    }

    /**
     * SR-R5: candidates for a path next to a declared artifact, loaded as a document of [owner] at
     * [version]. `${version}` is [version] as given (blank means unset), `${content.path}` is the
     * normalised [path], and `${artifact.*}` is unresolved. Apicurio and Maven are skipped.
     *
     * @throws ManifestResolutionException if [path] is empty, has a scheme, or leaves the owner's
     * content with a `..` above the root.
     */
    fun buildOwnedDocumentCandidates(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        version: String?,
        path: String,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): List<ManifestResolvedResource> {
        val normalized = normalizeOwnedPath(path)
        val context = baseContext(owner, null, normalized)
            .copy(version = version.nonBlankOrNull(), properties = manifest.config.properties)
        return buildResourceCandidates(manifest, owner, null, normalized, context, options)
    }

    /** SR-R5: loads a path next to a declared artifact through the ordered sources; see [buildOwnedDocumentCandidates]. */
    suspend fun loadOwnedDocument(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        version: String?,
        path: String,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResourceLoadResult {
        val normalized = normalizeOwnedPath(path)
        val (resource, content) = loadOwnedResourceText(
            manifest,
            owner,
            normalized,
            artifact = null,
            location = "${owner.artifactOwnerRef}.documents.$normalized",
            options = options,
            givenVersion = GivenVersion(version.nonBlankOrNull()),
        )
        return ManifestResourceLoadResult(normalized, resource, content)
    }

    private class GivenVersion(val value: String?)

    private fun normalizeOwnedPath(path: String): String {
        if (ManifestReferenceResolver.hasScheme(path)) {
            throw ManifestResolutionException("Path '$path' is not relative to its owner")
        }
        val segments = mutableListOf<String>()
        for (segment in path.replace('\\', '/').split('/')) {
            when (segment) {
                "", "." -> Unit
                ".." -> if (segments.isEmpty()) {
                    throw ManifestResolutionException("Path '$path' leaves the owner's content")
                } else {
                    segments.removeAt(segments.lastIndex)
                }
                else -> segments.add(segment)
            }
        }
        if (segments.isEmpty()) throw ManifestResolutionException("Path '$path' is empty")
        return segments.joinToString("/")
    }

    fun buildDocumentCandidates(
        manifest: ZenWaveManifest,
        service: ManifestService,
        documentKey: String,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): List<ManifestResolvedResource> {
        val path = service.docs[documentKey]
            ?: throw ManifestResolutionException("Service document key '$documentKey' is not declared in '${service.serviceRef}'")
        if (ManifestReferenceResolver.hasScheme(path)) return listOf(directResource(path))
        return buildResourceCandidates(
            manifest,
            service,
            artifact = null,
            resourcePath = path,
            context = documentResolutionContext(manifest, service, path),
            options = options,
        )
    }

    @JvmOverloads
    fun resolveArtifactReference(
        manifest: ZenWaveManifest,
        service: ManifestService,
        artifact: ManifestArtifact,
        reference: String? = null,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResolvedResource? = resolveArtifactReference(
        manifest, service as ManifestArtifactOwner, artifact, reference, options,
    )

    @JvmOverloads
    fun resolveArtifactReference(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
        reference: String? = null,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResolvedResource? {
        val resource = buildArtifactCandidates(manifest, owner, artifact, options).firstOrNull()
            ?: return null
        return reference.nonBlankOrNull()?.let(resource::resolveReference) ?: resource
    }

    @JvmOverloads
    fun resolveDocumentReference(
        manifest: ZenWaveManifest,
        service: ManifestService,
        documentKey: String,
        reference: String? = null,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): ManifestResolvedResource? {
        val resource = buildDocumentCandidates(manifest, service, documentKey, options).firstOrNull()
            ?: return null
        return reference.nonBlankOrNull()?.let(resource::resolveReference) ?: resource
    }

    @JvmOverloads
    fun artifactReferenceUri(
        manifest: ZenWaveManifest,
        service: ManifestService,
        artifact: ManifestArtifact,
        reference: String? = null,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): String? = artifactReferenceUri(manifest, service as ManifestArtifactOwner, artifact, reference, options)

    @JvmOverloads
    fun artifactReferenceUri(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
        reference: String? = null,
        options: ManifestLoadOptions = ManifestLoadOptions(),
    ): String? = resolveArtifactReference(manifest, owner, artifact, reference, options)?.referenceUri()

    private suspend fun loadOwnedResourceText(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        resourcePath: String,
        artifact: ManifestArtifact?,
        location: String,
        options: ManifestLoadOptions,
        givenVersion: GivenVersion? = null,
    ): Pair<ManifestResolvedResource, String> {
        if (ManifestReferenceResolver.hasScheme(resourcePath)) {
            val direct = directResource(resourcePath)
            return direct to loadText(direct.uri)
        }
        val context = baseContext(owner, artifact, resourcePath).copy(properties = manifest.config.properties)
            .let { if (givenVersion != null) it.copy(version = givenVersion.value) else it }
        val candidates = buildResourceCandidates(manifest, owner, artifact, resourcePath, context, options)
        var lastError: Throwable? = null
        val candidateErrors = mutableListOf<String>()
        for (candidate in candidates) {
            try {
                val text = candidate.archiveEntry?.let { entry ->
                    // No archive reader here (JS without a host-supplied loader): report the
                    // capability as unavailable and let the next candidate be tried.
                    val loader = archiveEntryLoader
                        ?: throw ManifestCapabilityUnavailableException(
                            ManifestPlatform.ARCHIVE_EXTRACTION,
                            ManifestPlatform.name,
                        )
                    loader.loadEntry(candidate.uri, entry)
                } ?: loadText(candidate.uri)
                return candidate to text
            } catch (error: Throwable) {
                lastError = error
                candidateErrors += redactErrorMessage(error.message ?: error::class.simpleName.orEmpty())
            }
        }
        val safeCandidates = candidates.map { it.copy(uri = redactUri(it.uri)) }
        val finalError = lastError?.message?.let(::redactErrorMessage)
            ?: if (candidates.isEmpty() && isRemoteManifest(manifest) &&
                ManifestSourceName.WORKSPACE in manifest.config.contentResolution
            ) {
                "source 'workspace' was skipped because the manifest is remote (${redactUri(manifest.uri)})"
            } else {
                "no candidates were produced"
            }
        throw ManifestResourceLoadException(
            buildString {
                append("Unable to load resource for $location. Ordered candidates: ")
                append(safeCandidates.joinToString(", ") { "${it.source}:${it.uri}" }.ifEmpty { "<none>" })
                append(". Final load error: $finalError")
            },
            safeCandidates,
            cause = null,
            finalError = finalError,
            candidateErrors = candidateErrors,
        )
    }

    private fun buildResourceCandidates(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact?,
        resourcePath: String,
        context: ManifestResolutionContext,
        options: ManifestLoadOptions,
    ): List<ManifestResolvedResource> = resolveSourceOrder(applicableSources(manifest), options).flatMap { source ->
        validateSourceReady(source, manifest.config.sources)
        when (source) {
            ManifestSourceName.WORKSPACE -> workspaceCandidates(manifest, resourcePath, context)
            ManifestSourceName.GIT -> manifest.config.sources.git!!.let { configured ->
                val expression = gitExpression(configured)
                gitCandidates(
                    configured,
                    expression,
                    addSelectedCoordinates(manifest, owner, artifact, context, expression),
                )
            }
            ManifestSourceName.APICURIO -> if (artifact == null) emptyList() else {
                val configured = manifest.config.sources.apicurio!!
                val expression = configured.contentUrlExpression ?: APICURIO_DEFAULT_EXPRESSION
                apicurioCandidates(
                    configured,
                    expression,
                    addSelectedCoordinates(manifest, owner, artifact, context, expression),
                )
            }
            ManifestSourceName.ARTIFACTORY -> manifest.config.sources.artifactory!!.let { configured ->
                artifactoryCandidates(
                    configured,
                    addSelectedCoordinates(manifest, owner, artifact, context, configured.contentUrlExpression),
                )
            }
            ManifestSourceName.MAVEN -> if (artifact == null) emptyList() else {
                val coordinates = resolveCoordinates(manifest, context, owner, artifact)
                mavenCandidates(
                    manifest.config.sources.maven!!,
                    artifact,
                    context.copy(groupId = coordinates.groupId, artifactId = coordinates.artifactId),
                )
            }
            else -> throw ManifestResolutionException("Invalid content-resolution source '$source'")
        }
    }

    /** SR-R4: a manifest read from an `http(s)` address has no directory, so `workspace` does not apply. */
    private fun isRemoteManifest(manifest: ZenWaveManifest): Boolean =
        manifest.uri.startsWith("http://", ignoreCase = true) || manifest.uri.startsWith("https://", ignoreCase = true)

    private fun applicableSources(manifest: ZenWaveManifest): List<String> =
        if (isRemoteManifest(manifest)) {
            manifest.config.contentResolution.filterNot { it == ManifestSourceName.WORKSPACE }
        } else {
            manifest.config.contentResolution
        }

    private fun resolveSourceOrder(contentResolution: List<String>, options: ManifestLoadOptions): List<String> {
        val preferred = options.preferredSource.nonBlankOrNull() ?: return contentResolution
        if (preferred !in contentResolution) {
            throw ManifestResolutionException("Preferred source '$preferred' is not active in config.contentResolution")
        }
        return if (options.allowFallback) listOf(preferred) + contentResolution.filterNot { it == preferred } else listOf(preferred)
    }

    private fun workspaceCandidates(
        manifest: ZenWaveManifest,
        resourcePath: String,
        context: ManifestResolutionContext,
    ): List<ManifestResolvedResource> {
        val base = interpolateRuntime(
            ManifestSourceName.WORKSPACE,
            manifest.config.sources.workspace.basePathExpression,
            context,
            encode = false,
        )
        val relative = listOf(base, resourcePath).filter { it.isNotBlank() }.joinToString("/")
        val manifestDirectory = ManifestReferenceResolver.resolveReference(manifest.uri, ".")
        return listOf(
            ManifestResolvedResource(
                ManifestSourceName.WORKSPACE,
                ManifestReferenceResolver.resolveReference("${manifestDirectory.trimEnd('/')}/placeholder", relative),
            ),
        )
    }

    private fun gitExpression(source: ManifestGitSource): String =
        source.contentUrlExpression ?: when (source.provider) {
            GIT_GITHUB -> "\${server}/\${domain.id}/\${service.id}/raw/v\${version}/\${content.path}"
            GIT_GITLAB -> "\${server}/\${domain.id}/\${subdomain.id}/\${service.id}/-/raw/v\${version}/\${content.path}"
            GIT_BITBUCKET -> "\${server}/\${domain.id}/\${service.id}/src/v\${version}/\${content.path}"
            else -> throw ManifestResolutionException("Git provider '${source.provider}' requires contentUrlExpression")
        }

    private fun gitCandidates(
        source: ManifestGitSource,
        expression: String,
        context: ManifestResolutionContext,
    ): List<ManifestResolvedResource> {
        val result = interpolateRuntime(ManifestSourceName.GIT, expression, context, source.server)
        return listOf(ManifestResolvedResource(ManifestSourceName.GIT, ManifestReferenceResolver.normalizeEmptySegments(result)))
    }

    private fun apicurioCandidates(
        source: ManifestApicurioSource,
        expression: String,
        context: ManifestResolutionContext,
    ): List<ManifestResolvedResource> {
        val result = interpolateRuntime(ManifestSourceName.APICURIO, expression, context, source.server)
        return listOf(ManifestResolvedResource(ManifestSourceName.APICURIO, ManifestReferenceResolver.normalizeEmptySegments(result)))
    }

    private fun artifactoryCandidates(
        source: ManifestArtifactorySource,
        context: ManifestResolutionContext,
    ): List<ManifestResolvedResource> {
        val result = interpolateRuntime(
            ManifestSourceName.ARTIFACTORY,
            source.contentUrlExpression,
            context,
            source.server,
        )
        return listOf(ManifestResolvedResource(ManifestSourceName.ARTIFACTORY, ManifestReferenceResolver.normalizeEmptySegments(result)))
    }

    private fun mavenCandidates(
        source: ManifestMavenSource,
        artifact: ManifestArtifact,
        context: ManifestResolutionContext,
    ): List<ManifestResolvedResource> {
        val groupId = context.groupId.requireCoordinate("groupId")
        val artifactId = context.artifactId.requireCoordinate("artifactId")
        val version = context.version.requireCoordinate("version")
        val repository = interpolateRuntime(
            ManifestSourceName.MAVEN,
            source.repository,
            context,
            source.server,
            encode = false,
        )
        val groupPath = groupId.split('.').joinToString("/") { ManifestReferenceResolver.encodePathSegment(it) }
        val encodedArtifactId = ManifestReferenceResolver.encodePathSegment(artifactId)
        val encodedVersion = ManifestReferenceResolver.encodePathSegment(version)
        val jarPath = "$groupPath/$encodedArtifactId/$encodedVersion/$encodedArtifactId-$encodedVersion.jar"
        val base = "${source.server.trimEnd('/')}/${ManifestReferenceResolver.encodePath(repository.trim('/'))}/$jarPath"
        return when (source.provider) {
            MAVEN_ARTIFACTORY -> listOf(
                ManifestResolvedResource(
                    ManifestSourceName.MAVEN,
                    "$base!/${ManifestReferenceResolver.encodePath(artifact.path.trimStart('/'))}",
                ),
            )
            MAVEN_CENTRAL, MAVEN_GITHUB -> listOf(
                ManifestResolvedResource(ManifestSourceName.MAVEN, base, archiveEntry = artifact.path),
            )
            else -> throw ManifestResolutionException("Invalid Maven provider '${source.provider}'")
        }
    }

    internal fun interpolateRuntime(
        source: String,
        expression: String,
        context: ManifestResolutionContext,
        server: String? = null,
        encode: Boolean = true,
    ): String {
        val invalidDocLookup = PLACEHOLDER.findAll(expression)
            .flatMap { ManifestVariableInterpolator.alternatives(it.groupValues[1]).asSequence() }
            .firstOrNull { it.startsWith("service.docs") && !DOC_LOOKUP.matches(it) }
        if (invalidDocLookup != null) {
            throw ManifestResolutionException("Source '$source' expression '$expression' has invalid document lookup: $invalidDocLookup")
        }
        val variables = context.properties.filterKeys { !isRuntimeVariable(it) }.toMutableMap()
        variables.putAll(context.variables())
        server.nonBlankOrNull()?.let { variables["server"] = it.trimEnd('/') }
        val interpolation = ManifestVariableInterpolator.interpolate(
            expression,
            resolve = { variables[it] },
            transform = { name, value -> if (encode) encodeRuntimeValue(source, name, value) else value },
        )
        if (interpolation.unresolvedVariables.isNotEmpty()) {
            throw ManifestResolutionException(
                "Source '$source' expression '$expression' has unresolved runtime variables: " +
                    interpolation.unresolvedVariables.joinToString(", "),
            )
        }
        return interpolation.value
    }

    private fun encodeRuntimeValue(source: String, name: String, value: String): String = when {
        name == "server" -> value
        source == ManifestSourceName.APICURIO && (name == "artifact.path" || name == "content.path") ->
            ManifestReferenceResolver.encodePathSegment(value)
        name == "artifact.path" || name == "content.path" || name.startsWith("service.docs[") ->
            ManifestReferenceResolver.encodePath(value)
        else -> ManifestReferenceResolver.encodePathSegment(value)
    }

    private fun resolveCoordinates(
        manifest: ZenWaveManifest,
        context: ManifestResolutionContext,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact,
    ): ManifestCoordinates {
        return ManifestCoordinates(
            resolveGroupId(manifest, owner, context),
            resolveArtifactId(manifest, artifact, context),
        )
    }

    private fun addSelectedCoordinates(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        artifact: ManifestArtifact?,
        context: ManifestResolutionContext,
        expression: String,
    ): ManifestResolutionContext {
        var selected = context
        PLACEHOLDER.findAll(expression).forEach { match ->
            val body = match.groupValues[1]
            ManifestVariableInterpolator.alternatives(body).firstOrNull { name ->
                fun coordinate(resolve: () -> String): String? =
                    if ('|' in body) try { resolve() } catch (_: ManifestResolutionException) { null }
                    else resolve()
                when (name) {
                    "groupId" -> if (selected.groupId == null) {
                        selected = selected.copy(groupId = coordinate { resolveGroupId(manifest, owner, selected) })
                    }
                    "artifactId" -> if (selected.artifactId == null) {
                        selected = selected.copy(artifactId = coordinate {
                            artifact?.let { resolveArtifactId(manifest, it, selected) }
                                ?: throw ManifestResolutionException("Required coordinate 'artifactId' is unresolved")
                        })
                    }
                }
                val value = selected.variables()[name] ?: selected.properties[name]
                value != null && ('|' !in body || value.isNotBlank())
            }
        }
        return selected
    }

    private fun resolveGroupId(
        manifest: ZenWaveManifest,
        owner: ManifestArtifactOwner,
        context: ManifestResolutionContext,
    ): String = (
        owner.groupId.nonBlankOrNull()
            ?: interpolateRuntime("coordinates", manifest.config.groupIdExpression, context, encode = false)
        ).requireCoordinate("groupId")

    private fun baseContext(owner: ManifestArtifactOwner, artifact: ManifestArtifact?, contentPath: String): ManifestResolutionContext =
        when (owner) {
            is ManifestService -> baseContext(owner, artifact, contentPath)
            is ManifestDomain -> ManifestResolutionContext(
                domainId = owner.id,
                subdomainId = "",
                serviceId = "",
                domainVersion = owner.version,
                subdomainVersion = null,
                serviceVersion = null,
                artifact = artifact,
                contentPath = contentPath,
                docs = emptyMap(),
                version = artifact?.resolvedVersion ?: owner.version,
                ownerId = owner.id,
                ownerRepository = owner.repository,
            )
            is ManifestSubdomain -> ManifestResolutionContext(
                domainId = owner.domainId,
                subdomainId = owner.id,
                serviceId = "",
                domainVersion = owner.domainVersion,
                subdomainVersion = owner.version,
                serviceVersion = null,
                artifact = artifact,
                contentPath = contentPath,
                docs = emptyMap(),
                version = artifact?.resolvedVersion ?: owner.documentVersion(),
                ownerId = owner.id,
                ownerRepository = owner.repository,
            )
        }

    private fun resolveArtifactId(
        manifest: ZenWaveManifest,
        artifact: ManifestArtifact,
        context: ManifestResolutionContext,
    ): String = (
        artifact.artifactId.nonBlankOrNull()
            ?: interpolateRuntime("coordinates", manifest.config.artifactIdExpression, context, encode = false)
        ).requireCoordinate("artifactId")

    private fun baseContext(service: ManifestService, artifact: ManifestArtifact?, contentPath: String) =
        ManifestResolutionContext(
            domainId = service.domainId,
            subdomainId = service.subdomainId,
            serviceId = service.id,
            repository = service.repository,
            domainVersion = service.domainVersion,
            subdomainVersion = service.subdomainVersion,
            serviceVersion = service.version,
            artifact = artifact,
            contentPath = contentPath,
            docs = service.docs,
            version = if (artifact == null) service.documentVersion() else artifact.resolvedVersion,
            ownerId = service.id,
            ownerRepository = service.repository,
        )

    private fun String?.requireCoordinate(name: String): String =
        nonBlankOrNull() ?: throw ManifestResolutionException("Required coordinate '$name' is unresolved")

    private fun validateSourceReady(source: String, sources: ManifestSources) {
        when {
            source !in ManifestSourceName.all -> throw ManifestResolutionException("Invalid content-resolution source '$source'")
            source == ManifestSourceName.GIT && sources.git == null -> unconfiguredSourceError(source)
            source == ManifestSourceName.APICURIO && sources.apicurio == null -> unconfiguredSourceError(source)
            source == ManifestSourceName.ARTIFACTORY && sources.artifactory == null -> unconfiguredSourceError(source)
            source == ManifestSourceName.MAVEN && sources.maven == null -> unconfiguredSourceError(source)
        }
        when (source) {
            ManifestSourceName.GIT -> sources.git!!.let {
                if (it.provider !in GIT_PROVIDERS) {
                    throw ManifestResolutionException("Invalid Git provider '${it.provider}'")
                }
                if (it.provider == GIT_GENERIC && it.contentUrlExpression.nonBlankOrNull() == null) {
                    throw ManifestResolutionException("Git provider 'generic' requires contentUrlExpression")
                }
            }
            ManifestSourceName.APICURIO -> if (sources.apicurio!!.server.isBlank()) {
                throw ManifestResolutionException("Source 'apicurio' requires server")
            }
            ManifestSourceName.ARTIFACTORY -> sources.artifactory!!.let {
                if (it.server.isBlank()) throw ManifestResolutionException("Source 'artifactory' requires server")
                if (it.contentUrlExpression.isBlank()) {
                    throw ManifestResolutionException("Source 'artifactory' contentUrlExpression must not be blank")
                }
            }
            ManifestSourceName.MAVEN -> sources.maven!!.let {
                if (it.provider !in MAVEN_PROVIDERS) {
                    throw ManifestResolutionException("Invalid Maven provider '${it.provider}'")
                }
                if (it.server.isBlank()) throw ManifestResolutionException("Source 'maven' requires server")
                if (it.repository.isBlank()) throw ManifestResolutionException("Source 'maven' requires repository")
            }
        }
    }

    private fun unconfiguredSourceError(source: String): Nothing =
        throw ManifestResolutionException("Content-resolution source '$source' is not configured in config.sources")

    private fun directResource(path: String): ManifestResolvedResource {
        val uri = ManifestReferenceResolver.normalizeUri(path)
        return ManifestResolvedResource(uri.substringBefore(':'), uri)
    }

    private suspend fun loadText(uri: String): String {
        val loader = documentLoaders.firstOrNull { it.canLoad(uri) }
            ?: error("No document loader available for URI: ${redactUri(uri)}")
        return loader.load(uri)
    }

    private fun parseDomain(
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
        allServices: MutableList<ManifestService>,
        domainKey: String,
        value: Map<String, Any?>,
    ): ManifestDomain {
        val domainId = value["id"]?.toString().nonBlankOrNull() ?: domainKey
        val domainVersion = value["version"].stringValue()
        val docs = parseDocs(properties, diagnostics, domainKey, value)
        val artifacts = parseArtifacts(properties, diagnostics, domainKey, value)
        val directServices = value.mapAt("services").map { (serviceKey, serviceValue) ->
            parseService(
                properties, diagnostics, domainKey, domainId, domainVersion,
                null, "", null, serviceKey, serviceValue.asMap(),
            ).also(allServices::add)
        }
        val subdomains = value.mapAt("subdomains").map { (subdomainKey, subdomainValue) ->
            parseSubdomain(
                properties, diagnostics, allServices, domainKey, domainId, domainVersion,
                subdomainKey, subdomainValue.asMap(),
            )
        }
        return ManifestDomain(
            key = domainKey,
            id = domainId,
            version = domainVersion,
            name = value["name"]?.toString(),
            description = value["description"]?.toString(),
            services = directServices,
            subdomains = subdomains,
            repository = (value["repository"] as? String).nonBlankOrNull(),
            groupId = (value["groupId"] as? String).nonBlankOrNull(),
            artifacts = artifacts,
            docs = docs,
            aliases = value.listAt("aliases").mapNotNull { it?.toString().nonBlankOrNull() },
        )
    }

    private fun parseSubdomain(
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
        allServices: MutableList<ManifestService>,
        domainKey: String,
        domainId: String,
        domainVersion: String?,
        subdomainKey: String,
        value: Map<String, Any?>,
    ): ManifestSubdomain {
        val subdomainId = value["id"]?.toString().nonBlankOrNull() ?: subdomainKey
        val subdomainVersion = value["version"].stringValue()
        val ownerRef = "$domainKey/$subdomainKey"
        val docs = parseDocs(properties, diagnostics, ownerRef, value)
        val artifacts = parseArtifacts(properties, diagnostics, ownerRef, value)
        val services = value.mapAt("services").map { (serviceKey, serviceValue) ->
            parseService(
                properties, diagnostics, domainKey, domainId, domainVersion,
                subdomainKey, subdomainId, subdomainVersion, serviceKey, serviceValue.asMap(),
            ).also(allServices::add)
        }
        return ManifestSubdomain(
            key = subdomainKey,
            id = subdomainId,
            version = subdomainVersion,
            name = value["name"]?.toString(),
            description = value["description"]?.toString(),
            services = services,
            aliases = value.listAt("aliases").mapNotNull { it?.toString().nonBlankOrNull() },
            domainKey = domainKey,
            domainId = domainId,
            domainVersion = domainVersion,
            repository = (value["repository"] as? String).nonBlankOrNull(),
            groupId = (value["groupId"] as? String).nonBlankOrNull(),
            artifacts = artifacts,
            docs = docs,
        )
    }

    private fun parseService(
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
        domainKey: String,
        domainId: String,
        domainVersion: String?,
        subdomainKey: String?,
        subdomainId: String,
        subdomainVersion: String?,
        serviceKey: String,
        value: Map<String, Any?>,
    ): ManifestService {
        val serviceRef = listOfNotNull(domainKey, subdomainKey, serviceKey).joinToString("/")
        val serviceId = value["id"]?.toString().nonBlankOrNull() ?: serviceKey
        val docs = parseDocs(properties, diagnostics, serviceRef, value)
        val artifacts = parseArtifacts(properties, diagnostics, serviceRef, value)
        return ManifestService(
            domainKey = domainKey,
            domainId = domainId,
            subdomainKey = subdomainKey,
            subdomainId = subdomainId,
            serviceKey = serviceKey,
            id = serviceId,
            repository = (value["repository"] as? String).nonBlankOrNull(),
            groupId = (value["groupId"] as? String).nonBlankOrNull(),
            version = value["version"].stringValue(),
            domainVersion = domainVersion,
            subdomainVersion = subdomainVersion,
            name = value["name"]?.toString(),
            description = value["description"]?.toString(),
            serviceRef = serviceRef,
            docs = docs,
            artifacts = artifacts,
            consumers = value.listAt("consumers").mapNotNull { normalizeConsumer(domainKey, it) },
            aliases = value.listAt("aliases").mapNotNull { it?.toString().nonBlankOrNull() },
        )
    }

    private fun parseDocs(
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
        ownerRef: String,
        value: Map<String, Any?>,
    ): Map<String, String> = value.mapAt("docs").mapValuesNotNull { raw ->
        (raw as? String)?.let {
            expandStatic(it, "$ownerRef.docs", properties, diagnostics, allowRuntime = false)
        }
    }

    private fun parseArtifacts(
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
        ownerRef: String,
        value: Map<String, Any?>,
    ): List<ManifestArtifact> = value.listAt("artifacts").mapIndexedNotNull { index, rawArtifact ->
        val artifact = rawArtifact.asMap()
        val type = artifact["type"] as? String ?: return@mapIndexedNotNull null
        val rawPath = artifact["path"] as? String ?: return@mapIndexedNotNull null
        val version = artifact["version"].stringValue()
        if (version == null) diagnostics += missingArtifactField(ownerRef, index, "version")
        ManifestArtifact(
            name = (artifact["name"] as? String).nonBlankOrNull(),
            artifactId = (artifact["artifactId"] as? String).nonBlankOrNull(),
            type = type,
            path = expandStatic(rawPath, "$ownerRef.artifacts.path", properties, diagnostics, allowRuntime = false),
            version = version,
            releaseGroup = artifact["releaseGroup"] as? String,
        )
    }

    private fun parseProperties(
        values: Map<String, Any?>,
        diagnostics: MutableList<ManifestDiagnostic>,
    ): Map<String, String> = values.mapNotNull { (name, value) ->
        if (isRuntimeVariable(name)) {
            diagnostics += validationDiagnostic(
                "config.properties must not override runtime variable '$name'",
                "reserved-runtime-variable",
                "config.properties.$name",
            )
            null
        } else {
            (value as? String)?.let { name to it }
        }
    }.toMap()

    private fun parseSources(
        values: Map<String, Any?>,
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
    ): ManifestSources {
        fun expression(raw: Any?, default: String, location: String): String = expandStatic(
            raw?.toString() ?: default, location, properties, diagnostics, allowRuntime = true,
        )
        fun optionalExpression(raw: Any?, default: String? = null, location: String): String? =
            (raw?.toString() ?: default)?.let {
                expandStatic(it, location, properties, diagnostics, allowRuntime = true)
            }
        fun static(raw: Any?, default: String? = null, location: String): String? =
            (raw?.toString() ?: default)?.let { expandStatic(it, location, properties, diagnostics, allowRuntime = false) }

        val workspace = values["workspace"]?.asMap().orEmpty()
        val git = values["git"]?.asMap()
        val apicurio = values["apicurio"]?.asMap()
        val artifactory = values["artifactory"]?.asMap()
        val maven = values["maven"]?.asMap()
        val gitProvider = git?.get("provider")?.toString().orEmpty()
        val mavenProvider = maven?.get("provider")?.toString().orEmpty()
        return ManifestSources(
            workspace = ManifestWorkspaceSource(
                expression(
                    workspace["basePathExpression"],
                    "\${domain.id}/\${subdomain.id}/\${service.id}",
                    "config.sources.workspace.basePathExpression",
                ),
            ),
            git = git?.let {
                ManifestGitSource(
                    provider = gitProvider,
                    server = static(
                        it["server"],
                        gitDefaultServer(gitProvider),
                        "config.sources.git.server",
                    ),
                    contentUrlExpression = optionalExpression(
                        it["contentUrlExpression"],
                        location = "config.sources.git.contentUrlExpression",
                    ),
                )
            },
            apicurio = apicurio?.let {
                ManifestApicurioSource(
                    server = static(it["server"], location = "config.sources.apicurio.server").orEmpty(),
                    contentUrlExpression = optionalExpression(
                        it["contentUrlExpression"],
                        location = "config.sources.apicurio.contentUrlExpression",
                    ),
                )
            },
            artifactory = artifactory?.let {
                ManifestArtifactorySource(
                    server = static(it["server"], location = "config.sources.artifactory.server").orEmpty(),
                    contentUrlExpression = expression(
                        it["contentUrlExpression"],
                        ARTIFACTORY_DEFAULT_EXPRESSION,
                        "config.sources.artifactory.contentUrlExpression",
                    ),
                )
            },
            maven = maven?.let {
                val (serverDefault, repositoryDefault) = when (mavenProvider) {
                    MAVEN_CENTRAL -> CENTRAL_SERVER to CENTRAL_REPOSITORY
                    MAVEN_GITHUB -> GITHUB_SERVER to null
                    else -> null to null
                }
                ManifestMavenSource(
                    provider = mavenProvider,
                    server = static(
                        it["server"],
                        serverDefault,
                        "config.sources.maven.server",
                    ).orEmpty(),
                    repository = optionalExpression(
                        it["repository"],
                        repositoryDefault,
                        "config.sources.maven.repository",
                    ).orEmpty(),
                )
            },
        )
    }

    private fun validateContentResolution(
        contentResolution: List<String>,
        sources: ManifestSources,
        diagnostics: MutableList<ManifestDiagnostic>,
    ) {
        contentResolution.forEachIndexed { index, source ->
            val location = "config.contentResolution[$index]"
            when {
                source !in ManifestSourceName.all -> diagnostics += validationDiagnostic(
                    "Unknown content-resolution source '$source'", "unknown-content-source", location,
                )
                source == ManifestSourceName.GIT && sources.git == null -> diagnostics += unconfiguredSource(source, location)
                source == ManifestSourceName.APICURIO && sources.apicurio == null -> diagnostics += unconfiguredSource(source, location)
                source == ManifestSourceName.ARTIFACTORY && sources.artifactory == null -> diagnostics += unconfiguredSource(source, location)
                source == ManifestSourceName.MAVEN && sources.maven == null -> diagnostics += unconfiguredSource(source, location)
            }
        }
        sources.git?.let { source ->
            if (source.provider !in GIT_PROVIDERS) diagnostics += invalidProvider("git", source.provider)
            if (source.provider == GIT_GENERIC && source.contentUrlExpression.nonBlankOrNull() == null) {
                diagnostics += missingSourceField("git", "contentUrlExpression")
            }
        }
        sources.apicurio?.let { if (it.server.isBlank()) diagnostics += missingSourceField("apicurio", "server") }
        sources.artifactory?.let {
            if (it.server.isBlank()) diagnostics += missingSourceField("artifactory", "server")
            if (it.contentUrlExpression.isBlank()) diagnostics += validationDiagnostic(
                "Source 'artifactory' contentUrlExpression must not be blank",
                "invalid-source-read-configuration",
                "config.sources.artifactory.contentUrlExpression",
            )
        }
        sources.maven?.let {
            if (it.provider !in MAVEN_PROVIDERS) diagnostics += invalidProvider("maven", it.provider)
            if (it.server.isBlank()) diagnostics += missingSourceField("maven", "server")
            if (it.repository.isBlank()) diagnostics += missingSourceField("maven", "repository")
        }
    }

    private fun validateCoordinateExpression(
        expression: String,
        location: String,
        diagnostics: MutableList<ManifestDiagnostic>,
    ) {
        val recursive = PLACEHOLDER.findAll(expression)
            .flatMap { ManifestVariableInterpolator.alternatives(it.groupValues[1]).asSequence() }
            .filter { it == "groupId" || it == "artifactId" }.toList()
        if (recursive.isNotEmpty()) diagnostics += validationDiagnostic(
            "Coordinate expression must not reference ${recursive.joinToString(", ")}",
            "recursive-coordinate-expression",
            location,
        )
    }

    private fun invalidProvider(source: String, provider: String) = validationDiagnostic(
        "Invalid $source provider '$provider'", "invalid-source-provider", "config.sources.$source.provider",
    )

    private fun missingSourceField(source: String, field: String) = validationDiagnostic(
        "Source '$source' requires $field", "missing-source-read-configuration", "config.sources.$source.$field",
    )

    private fun missingArtifactField(serviceRef: String, index: Int, field: String) = validationDiagnostic(
        "Artifact requires $field", "missing-artifact-field", "$serviceRef.artifacts[$index].$field",
    )

    private fun unconfiguredSource(source: String, location: String) = validationDiagnostic(
        "Content-resolution source '$source' is not configured in config.sources",
        "unconfigured-content-source",
        location,
    )

    private fun validationDiagnostic(message: String, code: String, location: String) = ManifestDiagnostic(
        message = message,
        code = code,
        location = location,
    )

    private fun expandStatic(
        rawValue: String,
        location: String,
        properties: Map<String, String>,
        diagnostics: MutableList<ManifestDiagnostic>,
        allowRuntime: Boolean,
    ): String {
        val interpolation = ManifestVariableInterpolator.interpolate(
            rawValue,
            resolve = { properties[it] },
            defer = { expression -> allowRuntime &&
                ManifestVariableInterpolator.alternatives(expression).any { isRuntimeVariable(it) } },
        )
        interpolation.unresolvedVariables.filterNot { expression -> allowRuntime &&
            ManifestVariableInterpolator.alternatives(expression).any { isRuntimeVariable(it) }
        }.forEach { variable ->
            diagnostics += ManifestDiagnostic(
                "Unresolved static variable '$variable'",
                code = "unresolved-static-variable",
                location = location,
            )
        }
        return interpolation.value
    }

    private fun isRuntimeVariable(name: String): Boolean =
        name in CANONICAL_RUNTIME_VARIABLES || name == "service.docs" ||
            name.startsWith("service.docs[") || name == "server"

    private fun normalizeConsumer(currentDomain: String, value: Any?): String? = when (value) {
        is String -> normalizeConsumerString(currentDomain, value)
        is Map<*, *> -> normalizeConsumerMap(currentDomain, value)
        else -> null
    }

    private fun normalizeConsumerMap(currentDomain: String, value: Map<*, *>): String? {
        val serviceRef = value["service"] as? String
        if (serviceRef != null) return normalizeConsumerString(currentDomain, serviceRef)
        return normalizeJsonPointerReference(value["\$ref"] as? String)
    }

    private fun normalizeConsumerString(currentDomain: String, value: String): String? {
        val raw = value.nonBlankOrNull() ?: return null
        if (raw.startsWith("#/")) return normalizeJsonPointerReference(raw)
        // Artifact-qualified references are resolved after the complete global service index exists.
        if ('#' in raw) return raw
        return normalizeServiceRef(currentDomain, raw)
    }

    private fun diagnoseConsumerServices(
        services: List<ManifestService>,
        diagnostics: MutableList<ManifestDiagnostic>,
    ) {
        val byRef = services.associateBy { it.serviceRef }
        val byId = services.associateBy { it.id }
        services.forEach { declaringService ->
            declaringService.consumers.forEachIndexed { index, raw ->
                val reference = runCatching { ManifestConsumerReference.parse(raw) }.getOrNull() ?: return@forEachIndexed
                // Suffix-less declarations retain legacy normalization and diagnostics behavior.
                if (reference.artifactSelector == null) return@forEachIndexed
                val resolved = byRef[reference.serviceReference]
                    ?: byId[reference.serviceReference]
                    ?: byRef["${declaringService.domainKey}/${reference.serviceReference}"]
                if (resolved == null) {
                    diagnostics += ManifestDiagnostic(
                        message = "Consumer service '${reference.serviceReference}' cannot be resolved",
                        severity = ManifestDiagnosticSeverity.ERROR,
                        code = "unresolved-consumer-reference",
                        location = "${declaringService.serviceRef}.consumers[$index]",
                    )
                }
            }
        }
    }

    private fun normalizeJsonPointerReference(pointer: String?): String? {
        val raw = pointer.nonBlankOrNull() ?: return null
        if (!raw.startsWith("#/")) return raw
        val tokens = raw.removePrefix("#/").split('/').map { it.replace("~1", "/").replace("~0", "~") }
        return when {
            tokens.size >= 4 && tokens[0] == "domains" && tokens[2] == "services" -> "${tokens[1]}/${tokens[3]}"
            tokens.size >= 6 && tokens[0] == "domains" && tokens[2] == "subdomains" && tokens[4] == "services" ->
                "${tokens[1]}/${tokens[3]}/${tokens[5]}"
            else -> raw
        }
    }

    private fun normalizeServiceRef(currentDomain: String, value: String?): String? {
        val raw = value.nonBlankOrNull() ?: return null
        return if ('/' !in raw) "$currentDomain/$raw" else raw
    }

    private fun shieldConsumerRefs(text: String): String =
        text.replace(Regex("""(^[ \t]*-[ \t]*)[${'$'}]ref:""", RegexOption.MULTILINE), "$1service:")

    private fun manifestDocumentLoaders(): List<DocumentLoader> = documentLoaders.map { delegate ->
        object : DocumentLoader {
            override fun canLoad(uri: String): Boolean = delegate.canLoad(uri)

            override suspend fun load(uri: String): String = shieldConsumerRefs(delegate.load(uri))
        }
    }

    private fun redactUri(uri: String): String = uri
        .replace(Regex("""(://)[^/?#\s]*@"""), "$1<redacted>@")
        .replace(Regex("""([?&][^=&#]+)=([^&#]*)"""), "$1=<redacted>")

    private fun redactErrorMessage(message: String): String = redactUri(message)

    private fun gitDefaultServer(provider: String): String? = when (provider) {
        GIT_GITHUB -> "https://github.com"
        GIT_GITLAB -> "https://gitlab.com"
        GIT_BITBUCKET -> "https://api.bitbucket.org/2.0/repositories"
        else -> null
    }

    private companion object {
        const val GIT_GITHUB = "github"
        const val GIT_GITLAB = "gitlab"
        const val GIT_BITBUCKET = "bitbucket"
        const val GIT_GENERIC = "generic"
        const val MAVEN_ARTIFACTORY = "artifactory"
        const val MAVEN_CENTRAL = "central"
        const val MAVEN_GITHUB = "github"
        const val CENTRAL_SERVER = "https://repo.maven.apache.org"
        const val CENTRAL_REPOSITORY = "maven2"
        const val GITHUB_SERVER = "https://maven.pkg.github.com"
        const val APICURIO_DEFAULT_EXPRESSION =
            "\${server}/apis/registry/v3/groups/\${service.id}/artifacts/\${artifact.path}/versions/\${version}/content"
        const val ARTIFACTORY_DEFAULT_EXPRESSION =
            "\${server}/artifactory/contracts/\${domain.id}/\${subdomain.id}/\${service.id}/\${version}/\${content.path}"
        val GIT_PROVIDERS = setOf(GIT_GITHUB, GIT_GITLAB, GIT_BITBUCKET, GIT_GENERIC)
        val MAVEN_PROVIDERS = setOf(MAVEN_ARTIFACTORY, MAVEN_CENTRAL, MAVEN_GITHUB)
        val PLACEHOLDER = Regex("""[${'$'}][{]([^}]*)[}]""")
        val DOC_LOOKUP = Regex("""service[.]docs\x5B[A-Za-z0-9._-]+\x5D""")
        val CANONICAL_RUNTIME_VARIABLES = setOf(
            "domain.id", "subdomain.id", "service.id", "service.repository", "owner.id", "owner.repository",
            "domain.version", "subdomain.version",
            "service.version", "artifact.version", "artifact.type", "artifact.releaseGroup", "artifact.path", "artifact.pathWithoutExtension", "artifact.name",
            "artifact.fileName", "artifact.fileNameWithoutExtension", "content.path",
            "groupId", "artifactId", "version",
        )
    }
}

@Suppress("UNCHECKED_CAST")
private fun Any?.asMap(): Map<String, Any?> = this as? Map<String, Any?> ?: emptyMap()

@Suppress("UNCHECKED_CAST")
private fun Map<*, *>.mapAt(key: String): Map<String, Any?> = this[key] as? Map<String, Any?> ?: emptyMap()

private fun Map<String, Any?>.listAt(key: String): List<Any?> = this[key] as? List<Any?> ?: emptyList()

private fun Map<String, Any?>.mapValuesNotNull(transform: (Any?) -> String?): Map<String, String> =
    entries.mapNotNull { (key, value) -> transform(value)?.let { key to it } }.toMap()

private fun Any?.stringValue(): String? = when (this) {
    is String -> nonBlankOrNull()
    is Number -> toString()
    else -> null
}
