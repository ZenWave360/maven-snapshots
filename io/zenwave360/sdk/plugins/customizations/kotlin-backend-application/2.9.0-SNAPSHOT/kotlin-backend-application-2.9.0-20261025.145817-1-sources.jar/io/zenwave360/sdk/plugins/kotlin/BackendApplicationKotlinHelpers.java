package io.zenwave360.sdk.plugins.kotlin;

import com.github.jknack.handlebars.Options;
import io.zenwave360.sdk.plugins.BackendApplicationDefaultGenerator;
import io.zenwave360.sdk.utils.JSONPath;
import io.zenwave360.sdk.zdl.utils.ZDLFindUtils;
import io.zenwave360.sdk.zdl.utils.ZDLJavaSignatureUtils;

import java.util.*;
import java.util.stream.Collectors;

public class BackendApplicationKotlinHelpers {

    private final BackendApplicationDefaultGenerator generator;

    BackendApplicationKotlinHelpers(BackendApplicationDefaultGenerator generator) {
        this.generator = generator;
    }

    public String javaType(Map field, Options options) {
        return ZDLJavaSignatureUtils.javaType(field).replace("byte[]", "ByteArray");
    }

    public String naturalIdsRepoMethodSignature(Map entity, Options options) {
        return ZDLJavaSignatureUtils.naturalIdsKotlinRepoMethodSignature(entity);
    }

    public String findById(Map method, Options options) {
        var zdl = options.get("zdl");
        var hasNaturalId = JSONPath.get(method, "$.naturalId", false);
        if(hasNaturalId) {
            var entity = (Map) JSONPath.get(zdl, "$.allEntitiesAndEnums." + method.get("entity"));
            return ZDLJavaSignatureUtils.naturalIdsRepoMethodCallSignature(entity);
        }
        return "findByIdOrNull(id)";
    }

    public String idForStringInterpolation(Map method, Options options) {
        var zdl = options.get("zdl");
        var hasNaturalId = JSONPath.get(method, "$.naturalId", false);
        if(hasNaturalId) {
            var entity = (Map) JSONPath.get(zdl, "$.allEntitiesAndEnums." + method.get("entity"));
            var params = ZDLJavaSignatureUtils.naturalIdsRepoMethodCallSignature(entity)
                    .replaceAll("findBy[^(]*\\(([^)]*)\\)", "$1");
            return Arrays.stream(params.split(", "))
                    .map(param -> param + "=$" + param)
                    .collect(Collectors.joining(", "));
        }
        return "$id";
    }


    /** Accepts both {@code {{methodParametersSignature "artifact.type" method}}} and the legacy {@code {{methodParametersSignature method}}}. */
    public String methodParametersSignature(Object artifactTypeOrMethod, Options options) {
        var zdl = (Map) options.get("zdl");
        var artifactType = artifactTypeOrMethod instanceof String type ? type : null;
        var method = (Map<String, Object>) (artifactType != null ? options.param(0) : artifactTypeOrMethod);
        return ZDLJavaSignatureUtils.kotlinMethodParametersSignature(artifactType, generator.getIdJavaType(), method, zdl);
    }

    public String nullableMethodParametersSignature(Object artifactTypeOrMethod, Options options) {
        var zdl = (Map) options.get("zdl");
        var artifactType = artifactTypeOrMethod instanceof String type ? type : null;
        var method = (Map<String, Object>) (artifactType != null ? options.param(0) : artifactTypeOrMethod);
        return ZDLJavaSignatureUtils.kotlinNullableMethodParametersSignature(artifactType, generator.getIdJavaType(), method, zdl);
    }

    public String mapperInputSignature(String inputType, Options options) {
        var zdl = (Map) options.get("zdl");
        return ZDLJavaSignatureUtils.kotlinMapperInputSignature(inputType, zdl);
    }

    public String mapperInputAnnotations(String inputType, Options options) {
        return ZDLJavaSignatureUtils.mapperInputAnnotations(inputType, (Map) options.get("zdl"))
                .stream()
                .map(annotations -> String.format("@Mapping(source = \"%s\", target = \"%s\")", annotations.get("source"), annotations.get("target")))
                .collect(Collectors.joining("\n"));
    }

    /** Accepts both {@code {{returnType "artifact.type" method}}} and the legacy {@code {{returnType method}}} / {@code {{returnType}}}. */
    public String returnType(Object artifactTypeOrMethod, Options options) {
        var artifactType = artifactTypeOrMethod instanceof String type ? type : null;
        var method = (Map<String, Object>) (artifactType != null ? options.param(0) : artifactTypeOrMethod);
        return ZDLJavaSignatureUtils.methodReturnType(artifactType, method)
                .replace("void", "Unit")
                .replaceAll("Optional<(.+)>", "$1?");
    }

    public String fieldType(Map field, Options options) {
        String prefix = (String) options.hash.getOrDefault("prefix", "");
        String suffix = (String) options.hash.getOrDefault("suffix", "");
        return fixKotlinCollectionTypes(ZDLJavaSignatureUtils.fieldType(field, prefix, suffix));
    };

    public boolean isRequired(Map field, Options options) {
        var isRequired = JSONPath.get(field, "validations.required") != null;
        var isArray = JSONPath.get(field, "isArray", false);
        return isRequired && !isArray;
    }

    public String relationshipFieldType(Map field, Options options) {
        String prefix = (String) options.hash.getOrDefault("prefix", "");
        String suffix = (String) options.hash.getOrDefault("suffix", "");
        String nullable = !JSONPath.get(field, "isCollection", false) ? "?" : "";
        return ZDLJavaSignatureUtils.relationshipFieldType(field, prefix, suffix) + nullable;
    };

    public String relationshipFieldTypeInitializer(Map field, Options options) {
        var typeInitializer = ZDLJavaSignatureUtils.relationshipFieldTypeInitializer(field);
        if(typeInitializer.trim().isEmpty()) {
            return " = null";
        }
        return fixKotlinTypeInitializers(typeInitializer);
    };

    public String fieldTypeInitializer(Map field, Options options) {
        var typeInitializer = fixKotlinTypeInitializers(ZDLJavaSignatureUtils.fieldTypeInitializer(field));
        if(typeInitializer.trim().isEmpty()) {
            return " = null";
        }
        return typeInitializer;
    };

    public String idFieldInitialization(Map method, Options options) {
        var zdl = options.get("zdl");
        var hasNaturalId = JSONPath.get(method, "$.naturalId", false);
        if(hasNaturalId) {
            var entity = (Map) JSONPath.get(zdl, "$.allEntitiesAndEnums." + method.get("entity"));
            List<Map> fields = ZDLFindUtils.naturalIdFields(entity);
            return fields.stream().map(field -> String.format("val %s = %s;", field.get("name"), ZDLJavaSignatureUtils.populateField(field)))
                    .collect(Collectors.joining("\n"));
        }
        return "val id: " + generator.getIdJavaType() + " = " + idInitialization(generator.getIdJavaType());
    }

    public String populateField(Map field, Options options) {
        var populate = ZDLJavaSignatureUtils.populateField(field).replace("new ", "");
        if("Integer".equals(field.get("type"))) {
            populate = populate.replace("0", "0 as Integer");
        }
        return populate;
    }

    public String transitionNaturalIdExpression(Map entity, Options options) {
        if (entity == null) {
            return "null";
        }
        List<Map> fields = ZDLFindUtils.naturalIdFields(entity);
        if (fields == null || fields.isEmpty()) {
            return "null";
        }
        return fields.stream()
                .map(field -> "\"" + field.get("name") + "=\" + entity." + field.get("name"))
                .collect(Collectors.joining(" + \", \" + "));
    }

    private String idInitialization(String idJavaType) {
        return switch (idJavaType) {
            case "Long" -> "1L";
            case "Integer" -> "1";
            case "String" -> "\"1\"";
            default -> "";
        };
    }

    private String fixKotlinTypeInitializers(String type) {
        return type
                .replaceAll("new HashSet<>\\(\\)", "mutableSetOf()")
                .replaceAll("new ArrayList<>\\(\\)", "mutableListOf()")
                .replaceAll("new HashMap<>\\(\\)", "mutableMapOf()");
    }

    private String fixKotlinCollectionTypes(String type) {
        return type
                .replaceAll("byte\\[]", "ByteArray")
                .replaceAll("Set<", "MutableSet<")
                .replaceAll("List<", "MutableList<")
                .replaceAll("Map<", "MutableMap<");
    }
}
