package io.zenwave360.sdk.plugins.kotlin;

import io.zenwave360.sdk.doc.DocumentedOption;
import io.zenwave360.sdk.generators.Generator;
import io.zenwave360.sdk.plugins.OpenAPIControllersGenerator;
import io.zenwave360.sdk.utils.JSONPath;
import io.zenwave360.sdk.zdl.ProjectTemplates;
import io.zenwave360.sdk.zdl.layouts.ProjectLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static io.zenwave360.sdk.templating.OutputFormatType.KOTLIN;

public class OpenAPIControllersKotlinTemplates extends ProjectTemplates {

    @DocumentedOption(description = "Include Controller Unit tests (using ServicesInMemoryConfig)")
    public boolean includeControllerTests = true;

    public Function<Map<String, Object>, Boolean> skipControllerTests = (model) -> !includeControllerTests;
    public Function<Map<String, Object>, Boolean> skipPatchMap = (model) -> {
        return JSONPath.get(model, "$.openapi.paths[*].patch", List.of()).isEmpty();
    };

    public OpenAPIControllersKotlinTemplates() {
        setTemplatesFolder("io/zenwave360/sdk/plugins/kotlin/OpenAPIControllersGenerator");

        var layoutNames = new ProjectLayout(); // layoutNames
        this.addTemplate(this.singleTemplates, "src/main/kotlin", "web/common/PatchMap.kt",
                layoutNames.adaptersWebCommonPackage, "PatchMap.kt", KOTLIN, skipPatchMap, false);
        this.addTemplate(this.singleTemplates, "src/main/kotlin", "web/mappers/BaseMapper.kt",
                layoutNames.adaptersWebMappersCommonPackage, "BaseMapper.kt", KOTLIN, null, false);
        this.addTemplate(this.serviceTemplates, "src/main/kotlin", "web/mappers/ServiceDTOsMapper.kt",
                layoutNames.adaptersWebMappersPackage, "{{serviceName}}DTOsMapper.kt", KOTLIN, null, true);
        this.addTemplate(this.serviceTemplates, "src/main/kotlin", "web/{{webFlavor}}/ServiceApiController.kt",
                layoutNames.adaptersWebPackage, "{{serviceName}}ApiController.kt", KOTLIN, null, false);
        this.addTemplate(this.serviceTemplates, "src/test/kotlin", "web/{{webFlavor}}/ServiceApiControllerTest.kt",
                layoutNames.adaptersWebPackage, "{{serviceName}}ApiControllerTest.kt", KOTLIN, skipControllerTests, true);
    }

    @Override
    public List<Object> getTemplateHelpers(Generator generator) {
        var helpers = new ArrayList<>(super.getTemplateHelpers(generator));
        if (generator instanceof OpenAPIControllersGenerator openAPIControllersGenerator) {
            helpers.add(new OpenAPIControllersKotlinHelpers(
                    openAPIControllersGenerator.openApiModelNamePrefix, openAPIControllersGenerator.openApiModelNameSuffix));
        }
        return helpers;
    }
}
