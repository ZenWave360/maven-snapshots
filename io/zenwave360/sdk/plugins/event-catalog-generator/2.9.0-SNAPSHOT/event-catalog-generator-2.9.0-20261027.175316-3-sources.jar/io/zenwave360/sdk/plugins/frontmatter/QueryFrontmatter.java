package io.zenwave360.sdk.plugins.frontmatter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import io.zenwave360.sdk.plugins.frontmatter.FrontmatterTypes.ChannelPointerFrontmatter;
import io.zenwave360.sdk.plugins.frontmatter.FrontmatterTypes.CommonFrontmatter;
import io.zenwave360.sdk.plugins.frontmatter.FrontmatterTypes.MessageDetailsPanelFrontmatter;
import io.zenwave360.sdk.plugins.frontmatter.FrontmatterTypes.OperationFrontmatter;
import io.zenwave360.sdk.plugins.frontmatter.FrontmatterTypes.ResourcePointerFrontmatter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public record QueryFrontmatter(
        @JsonUnwrapped CommonFrontmatter base,
        OperationFrontmatter operation,
        List<String> producers,
        List<String> consumers,
        List<ChannelPointerFrontmatter> channels,
        List<String> messageChannels,
        MessageDetailsPanelFrontmatter detailsPanel) implements Frontmatter {
}
