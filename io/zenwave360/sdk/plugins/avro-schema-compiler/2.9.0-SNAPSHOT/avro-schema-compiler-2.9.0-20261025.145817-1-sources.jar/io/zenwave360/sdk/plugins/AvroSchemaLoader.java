package io.zenwave360.sdk.plugins;

import io.zenwave360.jsonrefparser.AuthenticationValue;
import io.zenwave360.jsonrefparser.$RefParser;
import io.zenwave360.jsonrefparser.$RefParserOptions;
import io.zenwave360.jsonrefparser.$RefParserOptions.OnMissing;
import io.zenwave360.sdk.doc.DocumentedOption;
import io.zenwave360.sdk.parsers.Parser;
import io.zenwave360.sdk.utils.AntStyleMatcher;
import org.reflections.scanners.Scanners;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static io.zenwave360.jsonrefparser.$RefParserOptions.OnCircular.SKIP;

import org.reflections.Reflections;
import org.reflections.scanners.ResourcesScanner;
import org.reflections.util.ConfigurationBuilder;

import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class AvroSchemaLoader implements io.zenwave360.sdk.parsers.Parser {
    private Logger log = LoggerFactory.getLogger(getClass());

    public static final String AVRO_SCHEMAS_LIST = "avroSchemas";

    @DocumentedOption(description = "List of avro schema files to generate code for. It is alternative to sourceDirectory and imports.")
    public List<String> avroFiles;

    @DocumentedOption(description = "Avro Compiler Properties")
    public AvroCompilerProperties avroCompilerProperties = new AvroCompilerProperties();

    @DocumentedOption(description = "Authentication configuration values for fetching remote resources.")
    public List<AuthenticationValue> authentication = List.of();

    private ClassLoader projectClassLoader;

    @Override
    public Parser withProjectClassLoader(ClassLoader projectClassLoader) {
        this.projectClassLoader = projectClassLoader;
        return this;
    }

    @Override
    public Map<String, Object> parse() throws IOException {
        List<URI> avroFileURIs = null;
        if(avroFiles != null && !avroFiles.isEmpty()) {
            log.info("Using {} avro files: {}", avroFiles.size(), avroFiles);
            avroFileURIs = avroFiles.stream().map(this::toInputUri).toList();
        }
        else {
            avroFileURIs = collectAvscFiles(avroCompilerProperties);
            log.debug("Found {} avsc files: {}", avroFileURIs.size(), avroFileURIs);
        }
        var avroSchemas = avroSchemasAsList(avroFileURIs);
        return Map.of(AVRO_SCHEMAS_LIST, avroSchemas);
    }

    protected List<Map<String, Object>> avroSchemasAsList(List<URI> avroFileURIs) throws IOException {
        var schemas = new ArrayList<Map<String, Object>>();
        for (URI uri : avroFileURIs) {
            $RefParser parser = new $RefParser(uri)
                    .withResourceClassLoader(this.projectClassLoader)
                    .withAuthenticationValues(authentication)
                    .withOptions(new $RefParserOptions().withOnCircular(SKIP).withOnMissing(OnMissing.FAIL));
            Object schema = parser.parse().getRefs().schema();
            if(schema instanceof List) {
                schemas.addAll((List<Map<String, Object>>) schema);
            } else {
                schemas.add((Map<String, Object>) schema);
            }
        }
        return schemas;
    }

    public List<Map<String, Object>> loadSchemas(List<URI> avroFileURIs) throws IOException {
        return avroSchemasAsList(avroFileURIs);
    }

    private URI toInputUri(String value) {
        if (value.startsWith("classpath:") || value.startsWith("http://") || value.startsWith("https://") || value.startsWith("file:")) {
            return URI.create(value);
        }
        return new File(value).toURI();
    }

    protected List<URI> collectAvscFiles(AvroCompilerProperties avroCompilerProperties) throws IOException {
        return collectAvscFiles(avroCompilerProperties.sourceDirectory, avroCompilerProperties.imports, avroCompilerProperties.includes, avroCompilerProperties.excludes);
    }

    public List<URI> collectImportUris(List<String> imports) throws IOException {
        return collectAvscFiles(null, imports, List.of("**/*.avsc"), List.of());
    }

    /**
     * Finds .avsc files beside a local or classpath root schema. Remote URI directories
     * cannot be listed and therefore continue to require explicit imports.
     */
    public List<URI> collectSiblingUris(URI schemaUri) throws IOException {
        List<URI> siblingUris;
        if (schemaUri.getScheme() == null || "file".equalsIgnoreCase(schemaUri.getScheme())) {
            Path schemaPath = schemaUri.getScheme() == null
                    ? Paths.get(schemaUri.getPath()).toAbsolutePath().normalize()
                    : Paths.get(schemaUri).toAbsolutePath().normalize();
            Path parent = schemaPath.getParent();
            if (parent == null || !Files.isDirectory(parent)) {
                siblingUris = List.of();
            } else {
                try (var paths = Files.list(parent)) {
                    siblingUris = paths
                            .filter(Files::isRegularFile)
                            .filter(path -> path.getFileName().toString().endsWith(".avsc"))
                            .map(path -> path.toAbsolutePath().normalize())
                            .filter(path -> !path.equals(schemaPath))
                            .sorted()
                            .map(Path::toUri)
                            .toList();
                }
            }
        } else if ("classpath".equalsIgnoreCase(schemaUri.getScheme())) {
            String schemaResource = schemaUri.getSchemeSpecificPart().replaceFirst("^/", "");
            int lastSlash = schemaResource.lastIndexOf('/');
            if (lastSlash < 0) {
                siblingUris = List.of();
            } else {
                String parentResource = schemaResource.substring(0, lastSlash);
                siblingUris = collectImportUris(List.of("classpath:" + parentResource)).stream()
                        .filter(uri -> {
                            String resource = uri.getSchemeSpecificPart().replaceFirst("^/", "");
                            int resourceLastSlash = resource.lastIndexOf('/');
                            return resourceLastSlash >= 0
                                    && parentResource.equals(resource.substring(0, resourceLastSlash))
                                    && !schemaResource.equals(resource);
                        })
                        .sorted(Comparator.comparing(URI::toString))
                        .toList();
            }
        } else {
            siblingUris = List.of();
        }

        log.info("Found {} sibling avsc files for {}: {}", siblingUris.size(), schemaUri, siblingUris);
        return siblingUris;
    }

    protected List<URI> collectAvscFiles(File sourceFolder, List<String> imports, List<String> includes, List<String> excludes) throws IOException {
        Set<File> avscFiles = new HashSet<>();
        List<URI> importedURIs = new ArrayList<>();

        // Process sourceFolder if provided
        if (sourceFolder != null && sourceFolder.exists()) {
            if (sourceFolder.isDirectory()) {
                log.info("Collecting avsc files from source folder: {}", sourceFolder);
                avscFiles.addAll(Files.walk(sourceFolder.toPath())
                        .filter(Files::isRegularFile)
                        .filter(p ->  matchesIncludes(p.toString(), includes) && !matchesExcludes(p.toString(), excludes))
                        .map(Path::toFile)
                        .toList());
            } else if (sourceFolder.isFile() && sourceFolder.getName().endsWith(".avsc")) {
                avscFiles.add(sourceFolder);
            }
        }

        // Process imports if provided
        if (imports != null) {
            log.info("Collecting avsc files from imports: {}", imports);
            // Maven configOptions can bind a comma-separated value as a single list item,
            // especially when the XML property spans multiple lines.
            for (String importPath : imports.stream()
                    .flatMap(value -> Pattern.compile(",").splitAsStream(value))
                    .map(String::trim)
                    .filter(value -> !value.isEmpty())
                    .toList()) {
                try {
                    if (importPath.startsWith("classpath:")) {
                        // Handle classpath resources (files only, not directories)
                        log.trace("Processing classpath resource: {}", importPath);
                        if (importPath.endsWith(".avsc")) {
                            importedURIs.add(URI.create(importPath));
                        } else {
                            // Scan for .avsc files within the package
                            String packagePath = importPath.replace("classpath:", "").replaceFirst("^/", "");
                            log.trace("Scanning classpath package for .avsc files: {}", packagePath);
                            try {
                                ConfigurationBuilder config = new ConfigurationBuilder()
                                        .setScanners(Scanners.Resources);

                                if (this.projectClassLoader instanceof URLClassLoader urlClassLoader) {
                                    config.addClassLoaders(urlClassLoader);
                                    config.addUrls(urlClassLoader.getURLs());
                                } else {
                                    config.forPackage(packagePath.replace("/", "."));
                                }

                                Set<String> avscResources = new Reflections(config).getResources(Pattern.compile(".*\\.avsc"));

                                // Apply package filtering as a safety net (handles current Reflections bug)
                                avscResources = avscResources.stream()
                                        .filter(resource -> resource.startsWith(packagePath))
                                        .collect(Collectors.toSet());

                                for (String resource : avscResources) {
                                    // Apply include/exclude filters to classpath resources
                                    if (matchesIncludes(resource, includes) && !matchesExcludes(resource, excludes)) {
                                        String classpathUri = "classpath:" + resource;
                                        log.trace("Found classpath .avsc file: {}", classpathUri);
                                        importedURIs.add(URI.create(classpathUri));
                                    } else {
                                        log.trace("Classpath resource {} filtered out by include/exclude patterns", resource);
                                    }
                                }

                                if (avscResources.isEmpty()) {
                                    log.warn("No .avsc files found in classpath package: {}", importPath);
                                }
                            } catch (Exception e) {
                                log.error("Error scanning classpath package '{}': {}", packagePath, e.getMessage());
                                throw new IOException("Failed to scan classpath package: " + importPath, e);
                            }
                        }
                    } else if (importPath.startsWith("https://") || importPath.startsWith("http://")) {
                        // Handle HTTPS resources
                        log.debug("Processing HTTPS resource: {}", importPath);
                        if (importPath.endsWith(".avsc")) {
                            importedURIs.add(URI.create(importPath));
                        } else {
                            log.warn("HTTPS imports only support individual .avsc files: {}", importPath);
                        }
                    } else {
                        // Handle local file system paths
                        Path path = Paths.get(importPath);
                        if (Files.isDirectory(path)) {
                            avscFiles.addAll(Files.walk(path)
                                    .filter(Files::isRegularFile)
                                    .filter(p -> matchesIncludes(p.toString(), includes) && !matchesExcludes(p.toString(), excludes))
                                    .map(Path::toFile)
                                    .toList());
                        } else if (Files.isRegularFile(path) && importPath.endsWith(".avsc")) {
                            if (matchesIncludes(path.toString(), includes) && !matchesExcludes(path.toString(), excludes)) {
                                avscFiles.add(path.toFile());
                            }
                        } else {
                            log.warn("Skipping invalid import path: {}", importPath);
                        }
                    }
                } catch (Exception e) {
                    log.error("Error processing import path '{}': {}", importPath, e.getMessage());
                    throw new IOException("Failed to process import: " + importPath, e);
                }
            }
        }

        // Combine local file URIs with remote URIs
        List<URI> allURIs = new ArrayList<>();
        allURIs.addAll(avscFiles.stream().map(File::toURI).toList());
        allURIs.addAll(importedURIs);

        if (imports != null) {
            log.info("Found {} avsc files in imports: {}", allURIs.size(), allURIs);
        }

        return allURIs;
    }

    public List<Map<String, Object>> sortSchemas(List<Map<String, Object>> schemas) {
        if (isAvroVersionLater("1.12.0")) {
            return schemas;
        }
        log.info("Avro version detected {} < 1.12.0. Sorting schemas...", AVRO_VERSION);

        log.debug("Sorting schemas: {}", schemas.stream().map(schema -> schema.get("name")).toList());
        schemas.sort(createDependencyComparator());
        log.debug("Sorted schemas: {}", schemas.stream().map(schema -> schema.get("name")).toList());

        return schemas;
    }

    private Comparator<Map<String, Object>> createDependencyComparator() {
        return (map1, map2) -> {
            String name1 = (String) map1.get("name");
            String name2 = (String) map2.get("name");
            String type1 = (String) map1.get("type");
            String type2 = (String) map2.get("type");

            List<String> dependencies1 = extractDependencies(map1);
            List<String> dependencies2 = extractDependencies(map2);

            boolean map1IsEnum = "enum".equals(type1);
            boolean map2IsEnum = "enum".equals(type2);
            boolean map1HasNoDeps = dependencies1.isEmpty();
            boolean map2HasNoDeps = dependencies2.isEmpty();

            if ((map1IsEnum || map1HasNoDeps) && !(map2IsEnum || map2HasNoDeps)) {
                return -1;
            } else if (!(map1IsEnum || map1HasNoDeps) && (map2IsEnum || map2HasNoDeps)) {
                return 1;
            }

            boolean map1DependsOnMap2 = dependencies1.contains(name2);
            boolean map2DependsOnMap1 = dependencies2.contains(name1);

            if (map1DependsOnMap2 && !map2DependsOnMap1) {
                return 1;
            } else if (!map1DependsOnMap2 && map2DependsOnMap1) {
                return -1;
            }
            return 0;
        };
    }

    private List<String> extractDependencies(Map<String, Object> schema) {
        List<Object> fieldTypes = io.zenwave360.sdk.utils.JSONPath.get(schema, "$.fields[*].type", List.of());
        List<String> dependencies = new ArrayList<>();
        Set<String> primitiveTypes = Set.of("null", "boolean", "int", "long", "float", "double", "bytes", "string");

        for (Object fieldType : fieldTypes) {
            if (fieldType instanceof String typeName) {
                if (!primitiveTypes.contains(typeName)) {
                    dependencies.add(typeName);
                }
            } else if (fieldType instanceof List<?> unionTypes) {
                for (Object unionType : unionTypes) {
                    if (unionType instanceof String typeName && !primitiveTypes.contains(typeName)) {
                        dependencies.add(typeName);
                    }
                }
            } else if (fieldType instanceof Map<?, ?> typeMap) {
                String items = io.zenwave360.sdk.utils.JSONPath.get(typeMap, "$.items", null);
                if (items != null && !primitiveTypes.contains(items)) {
                    dependencies.add(items);
                }
            }
        }

        return dependencies;
    }

    private static String AVRO_VERSION = getAvroVersion();

    private static String getAvroVersion() {
        Package avroPackage = org.apache.avro.Schema.class.getPackage();
        if (avroPackage != null && avroPackage.getImplementationVersion() != null) {
            return avroPackage.getImplementationVersion();
        }
        return "0.0.0";
    }

    public boolean isAvroVersionLater(String version) {
        String[] currentVersionParts = AVRO_VERSION.split("\\.");
        String[] targetVersionParts = version.split("\\.");

        int currentMajor = Integer.parseInt(currentVersionParts[0]);
        int currentMinor = Integer.parseInt(currentVersionParts[1]);
        int targetMajor = Integer.parseInt(targetVersionParts[0]);
        int targetMinor = Integer.parseInt(targetVersionParts[1]);

        return currentMajor > targetMajor ||
                (currentMajor == targetMajor && currentMinor >= targetMinor);
    }

    private boolean matchesIncludes(String pathString, List<String> includes) {
        if (includes == null || includes.isEmpty()) {
            boolean matches = pathString.endsWith(".avsc");
            log.trace("File {} matches default include pattern: {}", pathString, matches);
            return matches;
        }
        String normalizedPath = pathString.replace("\\", "/");
        boolean matches = includes.stream().anyMatch(include -> AntStyleMatcher.match(include, normalizedPath));
        log.trace("File {} matches includes {}: {}", normalizedPath, includes, matches);
        return matches;
    }

    private boolean matchesExcludes(String pathString, List<String> excludes) {
        if (excludes == null || excludes.isEmpty()) {
            log.trace("File {} has no excludes, not excluded", pathString);
            return false;
        }
        String normalizedPath = pathString.replace("\\", "/");
        boolean matches = excludes.stream().anyMatch(exclude -> AntStyleMatcher.match(exclude, normalizedPath));
        log.trace("File {} matches excludes {}: {}", normalizedPath, excludes, matches);
        return matches;
    }

}
