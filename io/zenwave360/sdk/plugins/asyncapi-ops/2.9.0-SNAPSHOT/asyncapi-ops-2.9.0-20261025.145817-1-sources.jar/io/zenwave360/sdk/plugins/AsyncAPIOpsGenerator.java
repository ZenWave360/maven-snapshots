package io.zenwave360.sdk.plugins;

import io.zenwave360.sdk.MainGenerator;
import io.zenwave360.jsonrefparser.AuthenticationValue;
import io.zenwave360.sdk.doc.DocumentedOption;
import io.zenwave360.sdk.generators.Generator;
import io.zenwave360.sdk.parsers.Model;
import io.zenwave360.sdk.plugins.templates.TerraformConfluentHybridTemplates;
import io.zenwave360.sdk.plugins.templates.TerraformConfluentTemplates;
import io.zenwave360.sdk.plugins.templates.TerraformKafkaTemplates;
import io.zenwave360.sdk.templating.OutputFormatType;
import io.zenwave360.sdk.templating.TemplateInput;
import io.zenwave360.sdk.templating.TemplateOutput;
import io.zenwave360.sdk.utils.JSONPath;
import io.zenwave360.sdk.zdl.GeneratedProjectFiles;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import static io.zenwave360.sdk.templating.OutputFormatType.JAVA;

public class AsyncAPIOpsGenerator extends Generator {

    private Logger log = LoggerFactory.getLogger(getClass());

    @DocumentedOption(description = "Templates to use for code generation.", values = {"TerraformKafka", "TerraformConfluent", "TerraformConfluentHybrid", "FQ Class Name"})
    public String templates = "TerraformKafka";

    @DocumentedOption(description = "How Confluent service accounts are resolved: existing looks them up by display name; managed provisions them.", values = {"existing", "managed"})
    public String serviceAccountMode = "existing";

    @DocumentedOption(description = "Additional Avro schema files or folders available while bundling owned message schemas. Sibling .avsc files are discovered automatically for local and classpath schemas.")
    public List<String> avroImports = List.of();

    @DocumentedOption(description = "Authentication configuration values for fetching remote resources.")
    public List<AuthenticationValue> authentication = List.of();

    @DocumentedOption(description = "Target folder to generate code to.")
    public File targetFolder;

    public String sourceProperty = "api";

    @Override public GeneratedProjectFiles generate(Map<String, Object> contextModel) {
        if (!"existing".equals(serviceAccountMode) && !"managed".equals(serviceAccountMode)) {
            throw new IllegalArgumentException("serviceAccountMode must be either 'existing' or 'managed'");
        }
        Model apiModel = (Model) contextModel.get(sourceProperty);
        Templates templates = configureTemplates();

        var outputList = new ArrayList<TemplateOutput>();

        // Pass the intent model (built by AsyncAPIOpsIntentProcessor) to common templates
        var commonExtModel = new HashMap<String, Object>();
        var intent = contextModel.get("intent");
        if (intent != null) {
            commonExtModel.put("intent", intent);
        }
        commonExtModel.put("managedConfluentServiceAccounts", "managed".equals(serviceAccountMode));
        outputList.addAll(generateTemplateOutput(contextModel, templates.commonTemplates, commonExtModel));
        outputList.addAll(generateBundledSchemaOutputs((AsyncAPIOpsIntent) intent));

        if (apiModel != null) {
            var channels = JSONPath.get(apiModel, "$.channels", Map.<String, Map>of());
            outputList.addAll(generateTemplateOutput(contextModel, templates.allChannelsTemplates, Map.of("channels", channels)));

            var allMessages = new HashMap<>();

            for (Map.Entry<String, Map> channelEntry : channels.entrySet()) {
                var channelModel = Map.of("channelName", channelEntry.getKey(), "channel", channelEntry.getValue());
                outputList.addAll(generateTemplateOutput(contextModel, templates.channelTemplates, channelModel));

                var messages = JSONPath.get(channelEntry.getValue(), "$.messages", Map.<String, Map>of());
                outputList.addAll(generateTemplateOutput(contextModel, templates.channelMessagesTemplates, channelModel));

                for (Map.Entry<String, Map> messageEntry : messages.entrySet()) {
                    var messageModel = Map.of(
                            "channelName", channelEntry.getKey(),
                            "channel", channelEntry.getValue(),
                            "messageName", messageEntry.getKey(),
                            "message", messageEntry.getValue());
                    outputList.addAll(generateTemplateOutput(contextModel, templates.messageTemplates, messageModel));
                }
                allMessages.putAll(messages);
            }

            outputList.addAll(generateTemplateOutput(contextModel, templates.allMessagesTemplates, Map.of("messages", allMessages)));
        }

        GeneratedProjectFiles generatedProjectFiles = new GeneratedProjectFiles();
        generatedProjectFiles.singleFiles.addAll(outputList);
        return generatedProjectFiles;
    }

    protected List<TemplateOutput> generateBundledSchemaOutputs(AsyncAPIOpsIntent intent) {
        if (intent == null || intent.schemas.isEmpty()) {
            return List.of();
        }
        ClassLoader projectClassLoader = configuration != null ? configuration.getProjectClassLoader() : null;
        AsyncAPIOpsAvroBundler bundler = new AsyncAPIOpsAvroBundler(avroImports, authentication, projectClassLoader);
        // Channel address parameter expansion produces one subject per resolved address, all
        // referencing the same bundled .avsc file: bundle and write each file only once.
        var schemasByTargetFile = new java.util.LinkedHashMap<String, AsyncAPIOpsIntent.SchemaIntent>();
        for (AsyncAPIOpsIntent.SchemaIntent schema : intent.schemas) {
            schemasByTargetFile.putIfAbsent(schema.schemaFile + "|" + schema.sourceSchemaUri, schema);
        }
        return schemasByTargetFile.values().stream()
                .map(bundler::bundle)
                .toList();
    }

    protected Templates configureTemplates() {
        Templates templatesObject = null;
        if("TerraformKafka".equals(templates)) {
            templatesObject = new TerraformKafkaTemplates(this);
        } else if("TerraformConfluent".equals(templates)) {
            templatesObject = new TerraformConfluentTemplates(this);
        } else if("TerraformConfluentHybrid".equals(templates)) {
            templatesObject = new TerraformConfluentHybridTemplates(this);
        } else {
            // Instantiate FQ class name
            try {
                templatesObject = (Templates) Class.forName(templates).getConstructor(
                        AsyncAPIOpsGenerator.class).newInstance(this);
            } catch (Exception e) {
                try {
                    templatesObject = (Templates) Class.forName(templates).getConstructor().newInstance();
                } catch (Exception ex) {
                    throw new RuntimeException(e);
                }
            }
        }
        try {
            MainGenerator.applyConfiguration(0, templatesObject, configuration);
            return templatesObject;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected List<TemplateOutput> generateTemplateOutput(Map<String, Object> contextModel, List<TemplateInput> templates, Map<String, Object> extModel) {
        Map<String, Object> baseModel = new HashMap<>();
        baseModel.putAll(this.asConfigurationMap());
        baseModel.put("context", contextModel);
        baseModel.put("asyncapi", contextModel.get(sourceProperty));
        // baseModel.putAll(this.templates.getDocumentedOptions());

        var templateOutputList = new ArrayList<TemplateOutput>();
        for (TemplateInput template : templates) {
            var model = new HashMap<>(baseModel);
            model.putAll(extModel);
            templateOutputList.addAll(getTemplateEngine().processTemplates(model, List.of(template)));
        }
        return templateOutputList;
    }


    public static class Templates {

        public final String templatesFolder;

        public Templates(String templatesFolder) {
            this.templatesFolder = templatesFolder;
        }


        public List<TemplateInput> commonTemplates = new ArrayList<>();

        public List<TemplateInput> allChannelsTemplates = new ArrayList<>();
        public List<TemplateInput> channelTemplates = new ArrayList<>();
        public List<TemplateInput> channelMessagesTemplates = new ArrayList<>();
        public List<TemplateInput> messageTemplates = new ArrayList<>();
        public List<TemplateInput> allMessagesTemplates = new ArrayList<>();

        public void addTemplate(List<TemplateInput> templates, String templateLocation, String targetFile) {
            addTemplate(templates, templateLocation, targetFile, JAVA, null, false);
        }

        public void addTemplate(List<TemplateInput> templates, String templateLocation, String targetFile, OutputFormatType mimeType, Function<Map<String, Object>, Boolean> skip, boolean skipOverwrite) {
            var template = new TemplateInput()
                    .withTemplateLocation(templatesFolder + "/" + templateLocation)
                    .withTargetFile(targetFile)
                    .withMimeType(mimeType)
                    .withSkipOverwrite(skipOverwrite)
                    .withSkip(skip);
            templates.add(template);
        }
    }
}
