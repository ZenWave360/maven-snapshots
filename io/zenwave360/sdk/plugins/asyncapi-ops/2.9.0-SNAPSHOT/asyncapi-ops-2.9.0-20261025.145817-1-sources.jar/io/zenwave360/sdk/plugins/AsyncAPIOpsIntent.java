package io.zenwave360.sdk.plugins;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AsyncAPIOpsIntent {

    public String server;
    public List<TopicIntent> topics = new ArrayList<>();
    public List<SchemaIntent> schemas = new ArrayList<>();
    public List<AclIntent> acls = new ArrayList<>();
    public List<RoleBindingIntent> roleBindings = new ArrayList<>();
    public List<PrincipalIntent> principals = new ArrayList<>();
    /** Channels skipped because their address carries an unbounded (non-enum) parameter */
    public List<SkippedChannelIntent> skippedChannels = new ArrayList<>();

    private final Set<String> skippedChannelKeys = new LinkedHashSet<>();
    private final Set<String> aclKeys = new LinkedHashSet<>();
    private final Set<String> roleBindingKeys = new LinkedHashSet<>();
    private final Set<String> principalNames = new LinkedHashSet<>();
    private final Map<String, String> principalNamesByResourceName = new LinkedHashMap<>();
    private final Map<String, SchemaIntent> schemasBySubject = new LinkedHashMap<>();

    public void addPrincipal(String name, String resourceName) {
        String existingName = principalNamesByResourceName.putIfAbsent(resourceName, name);
        if (existingName != null && !existingName.equals(name)) {
            throw new IllegalArgumentException("Principal resource name collision: '" + existingName
                    + "' and '" + name + "' both sanitize to '" + resourceName + "'");
        }
        if (principalNames.add(name)) {
            PrincipalIntent principal = new PrincipalIntent();
            principal.name = name;
            principal.resourceName = resourceName;
            principals.add(principal);
        }
    }

    public void addSkippedChannel(String channelKey, String address, String parameterName) {
        if (!skippedChannelKeys.add(channelKey + "|" + address)) {
            return;
        }
        SkippedChannelIntent skipped = new SkippedChannelIntent();
        skipped.channelKey = channelKey;
        skipped.address = address;
        skipped.parameterName = parameterName;
        skippedChannels.add(skipped);
    }

    public void addAcl(AclIntent acl) {
        String key = acl.resourceType + "|" + acl.kafkaResourceName + "|" + acl.patternType + "|" + acl.principal + "|" + acl.operation;
        if (aclKeys.add(key)) {
            acls.add(acl);
        }
    }

    public void addRoleBinding(RoleBindingIntent roleBinding) {
        String key = roleBinding.principal + "|" + roleBinding.roleName + "|" + roleBinding.crnPattern;
        if (roleBindingKeys.add(key)) {
            roleBindings.add(roleBinding);
        }
    }

    /**
     * Adds one Schema Registry subject. Multiple messages may legitimately resolve to the same
     * subject (for example with TopicNameStrategy), but that subject can have only one schema and
     * compatibility configuration in the generated Terraform.
     */
    public void addSchema(SchemaIntent schema) {
        SchemaIntent existing = schemasBySubject.putIfAbsent(schema.subject, schema);
        if (existing == null) {
            schemas.add(schema);
            return;
        }
        if (!sameSchemaConfiguration(existing, schema)) {
            throw new IllegalArgumentException("Schema Registry subject '" + schema.subject
                    + "' resolves to conflicting schema definitions. Use TopicRecordNameStrategy "
                    + "or RecordNameStrategy, or configure the messages with the same schema and compatibility.");
        }
    }

    private boolean sameSchemaConfiguration(SchemaIntent left, SchemaIntent right) {
        return java.util.Objects.equals(left.schemaType, right.schemaType)
                && java.util.Objects.equals(left.compatibility, right.compatibility)
                && java.util.Objects.equals(left.schemaFile, right.schemaFile)
                && java.util.Objects.equals(left.sourceSchemaUri, right.sourceSchemaUri);
    }

    public static class TopicIntent {
        /** Snake_case Terraform resource identifier */
        public String resourceName;
        /** Actual Kafka topic address */
        public String topicName;
        public Integer partitions;
        public Integer replicationFactor;
        public Map<String, String> config = new LinkedHashMap<>();
        /** True for auto-generated retry/DLQ topics — rendered without config block */
        public boolean isRetryOrDlq;
    }

    public static class SkippedChannelIntent {
        /** AsyncAPI channel key */
        public String channelKey;
        /** Unresolved channel address, still containing the {parameter} expression */
        public String address;
        /** Address parameter with no enum declared */
        public String parameterName;
    }

    public static class SchemaIntent {
        /** Snake_case Terraform resource identifier */
        public String resourceName;
        /** Schema Registry subject resolved from the message Kafka schemaLookupStrategy. */
        public String subject;
        public String schemaType = "AVRO";
        /** BACKWARD, FORWARD, or null (template falls back to var.default_compatibility) */
        public String compatibility;
        /** Relative path to generated bundled .avsc file inside targetFolder */
        public String schemaFile;
        /** Source .avsc URI resolved from the owning AsyncAPI file */
        public String sourceSchemaUri;
    }

    public static class PrincipalIntent {
        /** Provider-neutral authenticated account or service-account name from AsyncAPI */
        public String name;
        /** Snake_case Terraform identifier derived from {@link #name} */
        public String resourceName;
    }

    public static class AclIntent {
        /** Snake_case Terraform resource identifier */
        public String resourceName;
        public String kafkaResourceName;
        public String topicName;
        /** TOPIC, GROUP, or TRANSACTIONAL_ID for Confluent; Topic, Group, or TransactionalId for Kafka OSS templates */
        public String resourceType = "TOPIC";
        public String kafkaResourceType = "Topic";
        public String patternType = "LITERAL";
        public String kafkaPatternType = "Literal";
        /** Provider-neutral principal name from AsyncAPI */
        public String principal;
        /** Terraform identifier used to reference the provider-specific principal lookup */
        public String principalResourceName;
        /** Mongey/kafka spelling: Read, Write, Describe, Create, Delete, Alter, AlterConfigs */
        public String operation;
        /** confluentinc/confluent spelling of {@link #operation}: READ, WRITE, ALTER_CONFIGS, ... */
        public String confluentOperation;
        public String permissionType = "Allow";
    }

    public static class RoleBindingIntent {
        /** Snake_case Terraform resource identifier */
        public String resourceName;
        /** Provider-neutral principal name from AsyncAPI */
        public String principal;
        /** Terraform identifier used to reference the provider-specific principal lookup */
        public String principalResourceName;
        public String roleName;
        public String crnPattern;
    }
}
