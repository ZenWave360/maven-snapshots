package io.zenwave360.sdk.zdl.utils;

import io.zenwave360.sdk.parsers.ZDLParser;
import io.zenwave360.sdk.utils.JSONPath;
import io.zenwave360.sdk.utils.NamingUtils;
import io.zenwave360.sdk.zdl.model.JavaZdlModel;
import org.apache.commons.lang3.StringUtils;

import java.sql.Blob;
import java.util.*;
import java.util.stream.Collectors;

public class ZDLJavaSignatureUtils {

    public static String javaType(Map field) {
        if("Blob".equals(field.get("type")) || "AnyBlob".equals(field.get("type")) || "ImageBlob".equals(field.get("type"))) {
            return "byte[]";
        }
        if("TextBlob".equals(field.get("type"))) {
            return "String";
        }
        return (String) field.get("type");
    }

    // XXX: solo se esta usando en tests
    public static String methodParameterType(Map method, Map zdl) {
        var isPatch = JSONPath.get(method, "options.patch") != null;
        if(isPatch) {
            return "java.util.Map";
        }
        return (String) method.get("parameter");
    }


    public static String findServiceMethodMainParameter(Map<String, Object> method, Map<String, Object> zdlModel) {
        if(method == null) {
            return null;
        }
        var methodParameterType = (String) method.get("parameter");
        var parameterEntity = JSONPath.get(zdlModel, "$.allEntitiesAndEnums." + methodParameterType);
        if(parameterEntity == null) {
            return null;
        }
        var isInline = JSONPath.get(parameterEntity, "$.options.inline", false);
        if (isInline) {
            var fields = JSONPath.get(parameterEntity, "$.fields", Map.<String, Map>of());
            for (Map field : fields.values()) {
                if (JSONPath.get(field, "$.isComplexType", false) && !JSONPath.get(field, "$.isEnum", false)) {
                    return JSONPath.get(field, "$.type");
                }
            }
            return null;
        }
        return methodParameterType;
    }


    public static String fieldsParamsSignature(List<Map> fields) {
        if(fields == null) {
            return "";
        }
        return fields.stream()
                .map(f -> String.format("%s %s", f.get("type"), f.get("name")))
                .collect(Collectors.joining(", "));
    }

    public static String fieldsParamsCallSignature(List<Map> fields) {
        if(fields == null) {
            return "";
        }
        return fields.stream().map(f -> f.get("name").toString()).collect(Collectors.joining(", "));
    }

    public static String naturalIdsRepoMethodSignature(Map entity) {
        List<Map> fields = ZDLFindUtils.naturalIdFields(entity);
        var params = fieldsParamsSignature(fields);
        var fieldNames = fields.stream().map(f -> NamingUtils.camelCase((String) f.get("name"))).toList();
        return String.format("java.util.Optional<%s> findBy%s(%s)", entity.get("name"), StringUtils.join(fieldNames, "And"), params);
    }

    public static String naturalIdsKotlinRepoMethodSignature(Map entity) {
        List<Map> fields = ZDLFindUtils.naturalIdFields(entity);
        var params = fieldsParamsSignature(fields);
        params = toKotlinMethodSignature(params);
        var fieldNames = fields.stream().map(f -> NamingUtils.camelCase((String) f.get("name"))).toList();
        return String.format("fun findBy%s(%s): %s?", StringUtils.join(fieldNames, "And"), params, entity.get("name"));
    }


    public static String naturalIdsRepoMethodCallSignature(Map entity) {
        List<Map> fields = ZDLFindUtils.naturalIdFields(entity);
        var params = fieldsParamsCallSignature(fields);
        var fieldNames = fields.stream().map(f -> NamingUtils.camelCase((String) f.get("name"))).toList();
        return String.format("findBy%s(%s)", StringUtils.join(fieldNames, "And"), params);
    }

    public static String methodParametersSignature(String idJavaType, Map method, Map zdl) {
        return methodParametersSignature(null, idJavaType, method, zdl);
    }

    /**
     * @param artifactType the artifact the current template generates, so parameter annotations can
     *                     be scoped to it. Null renders only artifact independent annotations.
     */
    public static String methodParametersSignature(String artifactType, String idJavaType, Map method, Map zdl) {
        var params = new ArrayList<String>();
        var javaServiceMethod = (JavaZdlModel.ServiceMethod) method.get("javaServiceMethod");
        for (var parameter : javaServiceMethod.parameters()) {
            var type = "id".equals(parameter.name())? idJavaType : parameter.type();
            if(parameter.isArray()) {
                type = "List<" + type + ">";
            }
            var annotations = annotations(parameter.annotations(), artifactType);
            params.add((annotations + " " + type + " " + parameter.name()).trim());
        }
        return StringUtils.join(params, ", ");
    }

    public static String kotlinMethodParametersSignature(String idJavaType, Map method, Map zdl) {
        return kotlinMethodParametersSignature(null, idJavaType, method, zdl);
    }

    public static String kotlinMethodParametersSignature(String artifactType, String idJavaType, Map method, Map zdl) {
        return kotlinMethodParametersSignature(artifactType, idJavaType, method, zdl, false);
    }

    public static String kotlinNullableMethodParametersSignature(String artifactType, String idJavaType, Map method, Map zdl) {
        return kotlinMethodParametersSignature(artifactType, idJavaType, method, zdl, true);
    }

    private static String kotlinMethodParametersSignature(String artifactType, String idJavaType, Map method, Map zdl,
            boolean nullable) {
        var params = new ArrayList<String>();
        var javaServiceMethod = (JavaZdlModel.ServiceMethod) method.get("javaServiceMethod");
        for (var parameter : javaServiceMethod.parameters()) {
            var type = "id".equals(parameter.name())? idJavaType : parameter.type();
            if("java.util.Map".equals(type)) {
                type = "Map<String,Any?>";
            }
            if(parameter.isArray()) {
                type = "List<" + type + ">";
            }
            var annotations = annotations(parameter.annotations(), artifactType);
            params.add((annotations + " " + parameter.name() + ": " + type
                    + (nullable || parameter.isOptional() ? "?" : "")).trim());
        }
        return StringUtils.join(params, ", ").trim();
    }

    /** Renders the annotations of a signature element that apply to the given artifact type. */
    public static String annotations(List<JavaZdlModel.Annotation> annotations, String artifactType) {
        return annotations.stream()
                .filter(annotation -> annotation.appliesTo(artifactType))
                .map(annotation -> annotation.value() != null
                        ? "@" + annotation.name() + "(" + annotation.value() + ")"
                        : "@" + annotation.name())
                .distinct()
                .collect(Collectors.joining(" "));
    }

    /** Method return type, prefixed with any return type annotations scoped to this artifact. */
    public static String methodReturnType(String artifactType, Map method) {
        var javaServiceMethod = (JavaZdlModel.ServiceMethod) method.get("javaServiceMethod");
        var returnType = javaServiceMethod != null ? javaServiceMethod.returnType() : null;
        var annotations = returnType != null ? annotations(returnType.annotations(), artifactType) : "";
        return (annotations + " " + methodReturnType(method)).trim();
    }

    public static String toKotlinMethodSignature(String signature) {
        if(signature == null || signature.isEmpty()) {
            return "";
        }
        var params = signature.split(", ");
        for (int i = 0; i < params.length; i++) {
            var param = params[i].split(" ");
            params[i] = param[1] + ": " + param[0];
        }
        return StringUtils.join(params, ", ");
    }

    public static String methodParametersCallSignature(Map method, Map zdl) {
        var javaServiceMethod = (JavaZdlModel.ServiceMethod) method.get("javaServiceMethod");
        return javaServiceMethod.parameters().stream().map(p -> p.name()).collect(Collectors.joining(", "));
    }

    private static List<String> methodInputSignature(Map method, Map zdl) {
        return inputSignature((String) method.get("parameter"), method, zdl);
    }

    public static String mapperInputSignature(String inputType, Map zdl) {
        if("Map".equals(inputType) || "java.util.Map".equals(inputType)) {
            return "java.util.Map input";
        }
        return StringUtils.join(inputSignature(inputType, null, zdl), ", ");
    }

    public static String kotlinMapperInputSignature(String inputType, Map zdl) {
        if("Map".equals(inputType) || "java.util.Map".equals(inputType)) {
            return "input: Map<String,Any?>";
        }
        var mapperInputSignature = StringUtils.join(inputSignature(inputType, null, zdl), ", ");
        var kotlinSignature = toKotlinMethodSignature(mapperInputSignature);
        if(JSONPath.get(zdl, "$.inputs." + inputType + ".options.inline", false)) {
            var optionalParamFields = JSONPath.get(zdl, "$.inputs." + inputType + ".fields[*][?(!@.validations.required)]", List.<Map>of());
            for (var field : optionalParamFields) {
                if(!JSONPath.get(field, "$.isArray", false)) {
                    kotlinSignature = kotlinSignature.replace(field.get("name") + ": " + field.get("type"), field.get("name") + ": " + field.get("type") + "?");
                }
            }
        }
        return kotlinSignature;
    }

    public static String mapperInputCallSignature(String inputType, Map zdl) {
        return inputSignature(inputType, null, zdl).stream()
                .map(p -> p.split(" ")[1])
                .collect(Collectors.joining(", "));
    }

    public static List<Map<String, String>> mapperInputAnnotations(String inputType, Map zdl) {
        var annotations = new ArrayList<Map<String, String>>();
        if(inputType != null) {
            var isInline = JSONPath.get(zdl, "$.allEntitiesAndEnums." + inputType + ".options.inline", false);
            var fields = (Map<String, Map>) JSONPath.get(zdl, "$.allEntitiesAndEnums." + inputType + ".fields");
            if (isInline && fields != null && !fields.isEmpty()) {
                for (var field : fields.entrySet()) {
                    annotations.add(Map.of("source", field.getKey(), "target", (String) field.getValue().get("name")));
                }
            }
        }
        return annotations;
    }

    public static String inputFieldInitializer(String inputType, Map zdl) {
        return inputSignature(inputType, null, zdl).stream()
                .map(p -> p + " = null;\n")
                .collect(Collectors.joining());
    }

    public static List<String> inputSignature(String inputType, Map method, Map zdl) {
        var params = new ArrayList<String>();
        if(inputType != null) {
            var isInline = JSONPath.get(zdl, "$.inputs." + inputType + ".options.inline", false);
            var fields = (Map<String, Map>) JSONPath.get(zdl, "$.inputs." + inputType + ".fields");
            if (isInline && fields != null && !fields.isEmpty()) {
                for (var field : fields.entrySet()) {
                    var isArray = JSONPath.get(field.getValue(), "$.isArray", false);
                    if(isArray) {
                        params.add(String.format("List<%s> %s", field.getValue().get("type"), field.getKey()));
                    } else {
                        params.add(String.format("%s %s", field.getValue().get("type"), field.getKey()));
                    }
                }
            } else {
                var methodParameterType = method != null? methodParameterType(method, zdl) : inputType;
                params.add(methodParameterType + " input");
            }
        }
        return params;
    }

    public static List<String> methodInputCall(Map method, Map zdl) {
        var params = new ArrayList<String>();
        if(JSONPath.get(method, "parameter") != null) {
            var parameterType = (String) method.get("parameter");
            var isInline = JSONPath.get(zdl, "$.inputs." + parameterType + ".options.inline", false);
            var fields = (Map<String, Map>) JSONPath.get(zdl, "$.inputs." + parameterType + ".fields");
            if (isInline && fields != null && !fields.isEmpty()) {
                for (var field : fields.entrySet()) {
                    params.add(field.getKey());
                }
            } else {
                var methodParameterType = methodParameterType(method, zdl);
                params.add(methodParameterType + " input");
            }
        }
        return params;
    }

    public static String methodReturnType(Map method) {
        var methodName = (String) method.get("name");
        var returnType = method.get("returnType");
        var returnTypeIsArray = (Boolean) method.getOrDefault("returnTypeIsArray", false);
        if (returnType == null) {
            return "void";
        }
        //        if(methodName.startsWith("create")) {
        //            return (String) returnType;
        //        }
        if(returnTypeIsArray) {
            if(JSONPath.get(method, "options.paginated", false)) {
                return String.format("Page<%s>", returnType);
            }
            return String.format("List<%s>", returnType);
        }
        var isOptional = "true".equals(String.valueOf(method.get("returnTypeIsOptional")));
        if(isOptional) {
            return String.format("Optional<%s>", returnType);
        }
        var isAsync = JSONPath.get(method, "options.async") != null;
        if(isAsync) {
            return String.format("CompletableFuture<%s>", returnType);
        }
        return (String) returnType;
    }

    public static String fieldType(Map field, String prefix, String suffix) {
        String type = javaType(field);
        if (field.get("isArray") == Boolean.TRUE) {
            if("byte".equalsIgnoreCase(type)) {
                return "byte[]";
            }
            return String.format("List<%s%s%s>", prefix, type, suffix);
        }
        if ("Map".equals(type)) {
            return "Map<String,Object>";
        }
        return String.format("%s%s%s", prefix, type, suffix);
    };

    /** An integer literal for a Long field needs the L suffix, in Java (`Long x = 1;`) as in Kotlin (`Long? = 1`). */
    private static String longLiteral(Map field, String value) {
        if ("Long".equals(field.get("type")) && !JSONPath.get(field, "isArray", false) && value.matches("-?\\d+")) {
            return value + "L";
        }
        return value;
    }

    public static String fieldTypeInitializer(Map field) {
        if (field.get("initialValue") != null) {
            if ("String".equals(field.get("type")) || "TextBlob".equals(field.get("type"))) {
                return "= \"" + field.get("initialValue") + "\"";
            }
            return "= " + longLiteral(field, String.valueOf(field.get("initialValue")));
        }
        if (field.get("isArray") == Boolean.TRUE) {
            if("byte".equalsIgnoreCase(String.valueOf(field.get("type")))) {
                return "";
            }
            return "= new ArrayList<>()";
        }
        return "";
    }

    public static String populateField(Map field) {
        String value;
        if(field.get("initialValue") != null) {
            if ("String".equals(field.get("type")) || "TextBlob".equals(field.get("type"))) {
                if(!JSONPath.get(field,"isArray", false)) {
                    return "\"" + field.get("initialValue") + "\"";
                }
            }
            return longLiteral(field, String.valueOf(field.get("initialValue")));
        }
        if ("String".equals(field.get("type")) || "TextBlob".equals(field.get("type"))) {
            int min = Integer.valueOf(JSONPath.get(field, "validations.minlength.value", "0"));
            int max = Integer.valueOf(JSONPath.get(field, "validations.minlength.value", "0"));
            int middle = min + (max - min) / 2;
            value = "\"" + StringUtils.repeat("a", middle) + "\"";
        } else if (JSONPath.get(field,"isEnum", false)) {
            value = field.get("type") + ".values()[0]";
        } else if ("LocalDate".equals(field.get("type"))) {
            value = "LocalDate.now()";
        } else if ("LocalDateTime".equals(field.get("type"))) {
            value = "LocalDateTime.now()";
        } else if ("LocalTime".equals(field.get("type"))) {
            value = "LocalTime.now()";
        } else if ("OffsetDateTime".equals(field.get("type"))) {
            value = "OffsetDateTime.now()";
        } else if ("ZonedDateTime".equals(field.get("type"))) {
            value = "ZonedDateTime.now()";
        } else if ("Instant".equals(field.get("type"))) {
            value = "Instant.now()";
        } else if ("Duration".equals(field.get("type"))) {
            value = "Duration.ofSeconds(0)";
        } else if ("Integer".equals(field.get("type"))) {
            value = "0";
        } else if ("Long".equals(field.get("type"))) {
            value = "0L";
        } else if ("Float".equals(field.get("type"))) {
            value = "0.0F";
        } else if ("Double".equals(field.get("type"))) {
            value = "0.0";
        } else if("BigDecimal".equals(field.get("type"))) {
            value = "BigDecimal.valueOf(0)";
        } else if ("Boolean".equals(field.get("type"))) {
            value = "false";
        } else if ("UUID".equals(field.get("type"))) {
            value = "UUID.randomUUID()";
        } else if (ZDLParser.blobTypes.contains(field.get("type"))) {
            value = "null";
        } else if ("Map".equals(field.get("type"))) {
            value = "new java.util.HashMap()";
        } else {
            value = "new " + field.get("type") + "()";
        }

        if (JSONPath.get(field,"isArray", false)) {
            return "List.of(" + value + ")";
        }

        return value;
    }

    public static String relationshipFieldType(Map relationship, String prefix, String suffix) {
        String type = (String) relationship.get("otherEntityName");
        if (relationship.get("isCollection") == Boolean.TRUE) {
            return String.format("Set<%s%s%s>", prefix, type, suffix);
        }
        return String.format("%s%s%s", prefix, type, suffix);
    };

    public static String relationshipFieldTypeInitializer(Map relationship) {
        if (relationship.get("isCollection") == Boolean.TRUE) {
            return "= new HashSet<>()";
        }
        return "";
    };

}
